# SALEC NEW_PRO — to‘liq source code

Branch: arena/8d9c1cbf-new-pro
Base: 7fc3bd0dbde1f48035fbf6a4ca0b93e8a4d16e2d (main)
Sana: 2026-11-15

## Ichida
- Butun repository source kodi: backend, frontend, mobile, infrastructure,
  shared, scripts, docs, packages/*, telegram-client-bot, root config fayllari.
- Yangi `@salec/plans-proposal` yadrosi va `@salec/plans-proposal-demo` web demosi,
  barcha testlar, README va `docs/PLANS_TAKLIFIY_REJA_ANALIZ_VA_REJA.md`.

## Chiqarib tashlandi
- `.git/`, barcha `node_modules/`, `dist/`, `build/`, `test-results/`, `coverage/`,
  IDE/kesh papkalari, `.log`/`.last-run.json`, `lint-report.json`.
- Katta binary installer/assetlar: `frontend/public/salec-link/*.exe|apk|zip`,
  `*.bin` model fayllari, arxivlar. Ular repo ichida qoladi; zip hajmini kichik
  saqlash uchun kiritilmadi. Kerak bo‘lsa alohida so‘rang.
- `packages/plans-proposal-demo/public/yuklab-olish.html` sahifasi KIRITILGAN;
  uning yonidagi serve qilingan ZIP nusxalari esa arxivga qayta kiritilmadi.

## Ishga tushirish
```bash
npm install
npm run plans:proposal:demo          # http://localhost:5175
npm run plans:proposal:test          # core 32 + demo 28 + typecheck + build
npm run test:e2e --workspace=@salec/plans-proposal-demo
```

`package-lock.json` va `docs/README.md` CRLF yangi satr belgilarini saqlagan holda qo‘shildi.
