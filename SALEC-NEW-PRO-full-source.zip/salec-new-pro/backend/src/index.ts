/** Backend entry — `env` must load before `app` (Prisma reads `DATABASE_URL`). */
import { env } from "./config/env";
import { buildApp } from "./app";
import { prisma } from "./config/database";
import { logger } from "./config/logger";
import { closeOrderEventBusRedis, initOrderEventBusRedis } from "./lib/order-event-bus";
import { disableAutoClose, enableAutoClose } from "./lib/order-auto-cron";
import { disableDashboardCacheWarm, enableDashboardCacheWarm } from "./lib/dashboard-cache-warm";
import {
  disableProductPriceScheduleCron,
  enableProductPriceScheduleCron
} from "./lib/product-price-schedule-cron";
import {
  disablePaymentReturnFinalizeCron,
  enablePaymentReturnFinalizeCron
} from "./lib/payment-return-finalize-cron";
import {
  disableConsignmentClosureCron,
  enableConsignmentClosureCron
} from "./lib/consignment-closure-cron";
import { disableAuditRetentionCron, enableAuditRetentionCron } from "./lib/audit-retention-cron";
import { disableTabelShiftCloseCron, enableTabelShiftCloseCron } from "./lib/tabel-shift-close-cron";
import { disableTabelRetentionCron, enableTabelRetentionCron } from "./lib/tabel-retention-cron";
import { disablePayrollCron, enablePayrollCron } from "./lib/payroll-cron";
import { startPayrollOrderHook } from "./modules/payroll/payroll.auto-hooks";
import { startMonthEndDueBackfill } from "./modules/client-balances/client-balances.consignment-due";
import { startFinishedReturnOrderBackfill } from "./modules/returns/returns-finished-order-backfill";
import { startTgApp, stopTgApp } from "./modules/tg-app/tg-runner";

async function main() {
  await prisma.$connect();
  startMonthEndDueBackfill();
  const app = buildApp();
  await initOrderEventBusRedis(app.log);

  /** Dev/test: `0.0.0.0` ba’zi Windows portlarida EACCES beradi; lokalda 127.0.0.1 yetarli. */
  const listenHost = env.NODE_ENV === "production" ? "0.0.0.0" : "127.0.0.1";
  await app.listen({ port: env.PORT, host: listenHost });
  app.log.info({ port: env.PORT, host: listenHost }, "Server listening");
  startFinishedReturnOrderBackfill();

  if (env.CRON_VIA_WORKER === "1") {
    app.log.info("Auto-status + price schedule crons owned by BullMQ worker (CRON_VIA_WORKER=1).");
  } else {
    enableAutoClose();
    app.log.info("Auto-status cron enabled (Redis lock).");
    enableProductPriceScheduleCron();
    app.log.info("Product price schedule cron enabled (Redis lock).");
  }
  enablePaymentReturnFinalizeCron();
  app.log.info("Payment return finalize cron enabled.");
  enableDashboardCacheWarm();
  enableAuditRetentionCron();
  app.log.info("Audit retention cron enabled (audit + activity).");
  enableTabelShiftCloseCron();
  app.log.info("Tabel shift-close cron enabled (every 10 minutes).");
  enableTabelRetentionCron();
  app.log.info("Tabel retention cron enabled (03:00 and 04:00 Asia/Tashkent).");
  enableConsignmentClosureCron();
  app.log.info("Consignment month closure cron enabled.");
  const stopPayrollOrderHook = startPayrollOrderHook();
  enablePayrollCron();
  app.log.info("Payroll auto-recalc cron enabled.");
  void startTgApp();

  const shutdown = async () => {
    stopTgApp();
    stopPayrollOrderHook();
    disablePayrollCron();
    disableAutoClose();
    disableProductPriceScheduleCron();
    disablePaymentReturnFinalizeCron();
    disableDashboardCacheWarm();
    disableAuditRetentionCron();
    disableTabelShiftCloseCron();
    disableTabelRetentionCron();
    disableConsignmentClosureCron();
    await app.close();
    await closeOrderEventBusRedis();
    process.exit(0);
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

main().catch((error) => {
  logger.error({ err: error }, "Fatal startup error");
  process.exit(1);
});
