import { z } from "zod";

const orderLineItemSchema = z.object({
  product_id: z.number().int().positive(),
  qty: z.number().positive()
});

const bonusGiftOverrideSchema = z.object({
  bonus_rule_id: z.number().int().positive(),
  bonus_product_id: z.number().int().positive()
});

const bonusGiftLineSchema = z.object({
  bonus_rule_id: z.number().int().positive(),
  product_id: z.number().int().positive(),
  qty: z.number().positive()
});

const exchangeLineSchema = z.object({
  order_id: z.number().int().positive(),
  product_id: z.number().int().positive(),
  qty: z.number().positive()
});

const plusLineSchema = z.object({
  product_id: z.number().int().positive(),
  qty: z.number().positive()
});

/** POST `/api/:slug/orders` tanasi */
export const createOrderBodySchema = z
  .object({
    client_id: z.number().int().positive(),
    warehouse_id: z.number().int().positive(),
    agent_id: z.number().int().positive().nullable().optional(),
    expeditor_user_id: z.number().int().positive().nullable().optional(),
    price_type: z.string().trim().min(1).max(128).optional().nullable(),
    /** Старые цены: YYYY-MM-DD — qator narxlari shu sana bo‘yicha */
    price_as_of: z
      .string()
      .trim()
      .regex(/^\d{4}-\d{2}-\d{2}$/)
      .optional()
      .nullable(),
    /** Zakaz sanasi/vaqti (ISO). Bo‘sh → server now. Davr cheklovi — create da tekshiriladi. */
    created_at: z.string().max(48).optional().nullable(),
    order_type: z.enum(["order", "return", "exchange", "partial_return", "return_by_order"]).optional(),
    apply_bonus: z.boolean().optional(),
    /** `false` — chegirma qo‘llanmaydi (bonus yoqilgan bo‘lsa ham). */
    apply_discount: z.boolean().optional(),
    bonus_gift_overrides: z.array(bonusGiftOverrideSchema).optional(),
    bonus_gift_lines: z.array(bonusGiftLineSchema).optional(),
    bonus_strategy_selections: z
      .array(
        z.object({
          strategy_id: z.number().int().positive(),
          rule_ids: z.array(z.number().int().positive()).min(1).max(200)
        })
      )
      .max(50)
      .optional(),
    comment: z.string().max(4000).optional().nullable(),
    request_type_ref: z.string().trim().max(128).optional().nullable(),
    is_consignment: z.boolean().optional(),
    consignment_due_date: z.string().max(40).optional().nullable(),
    items: z.array(orderLineItemSchema).default([]),
    payment_method_ref: z.string().trim().max(64).optional().nullable(),
    source_order_ids: z.array(z.number().int().positive()).optional(),
    minus_lines: z.array(exchangeLineSchema).optional(),
    plus_lines: z.array(plusLineSchema).optional(),
    reason_ref: z.string().trim().max(256).optional().nullable(),
    /** Ixtiyoriy hujjat ID (har qanday matn); bo‘sh → create dan keyin String(id) */
    number: z.string().trim().min(1).max(64).optional().nullable(),
    /** Offline/retry UUID — bir xil kalit → mavjud zakaz qaytariladi */
    client_uuid: z.string().trim().uuid().max(64).optional().nullable()
  })
  .superRefine((data, ctx) => {
    const ot = data.order_type ?? "order";
    if (ot === "exchange") {
      if (!data.source_order_ids?.length) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Исходные заказы (source_order_ids) обязательны",
          path: ["source_order_ids"]
        });
      }
      if (!data.minus_lines?.length) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Строки списания (minus_lines) обязательны",
          path: ["minus_lines"]
        });
      }
      if (!data.plus_lines?.length) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Строки добавления (plus_lines) обязательны",
          path: ["plus_lines"]
        });
      }
      return;
    }
    if (!data.items.length) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Нужна хотя бы одна строка",
        path: ["items"]
      });
    }
    if (ot !== "order") return;
    if (data.agent_id == null || data.agent_id < 1) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Агент обязателен",
        path: ["agent_id"]
      });
    }
  });

function parseOptionalPosInt(raw: string | undefined): number | undefined {
  if (!raw?.trim()) return undefined;
  const n = Number.parseInt(raw.trim(), 10);
  return !Number.isNaN(n) && n > 0 ? n : undefined;
}

function parseAgentIds(raw: string | undefined): number[] | undefined {
  if (!raw?.trim()) return undefined;
  const ids = raw
    .split(/[,;\s]+/)
    .map((s) => Number.parseInt(s.trim(), 10))
    .filter((n) => Number.isFinite(n) && n > 0);
  return ids.length > 0 ? ids : undefined;
}

function parseConsignmentFlag(raw: string | undefined): boolean | undefined {
  const v = raw?.trim().toLowerCase();
  if (v === "true" || v === "1" || v === "yes") return true;
  if (v === "false" || v === "0" || v === "no") return false;
  return undefined;
}

/** GET `/api/:slug/orders` query — string query parametrlarini servis shakliga */
export const ordersListQuerySchema = z
  .object({
    page: z.string().optional(),
    limit: z.string().optional(),
    status: z.string().optional(),
    q: z.string().optional(),
    search: z.string().optional(),
    client_id: z.string().optional(),
    warehouse_id: z.string().optional(),
    agent_id: z.string().optional(),
    agent_ids: z.string().optional(),
    no_agent: z.string().optional(),
    expeditor_id: z.string().optional(),
    expeditor_user_id: z.string().optional(),
    client_category: z.string().optional(),
    client_region: z.string().optional(),
    client_city: z.string().optional(),
    client_zone: z.string().optional(),
    trade_direction: z.string().optional(),
    product_id: z.string().optional(),
    date_from: z.string().optional(),
    date_to: z.string().optional(),
    from: z.string().optional(),
    to: z.string().optional(),
    /** Bo‘shliqli oylar: `YYYY-MM-DD_YYYY-MM-DD,YYYY-MM-DD_YYYY-MM-DD` */
    date_periods: z.string().optional(),
    order_type: z.string().optional(),
    is_consignment: z.string().optional(),
    product_category_id: z.string().optional(),
    payment_type: z.string().optional(),
    payment_method_ref: z.string().optional(),
    request_type_ref: z.string().optional(),
    price_type: z.string().optional(),
    visit_weekday: z.string().optional(),
    date_mode: z.string().optional(),
    cursor: z.string().optional(),
    discount_alert: z.string().optional(),
    bonus_alert: z.string().optional(),
    order_alert: z.string().optional()
  })
  .transform((q) => {
    const ints = (raw?: string) =>
      [...new Set((raw ?? "").split(",").map((s) => Number.parseInt(s.trim(), 10)).filter((n) => Number.isFinite(n) && n > 0))];
    const whIds = ints(q.warehouse_id);
    const exIds = ints(q.expeditor_id ?? q.expeditor_user_id);
    const prIds = ints(q.product_id);
    const catIds = ints(q.product_category_id);
    const dayIds = ints(q.visit_weekday).filter((n) => n >= 1 && n <= 7);
    const pageNum = Math.max(1, Number.parseInt(q.page ?? "1", 10) || 1);
    const limitNum = Math.min(100, Math.max(1, Number.parseInt(q.limit ?? "30", 10) || 30));
    const search = (q.q ?? q.search ?? "").trim() || undefined;
    const noAgentRaw = q.no_agent?.trim().toLowerCase();
    const include_no_agent = noAgentRaw === "1" || noAgentRaw === "true" || noAgentRaw === "yes";
    const agent_ids = parseAgentIds(q.agent_ids) ?? (ints(q.agent_id).length > 1 ? ints(q.agent_id) : undefined);
    return {
      page: pageNum,
      limit: limitNum,
      status: q.status?.trim() || undefined,
      search,
      client_id: parseOptionalPosInt(q.client_id),
      warehouse_id: whIds.length === 1 ? whIds[0] : undefined,
      warehouse_ids: whIds.length > 1 ? whIds : undefined,
      agent_id: agent_ids?.length ? undefined : parseOptionalPosInt(q.agent_id),
      agent_ids,
      include_no_agent: include_no_agent || undefined,
      expeditor_user_id: exIds.length === 1 ? exIds[0] : undefined,
      expeditor_user_ids: exIds.length > 1 ? exIds : undefined,
      client_category: q.client_category?.trim() || undefined,
      client_region: q.client_region?.trim() || undefined,
      client_city: q.client_city?.trim() || undefined,
      client_zone: q.client_zone?.trim() || undefined,
      agent_trade_direction: q.trade_direction?.trim() || undefined,
      product_id: prIds.length === 1 ? prIds[0] : undefined,
      product_ids: prIds.length > 1 ? prIds : undefined,
      date_from: q.date_from?.trim() || q.from?.trim() || undefined,
      date_to: q.date_to?.trim() || q.to?.trim() || undefined,
      date_periods: q.date_periods?.trim() || undefined,
      order_type: q.order_type?.trim() || undefined,
      is_consignment: parseConsignmentFlag(q.is_consignment),
      product_category_id: catIds.length === 1 ? catIds[0] : undefined,
      product_category_ids: catIds.length > 1 ? catIds : undefined,
      payment_type: q.payment_type?.trim() || undefined,
      payment_method_ref: q.payment_method_ref?.trim() || undefined,
      request_type_ref: q.request_type_ref?.trim() || undefined,
      list_price_type: q.price_type?.trim() || undefined,
      visit_weekday: dayIds.length === 1 ? dayIds[0] : undefined,
      visit_weekdays: dayIds.length > 1 ? dayIds : undefined,
      date_mode: q.date_mode?.trim() || undefined,
      cursor: q.cursor?.trim() || undefined,
      discount_alert: q.discount_alert?.trim() || undefined,
      bonus_alert: q.bonus_alert?.trim() || undefined,
      order_alert: q.order_alert?.trim() || undefined
    };
  });

export type OrdersListQuery = z.infer<typeof ordersListQuerySchema>;

const orderIdsBulkSchema = z.array(z.number().int().positive()).min(1).max(500);

/** PATCH `/api/:slug/orders/:id/status` */
export const patchOrderStatusBodySchema = z.object({
  status: z.string().min(1),
  /** Holat logidagi vaqt (ISO 8601). Bo‘lmasa — hozir. */
  occurred_at: z.string().datetime({ offset: true }).optional(),
  /** Vazvrat (returned) sababi — ixtiyoriy yoki konfiguratsiyaga ko'ra majburiy. */
  reason: z.string().max(500).optional()
});

/** POST `/api/:slug/orders/bulk/status` */
export const bulkOrderStatusBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  status: z.string().min(1),
  occurred_at: z.string().datetime({ offset: true }).optional()
});

/** POST `/api/:slug/orders/bulk/details` — guruh jami / export */
export const bulkOrderDetailsBodySchema = z.object({
  order_ids: orderIdsBulkSchema
});

/** PATCH `/api/:slug/orders/:id/milestone-at` — mavjud bosqich log vaqtini tuzatish */
export const patchOrderMilestoneAtBodySchema = z.object({
  milestone: z.string().min(1),
  occurred_at: z.string().datetime({ offset: true })
});

/** 112 / 410 / 600 — «Загруз зав.склада» maydonlari */
export const warehouseExportOptionsSchema = z
  .object({
    sort_products: z.boolean().optional(),
    show_barcode: z.boolean().optional(),
    show_sku: z.boolean().optional(),
    show_load_date: z.boolean().optional(),
    show_agents: z.boolean().optional(),
    show_territory: z.boolean().optional(),
    show_expeditor: z.boolean().optional(),
    show_agent_phone: z.boolean().optional(),
    products_by_order_only: z.boolean().optional(),
    show_product_id: z.boolean().optional(),
    show_product_code: z.boolean().optional(),
    show_product_price: z.boolean().optional()
  })
  .optional();

/** POST `/api/:slug/orders/bulk/nakladnoy` */
export const bulkOrderNakladnoyBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  template: z.enum(["nakladnoy_warehouse", "nakladnoy_expeditor"]),
  /** «Загруз зав.склада» — 13 ta alohida Excel andoza */
  warehouse_layout: z
    .enum([
      "wh-1.1",
      "wh-1.1.2",
      "wh-4.1",
      "wh-4.1.1",
      "wh-4.1.2",
      "wh-6.0",
      "wh-6.0.1",
      "wh-6.0.2",
      "wh-7.0.0",
      "wh-7.0.1",
      "wh-xprinter",
      "wh-7.0.3",
      "wh-7.0.4"
    ])
    .optional(),
  /** «Загруз экспедитор» */
  expeditor_loading_layout: z
    .enum([
      "ex-2.0",
      "ex-3.0",
      "ex-4.0.1",
      "ex-5.1.1",
      "ex-5.1.2",
      "ex-5.1.3",
      "ex-5.1.4",
      "ex-5.1.5",
      "ex-5.1.6",
      "ex-5.1.7",
      "ex-5.1.8",
      "ex-5.1.9",
      "ex-5.2.0"
    ])
    .optional(),
  format: z.enum(["xlsx", "pdf"]).optional(),
  code_column: z.enum(["sku", "barcode"]).optional(),
  separate_sheets: z.boolean().optional(),
  group_by: z.enum(["territory", "agent", "expeditor"]).optional(),
  warehouse_export_options: warehouseExportOptionsSchema
});

/** POST `/api/:slug/orders/bulk/nakladnoy/preview` — virtual ko‘rinish (barcha nakladnoy shablonlari) */
export const bulkOrderNakladnoyPreviewBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  template: z.enum(["nakladnoy_warehouse", "nakladnoy_expeditor"]),
  label: z.string().min(1).max(120),
  warehouse_layout: z
    .enum([
      "wh-1.1",
      "wh-1.1.2",
      "wh-4.1",
      "wh-4.1.1",
      "wh-4.1.2",
      "wh-6.0",
      "wh-6.0.1",
      "wh-6.0.2",
      "wh-7.0.0",
      "wh-7.0.1",
      "wh-xprinter",
      "wh-7.0.3",
      "wh-7.0.4"
    ])
    .optional(),
  expeditor_loading_layout: z
    .enum([
      "ex-2.0",
      "ex-3.0",
      "ex-4.0.1",
      "ex-5.1.1",
      "ex-5.1.2",
      "ex-5.1.3",
      "ex-5.1.4",
      "ex-5.1.5",
      "ex-5.1.6",
      "ex-5.1.7",
      "ex-5.1.8",
      "ex-5.1.9",
      "ex-5.2.0"
    ])
    .optional(),
  code_column: z.enum(["sku", "barcode"]).optional(),
  separate_sheets: z.boolean().optional(),
  group_by: z.enum(["territory", "agent", "expeditor"]).optional(),
  warehouse_export_options: warehouseExportOptionsSchema
});

/** POST `/api/:slug/orders/bulk/nakladnoy/loading-520` — 5.2.0 Excel (preview bilan bir xil hujjat) */
export const bulkOrderLoading520BodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  code_column: z.enum(["sku", "barcode"]).optional(),
  separate_sheets: z.boolean().optional(),
  group_by: z.enum(["territory", "agent", "expeditor"]).optional()
});

const expeditorLoadingLayoutEnum = z.enum([
  "ex-2.0",
  "ex-3.0",
  "ex-4.0.1",
  "ex-5.1.1",
  "ex-5.1.2",
  "ex-5.1.3",
  "ex-5.1.4",
  "ex-5.1.5",
  "ex-5.1.6",
  "ex-5.1.7",
  "ex-5.1.8",
  "ex-5.1.9",
  "ex-5.2.0"
]);

/** POST `/api/:slug/orders/bulk/nakladnoy/expeditor-loading` — shablon Excel (preview bilan bir xil buffer) */
export const bulkOrderExpeditorLoadingBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  expeditor_loading_layout: expeditorLoadingLayoutEnum,
  code_column: z.enum(["sku", "barcode"]).optional(),
  separate_sheets: z.boolean().optional(),
  group_by: z.enum(["territory", "agent", "expeditor"]).optional()
});

/** POST `/api/:slug/orders/bulk/expeditor` */
export const bulkOrderExpeditorBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  /** null — ekspeditordan yechish */
  expeditor_user_id: z.number().int().positive().nullable()
});

/** POST `/api/:slug/orders/bulk/consignment` */
export const bulkOrderConsignmentBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  is_consignment: z.boolean(),
  consignment_due_date: z.string().max(40).optional().nullable(),
  /** Shartlar / sabab — kommentariyaga va change log ga yoziladi */
  conditions_note: z.string().trim().max(2000).optional().nullable()
});

export const consignmentTransfersListQuerySchema = z.object({
  date_from: z.string().trim().min(8).max(40),
  date_to: z.string().trim().min(8).max(40),
  search: z.string().trim().max(120).optional(),
  page: z.coerce.number().int().min(1).default(1),
  page_size: z.coerce.number().int().min(1).max(200).default(50)
});

export const CONSIGNMENT_COMMENT_FIELD_KEYS = [
  "order_number",
  "client",
  "agent",
  "expeditor",
  "payment_method",
  "total_sum",
  "delivered_at",
  "days_overdue",
  "unpaid",
  "conditions"
] as const;

export const consignmentAutoSettingsPatchSchema = z.object({
  days_after_delivered: z.number().int().min(1).max(365).optional(),
  comment_fields: z.array(z.enum(CONSIGNMENT_COMMENT_FIELD_KEYS)).min(1).max(20).optional()
});

export const consignmentAutoCandidatesQuerySchema = z.object({
  search: z.string().trim().max(120).optional(),
  page: z.coerce.number().int().min(1).default(1),
  page_size: z.coerce.number().int().min(1).max(200).default(50),
  days_after_delivered: z.coerce.number().int().min(1).max(365).optional()
});

export const consignmentAutoConvertBodySchema = z.object({
  order_ids: orderIdsBulkSchema,
  comment_fields: z.array(z.enum(CONSIGNMENT_COMMENT_FIELD_KEYS)).min(1).max(20),
  conditions_note: z.string().trim().max(2000).optional().nullable(),
  consignment_due_date: z.string().max(40).optional().nullable(),
  save_comment_fields: z.boolean().optional()
});

/** PATCH `/api/:slug/orders/:id/lines` */
export const patchOrderLinesBodySchema = z.object({
  warehouse_id: z.number().int().positive().nullable().optional(),
  agent_id: z.number().int().positive().nullable().optional(),
  payment_method_ref: z.string().trim().max(64).optional().nullable(),
  /** Narx turi — tahrirda qayta hisoblash va `orders.price_type` ga saqlanadi. */
  price_type: z.string().trim().min(1).max(128).optional(),
  apply_bonus: z.boolean().optional(),
  /** `false` — chegirma qo‘llanmaydi (bonus yoqilgan bo‘lsa ham). */
  apply_discount: z.boolean().optional(),
  bonus_gift_overrides: z.array(bonusGiftOverrideSchema).optional(),
  /** Qty bonus: bir qoida uchun bir nechta mahsulot/dona (web tahrir tasdiqlash). */
  bonus_gift_lines: z.array(bonusGiftLineSchema).optional(),
  bonus_strategy_selections: z
    .array(
      z.object({
        strategy_id: z.number().int().positive(),
        rule_ids: z.array(z.number().int().positive()).min(1).max(200)
      })
    )
    .max(50)
    .optional(),
  items: z.array(orderLineItemSchema).min(1)
});

/** POST `/api/:slug/orders/bonus-preview` — web tahrir (agent_id majburiy). */
export const orderBonusPreviewBodySchema = z.object({
  client_id: z.number().int().positive(),
  warehouse_id: z.number().int().positive(),
  agent_id: z.number().int().positive(),
  price_type: z.string().trim().min(1).max(128).optional(),
  items: z.array(orderLineItemSchema).min(1),
  bonus_gift_overrides: z.array(bonusGiftOverrideSchema).optional(),
  is_consignment: z.boolean().optional(),
  exclude_order_id: z.number().int().positive().optional(),
  bonus_strategy_selections: z
    .array(
      z.object({
        strategy_id: z.number().int().positive(),
        rule_ids: z.array(z.number().int().positive()).min(1).max(200)
      })
    )
    .max(50)
    .optional()
});

/** POST `/api/:slug/orders/bulk/bonus-refresh` — «Новый» zakazlarda yangi bonus mexanizmi. */
export const bulkOrderBonusRefreshBodySchema = z.object({
  order_ids: orderIdsBulkSchema
});

/** PATCH `/api/:slug/orders/:id` meta maydonlari */
export const patchOrderMetaBodySchema = z
  .object({
    warehouse_id: z.number().int().positive().nullable().optional(),
    agent_id: z.number().int().positive().nullable().optional(),
    expeditor_user_id: z.number().int().positive().nullable().optional(),
    comment: z.string().max(4000).optional().nullable(),
    payment_method_ref: z.string().trim().max(64).optional().nullable(),
    warehouse_block_id: z.number().int().positive().nullable().optional()
  })
  .refine(
    (b) =>
      b.warehouse_id !== undefined ||
      b.agent_id !== undefined ||
      b.expeditor_user_id !== undefined ||
      b.comment !== undefined ||
      b.payment_method_ref !== undefined ||
      b.warehouse_block_id !== undefined,
    {
      message:
        "Укажите хотя бы одно поле: warehouse_id, agent_id, expeditor_user_id, comment, payment_method_ref, warehouse_block_id"
    }
  );
