import type { Job } from "bullmq";
import { readFile, unlink } from "fs/promises";
import type { OrderStatusNotifyJobData } from "../modules/jobs/jobs.service";
import { importClientsFromXlsx } from "../modules/clients/clients.service";
import { humanizeImportDbError } from "../modules/clients/clients.import.runtime";
import { notifyOrderParticipantsStatusChange } from "../modules/notifications/notifications.service";
import { importProductPricesFromXlsx } from "../modules/products/product-prices.service";
import {
  importProductsCatalogUpdateOnlyXlsx,
  importProductsFromCatalogTemplateXlsx,
  importProductsFromXlsx
} from "../modules/products/products.service";
import { importStockReceiptFromXlsx } from "../modules/stock/stock.service";
import { isSafeImportTempPath } from "./import-temp-file";

export type ImportClientsXlsxJobData = {
  tenant_id: number;
  requested_by_user_id: number;
  file_path: string;
  sheetName?: string;
  headerRowIndex?: number;
  columnMap?: Record<string, number>;
  importMode?: "create" | "update";
  duplicateKeyFields?: string[];
  updateApplyFields?: string[];
  commitDecision?: "accept_valid" | "reject_all";
};

export type ImportStockXlsxJobData = {
  tenant_id: number;
  actor_user_id: number | null;
  file_path: string;
  defaultWarehouseId?: number;
};

export type ImportProductsXlsxJobData = {
  tenant_id: number;
  actor_user_id: number | null;
  file_path: string;
};

export type ImportProductPricesXlsxJobData = ImportProductsXlsxJobData;

export async function processBackgroundJob(job: Job): Promise<unknown> {
  if (job.name === "ping") {
    return { ok: true, at: new Date().toISOString() };
  }

  if (job.name === "order_status_notify") {
    const d = job.data as OrderStatusNotifyJobData;
    await notifyOrderParticipantsStatusChange(d);
    return { ok: true };
  }

  if (job.name === "payroll_recalc") {
    const { processPayrollRecalcJob } = await import("../modules/payroll/payroll.jobs");
    return processPayrollRecalcJob(job.data as import("../modules/payroll/payroll.jobs").PayrollRecalcJobData);
  }

  if (job.name === "payroll_sweep") {
    const { processPayrollSweepJob } = await import("../modules/payroll/payroll.jobs");
    return processPayrollSweepJob(job.data as import("../modules/payroll/payroll.jobs").PayrollSweepJobData);
  }

  if (job.name === "order_auto_confirm") {
    const d = job.data as import("../modules/order-automation/order-automation.jobs").OrderAutoConfirmJobData;
    const { executeAutoConfirmSchedule } = await import(
      "../modules/order-automation/order-automation.auto-confirm"
    );
    await executeAutoConfirmSchedule(d.tenant_id, d.schedule_id);
    return { ok: true };
  }

  if (job.name === "import_clients_xlsx") {
    const d = job.data as ImportClientsXlsxJobData;
    const fp = d.file_path;
    if (typeof fp !== "string" || !fp || !isSafeImportTempPath(fp)) {
      throw new Error("Неверный путь к файлу импорта");
    }
    try {
      const buf = await readFile(fp);
      return await importClientsFromXlsx(d.tenant_id, buf, {
        sheetName: d.sheetName,
        headerRowIndex: d.headerRowIndex,
        columnMap: d.columnMap,
        importMode: d.importMode,
        duplicateKeyFields: d.duplicateKeyFields,
        updateApplyFields: d.updateApplyFields,
        commitDecision: d.commitDecision,
        actorUserId: d.requested_by_user_id ?? null,
        onProgress: async (progress) => {
          await job.updateProgress(progress);
        }
      });
    } catch (e) {
      throw new Error(humanizeImportDbError(e));
    } finally {
      await unlink(fp).catch(() => {});
    }
  }

  if (job.name === "import_stock_xlsx") {
    const d = job.data as ImportStockXlsxJobData;
    const fp = d.file_path;
    if (typeof fp !== "string" || !fp || !isSafeImportTempPath(fp)) {
      throw new Error("Неверный путь к файлу импорта");
    }
    try {
      const buf = await readFile(fp);
      return await importStockReceiptFromXlsx(
        d.tenant_id,
        buf,
        d.actor_user_id ?? null,
        d.defaultWarehouseId != null ? { defaultWarehouseId: d.defaultWarehouseId } : undefined
      );
    } finally {
      await unlink(fp).catch(() => {});
    }
  }

  if (
    job.name === "import_products_xlsx" ||
    job.name === "import_products_catalog_xlsx" ||
    job.name === "import_products_catalog_update_xlsx"
  ) {
    const d = job.data as ImportProductsXlsxJobData;
    const fp = d.file_path;
    if (typeof fp !== "string" || !fp || !isSafeImportTempPath(fp)) {
      throw new Error("Неверный путь к файлу импорта");
    }
    const actor = d.actor_user_id ?? null;
    try {
      const buf = await readFile(fp);
      if (job.name === "import_products_xlsx") {
        return await importProductsFromXlsx(d.tenant_id, buf, actor);
      }
      if (job.name === "import_products_catalog_xlsx") {
        return await importProductsFromCatalogTemplateXlsx(d.tenant_id, buf, actor);
      }
      return await importProductsCatalogUpdateOnlyXlsx(d.tenant_id, buf, actor);
    } finally {
      await unlink(fp).catch(() => {});
    }
  }

  if (job.name === "import_product_prices_xlsx") {
    const d = job.data as ImportProductPricesXlsxJobData;
    const fp = d.file_path;
    if (typeof fp !== "string" || !fp || !isSafeImportTempPath(fp)) {
      throw new Error("Неверный путь к файлу импорта");
    }
    try {
      const buf = await readFile(fp);
      return await importProductPricesFromXlsx(d.tenant_id, buf, d.actor_user_id ?? null);
    } finally {
      await unlink(fp).catch(() => {});
    }
  }

  if (job.name === "import_system_migration_backup") {
    const d = job.data as {
      tenant_id: number;
      actor_user_id: number | null;
      file_path: string;
      force_nonempty?: boolean;
      mode?: "full" | "profile_only";
      conflict_policy?: "keep" | "replace";
      modules?: string[];
    };
    const fp = d.file_path;
    if (typeof fp !== "string" || !fp || !isSafeImportTempPath(fp)) {
      throw new Error("Неверный путь к файлу импорта");
    }
    try {
      const buf = await readFile(fp);
      const { applyBackupZip } = await import("../modules/system-migration/system-migration.import");
      return await applyBackupZip(buf, d.tenant_id, {
        force_nonempty: d.force_nonempty ?? false,
        mode: d.mode ?? "full",
        conflict_policy: d.conflict_policy === "replace" ? "replace" : "keep",
        modules: Array.isArray(d.modules) ? d.modules : undefined,
        actorUserId: d.actor_user_id ?? null,
        onProgress: async (p) => {
          await job.updateProgress({
            stage: p.stage,
            percent: p.percent,
            message: p.message
          });
        }
      });
    } finally {
      await unlink(fp).catch(() => {});
    }
  }

  if (job.name === "export_excel") {
    const d = job.data as { tenant_id?: number; report_key?: string };
    return { ok: true, kind: "export_excel", tenant_id: d.tenant_id ?? null, report_key: d.report_key ?? null };
  }

  if (job.name === "generate_pdf") {
    const d = job.data as { tenant_id?: number; order_id?: number };
    return { ok: true, kind: "generate_pdf", tenant_id: d.tenant_id ?? null, order_id: d.order_id ?? null };
  }

  if (job.name === "cleanup_old_logs") {
    return { ok: true, kind: "cleanup_old_logs", at: new Date().toISOString() };
  }

  if (job.name === "tabel_retention_purge") {
    const { purgeTabelMediaAndFaces } = await import("../modules/tabel/tabel-media-telegram.service");
    const d = (job.data ?? {}) as { tenant_id?: number };
    return purgeTabelMediaAndFaces(d.tenant_id);
  }

  if (job.name === "tabel_shift_close_sweep") {
    const { closeEndedShiftsAndMarkAbsent } = await import("../modules/tabel/tabel-shift-close.service");
    const d = (job.data ?? {}) as { tenant_id?: number };
    return closeEndedShiftsAndMarkAbsent(d.tenant_id);
  }

  {
    const { processCronBackgroundJob } = await import("./cron-repeatable");
    const cronResult = await processCronBackgroundJob(job.name);
    if (cronResult != null) return cronResult;
  }

  throw new Error(`Неизвестная задача: ${job.name}`);
}
