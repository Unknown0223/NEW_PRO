# SALEC — Taklifiy reja moduli (to‘liq kod)

Branch: arena/8d9c1cbf-new-pro
Sana: 2026-11-15

## Ichida
- `packages/plans-proposal/` — framework-free hisoblash yadrosi + 32 test.
- `packages/plans-proposal-demo/` — React/Vite web demo, 28 unit + 17 E2E test,
  KPI ustunli draft va natijalar matritsalari, audit, backtest, shared draft.
- `docs/` — texnik/biznes hujjatlar, jumladan
  `docs/PLANS_TAKLIFIY_REJA_ANALIZ_VA_REJA.md`.
- `scripts/`, `.github/`, root `package.json` + `package-lock.json` va config
  fayllari — `npm install` va skriptlar ishlashi uchun.

## Ishga tushirish
```bash
npm install
npm run plans:proposal:demo
npm run plans:proposal:test
npm run test:e2e --workspace=@salec/plans-proposal-demo
```

Port 5175, host 0.0.0.0, `allowedHosts: [".e2b.app"]`.
`public/yuklab-olish.html` orqali ZIP larni brauzerdan yuklab olish mumkin.
`node_modules/`, `dist/`, `test-results/` va katta binarylar zipga kiritilmadi.
