"""
Worklyn Link — terminal one-shot (silka → admin parol → lokatsiya → avto).

Faqat 3 ta so‘rov; qolgani ketma-ket avtomatik.
"""
from __future__ import annotations

import argparse
import getpass
import json
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


def _info(msg: str) -> None:
    print(msg, flush=True)


def _ok(msg: str) -> None:
    print(f"  ✓ {msg}", flush=True)


def _warn(msg: str) -> None:
    print(f"  ! {msg}", flush=True)


def _err(msg: str) -> None:
    print(f"  ✗ {msg}", flush=True)


def _prompt(label: str, *, secret: bool = False, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    text = f"{label}{suffix}: "
    if secret:
        raw = getpass.getpass(text)
    else:
        try:
            raw = input(text)
        except EOFError:
            raw = ""
    value = (raw or "").strip()
    return value or default


def _derive_api_web(silka: str) -> tuple[str, str]:
    """From one server URL build apiUrl + webUrl."""
    raw = (silka or "").strip().rstrip("/")
    if not raw:
        return "", ""
    if "://" not in raw:
        raw = "https://" + raw
    low = raw.lower()
    # Explicit API host
    if "api" in urlparse(raw).hostname or raw.rstrip("/").endswith(":3002"):
        api = raw
        web = (
            raw.replace("hr-hubapi", "hr-hubweb")
            .replace("-api.", "-web.")
            .replace("/api", "")
            .replace(":3002", ":3001")
        )
        if web == api:
            web = raw.replace(":3002", ":3001")
        return api.rstrip("/"), web.rstrip("/")
    # Web host → API sibling (Railway naming + local ports)
    web = raw
    api = (
        raw.replace("hr-hubweb", "hr-hubapi")
        .replace("-web.", "-api.")
        .replace(":3001", ":3002")
    )
    if api == web and "localhost" in low:
        api = "http://127.0.0.1:3002"
        web = "http://127.0.0.1:3001"
    elif api == web:
        # Same host: API often on / or separate — keep same origin; Nest is separate service
        api = web
    return api.rstrip("/"), web.rstrip("/")


def _apply_silka(root: Path, silka: str) -> dict[str, Any]:
    from paths import (
        _decode_connection_hrhub,
        connection_file,
        write_config_urls,
        write_pairing_token,
    )

    text = (silka or "").strip()
    if not text:
        raise SystemExit("Silka bo‘sh.")

    # connection.hrhub (signed bind)
    decoded = _decode_connection_hrhub(text)
    if decoded and isinstance(decoded.get("payload"), dict):
        connection_file(root).write_text(text.strip() + "\n", encoding="utf-8")
        p = decoded["payload"]
        cfg = write_config_urls(
            api_url=str(p.get("apiUrl") or ""),
            web_url=str(p.get("webUrl") or ""),
            tenant_code=str(p.get("tenantCode") or ""),
            root=root,
        )
        _ok(f"connection.hrhub: {cfg.get('webUrl')} · tenant={cfg.get('tenantCode')}")
        return cfg

    # Pairing token (no URL)
    if "://" not in text and len(text) >= 16 and " " not in text and not text.endswith(".app"):
        write_pairing_token(text, root)
        _ok("Pairing token saqlandi")
        from paths import load_config

        return load_config(root)

    # URL (+ optional tenant after space or | )
    tenant = ""
    url_part = text
    for sep in ("|", " ", ";"):
        if sep in text and text.lower().startswith("http"):
            # only split once from the right-ish: first token URL
            bits = text.replace(";", "|").replace(" ", "|").split("|")
            bits = [b.strip() for b in bits if b.strip()]
            if bits:
                url_part = bits[0]
                if len(bits) > 1:
                    tenant = bits[1]
            break

    api, web = _derive_api_web(url_part)
    if not api:
        raise SystemExit("Silka URL emas.")
    cfg = write_config_urls(
        api_url=api,
        web_url=web,
        tenant_code=tenant or None,
        root=root,
    )
    # Drop stale bound pack so manual URLs win
    try:
        connection_file(root).unlink(missing_ok=True)
    except OSError:
        pass
    _ok(f"Web: {cfg.get('webUrl')}")
    _ok(f"API: {cfg.get('apiUrl')}")
    return cfg


def _list_locations(session) -> list[dict[str, Any]]:
    import api_client
    from paths import read_link_key

    code, data = api_client.list_locations(
        session.api_url,
        read_link_key(session.root),
        session.tenant,
        pairing_token=session.pairing_token() or None,
    )
    if not api_client.is_success(code) or not isinstance(data, dict):
        msg = ""
        if isinstance(data, dict):
            msg = str(data.get("message") or data.get("error") or "")
        raise RuntimeError(msg or f"Lokatsiyalar olinmadi (HTTP {code})")
    raw = data.get("locations") or data.get("items") or data.get("data") or []
    items: list[dict[str, Any]] = []
    if isinstance(raw, list):
        for row in raw:
            if not isinstance(row, dict):
                continue
            lid = str(row.get("id") or "").strip()
            if not lid:
                continue
            name = str(row.get("name") or row.get("title") or lid).strip()
            items.append({"id": lid, "name": name, **row})
    return items


def _pick_location(items: list[dict[str, Any]], preset: str = "") -> str:
    if not items:
        raise RuntimeError("Lokatsiya ro‘yxati bo‘sh — Webda lokatsiya yarating.")
    if preset:
        for it in items:
            if it["id"] == preset or it["name"].lower() == preset.lower():
                return it["id"]
        raise RuntimeError(f"Lokatsiya topilmadi: {preset}")
    _info("")
    _info("Lokatsiyalar:")
    for i, it in enumerate(items, 1):
        print(f"  {i}) {it['name']}", flush=True)
    while True:
        raw = _prompt("Lokatsiya raqami", default="1")
        try:
            idx = int(raw)
        except ValueError:
            # name match
            for it in items:
                if it["name"].lower() == raw.lower() or it["id"] == raw:
                    return it["id"]
            _warn("Raqam yoki nom kiriting.")
            continue
        if 1 <= idx <= len(items):
            return items[idx - 1]["id"]
        _warn("Noto‘g‘ri raqam.")


def _pick_device(session, password: str) -> None:
    devices = session.scan()
    if not devices:
        raise RuntimeError("LAN da Hikvision topilmadi. Qurilma va kompyuter bir tarmoqda bo‘lsin.")
    _ok(f"Topildi: {len(devices)} ta qurilma")
    results, match, reason = session.match_password_on_lan(password, devices=devices)
    if match is not None:
        _ok(f"Parol mos: {match.host}")
        return
    # Show probes and let user pick a matching host if several
    ok_hosts = [r for r in results if r.ok]
    if len(ok_hosts) == 1:
        session.select_scanned_host(ok_hosts[0].host, ok_hosts[0].port)
        session.password = password
        _ok(f"Tanlandi: {ok_hosts[0].host}")
        return
    if len(ok_hosts) > 1:
        _info("Bir nechta qurilmada parol mos keldi:")
        for i, r in enumerate(ok_hosts, 1):
            print(f"  {i}) {r.label()}", flush=True)
        raw = _prompt("Qurilma raqami", default="1")
        try:
            idx = int(raw)
        except ValueError:
            idx = 1
        if not (1 <= idx <= len(ok_hosts)):
            idx = 1
        chosen = ok_hosts[idx - 1]
        session.select_scanned_host(chosen.host, chosen.port)
        session.password = password
        return
    # No password match — if exactly one device, still select and verify explicitly
    if len(devices) == 1:
        session.chosen = devices[0]
        from discovery import OK

        res = session.submit_password(password)
        if res.kind != OK:
            raise RuntimeError(res.message or "Admin parol qurilmaga mos kelmadi.")
        _ok(f"Tasdiqlandi: {devices[0].host}")
        return
    _info("Qurilmalar (parol mos kelmadi — raqam tanlang, keyin qayta uriniladi):")
    for i, d in enumerate(devices, 1):
        print(f"  {i}) {d.host}  {getattr(d, 'name', '') or ''}", flush=True)
    raw = _prompt("Qurilma raqami", default="1")
    try:
        idx = int(raw)
    except ValueError:
        idx = 1
    if not (1 <= idx <= len(devices)):
        idx = 1
    session.chosen = devices[idx - 1]
    from discovery import OK

    res = session.submit_password(password)
    if res.kind != OK:
        raise RuntimeError(res.message or "Admin parol qurilmaga mos kelmadi.")
    _ok(f"Tasdiqlandi: {session.chosen.host}")


def _status(msg: str) -> None:
    print(f"    … {msg}", flush=True)


def run_connect(
    *,
    root: Path | None = None,
    silka: str = "",
    admin_parol: str = "",
    location: str = "",
    tenant: str = "",
) -> int:
    from paths import find_root, load_config, write_config_urls, write_link_key
    from session import OfficeLinkSession
    import api_client

    root = root or find_root()
    _info("")
    _info("══ Worklyn Link — terminal ulash ══")
    _info("")

    # ── 1) Silka ──────────────────────────────────────────────
    _info("[1/6] Server silka")
    if not silka:
        silka = _prompt(
            "Silka (Web URL, connection.hrhub yoki pairing token)"
        )
    cfg = _apply_silka(root, silka)
    if tenant:
        cfg = write_config_urls(tenant_code=tenant, root=root)
    if not str(cfg.get("tenantCode") or "").strip() or cfg.get("tenantCode") == "demo":
        # Soft prompt only when still demo / empty after silka
        if not tenant and not cfg.get("bound"):
            t = _prompt("Tenant kodi", default=str(cfg.get("tenantCode") or "demo"))
            if t:
                cfg = write_config_urls(tenant_code=t, root=root)

    # ── 2) Admin parol ────────────────────────────────────────
    _info("")
    _info("[2/6] Admin parol")
    if not admin_parol:
        admin_parol = _prompt(
            "Admin parol (qurilma + ixtiyoriy ulanish kaliti)",
            secret=True,
        )
    if not admin_parol:
        _err("Admin parol kerak.")
        return 2

    # Admin parol = qurilma paroli. Agar server ping qabul qilsa — link.key ham.
    session = OfficeLinkSession(root=root)
    session.cfg = load_config(root)
    session.password = admin_parol

    code, data = api_client.ping(
        session.api_url,
        admin_parol,
        session.tenant,
        pairing_token=session.pairing_token() or None,
    )
    if api_client.is_success(code):
        write_link_key(admin_parol, root)
        session = OfficeLinkSession(root=root)
        session.cfg = load_config(root)
        session.password = admin_parol
        _ok("Server ulanishi OK (admin kaliti / pairing)")
    else:
        from paths import read_link_key

        if session.pairing_token() or read_link_key(root):
            _warn("Yangi kalit bilan ping yo‘q — mavjud pairing/link.key bilan davom.")
        else:
            # Last resort: still store so locations API can try X-Device-Link-Key
            write_link_key(admin_parol, root)
            session = OfficeLinkSession(root=root)
            session.cfg = load_config(root)
            session.password = admin_parol
            msg = ""
            if isinstance(data, dict):
                msg = str(data.get("message") or data.get("error") or "")
            _warn(
                f"Server ping: HTTP {code} {msg}. "
                "Lokatsiya uchun DEVICE_LINK_KEY yoki pairing token kerak bo‘lishi mumkin."
            )

    # ── 3) Lokatsiya ──────────────────────────────────────────
    _info("")
    _info("[3/6] Lokatsiya")
    try:
        locs = _list_locations(session)
    except Exception as e:
        _err(str(e))
        return 3
    loc_id = _pick_location(locs, preset=location)
    session.set_location_id(loc_id)
    loc_name = next((x["name"] for x in locs if x["id"] == loc_id), loc_id)
    _ok(f"Lokatsiya: {loc_name}")

    # ── 4) LAN + parol ────────────────────────────────────────
    _info("")
    _info("[4/6] Qurilmani qidirish")
    try:
        _pick_device(session, admin_parol)
    except Exception as e:
        _err(str(e))
        return 4

    # Pairing bind (may receive link.key from server)
    if session.pairing_token():
        ok, msg = session.bind_pairing_session()
        if ok:
            _ok("Pairing sessiyasi bog‘landi")
        else:
            _warn(msg or "Pairing bind o‘tmadi — davom etiladi")

    # ── 5) Provision ──────────────────────────────────────────
    _info("")
    _info("[5/6] Platformaga ulash")
    result = session.link_to_cloud(on_status=_status)
    success_kinds = {
        "linked",
        "ok",
        "done",
        "registered",
        "sealed",
        "waiting_confirm",
        "waiting_admin",
        "provisioned",
        "tunnel_ok",
    }
    if result.kind not in success_kinds and not (
        isinstance(result.device, dict) and (result.device.get("id") or result.device.get("host"))
    ):
        _err(result.message or f"Ulash xatosi ({result.kind})")
        return 5
    _ok(result.message or "Ulash yakunlandi")
    if result.device:
        did = result.device.get("id") or result.device.get("deviceId")
        if did:
            _ok(f"Device id: {did}")

    # ── 6) Tunnel + background ────────────────────────────────
    _info("")
    _info("[6/6] Tunnel va fon xizmati")
    try:
        session.write_service_handoff()
        tun = session.restore_tunnel(on_status=_status)
        if tun.kind == "tunnel_ok":
            _ok(tun.message or "Tunnel OK")
        else:
            _warn(tun.message or "Tunnel hozir ochilmadi — keyinroq GUI dan tiklanadi")
        if session.ensure_tunnel_supervisor():
            _ok("Fon worker ishga tushdi")
        else:
            _warn("Fon worker yoqilmadi — BOSHLASH.bat yoki xizmatni tekshiring")
    except Exception as e:
        _warn(f"Tunnel: {e}")

    _info("")
    _info("══ Tayyor ══")
    _info(f"  Web:      {session.web_url}")
    _info(f"  Tenant:   {session.tenant}")
    _info(f"  Lokatsiya:{loc_name}")
    if session.chosen:
        _info(f"  Qurilma:  {session.chosen.host}")
    _info("")

    # Optional face sync right after Ulash (same helper as `worklyn sync`).
    ans = _prompt("Yuzlarni hozir sync qilaymi? (y/n)", default="y").lower()
    if ans in ("y", "yes", "ha", "1"):
        return run_sync(root=root, clock=True)
    return 0


def run_sync(
    *,
    root: Path | None = None,
    force: bool = False,
    failed_only: bool = False,
    clock: bool = False,
    no_queue: bool = False,
) -> int:
    from face_sync import run_face_sync, snapshot_progress, sync_clock_local
    from paths import find_root

    root = root or find_root()
    _info("")
    _info("══ Worklyn Link — sinhron ══")
    snap = snapshot_progress(root)
    if not snap.get("deviceId"):
        _err(snap.get("message") or "Avval ulash (worklyn / Ulash) qiling.")
        return 2
    _ok(f"Device: {snap.get('deviceId')} · {snap.get('host') or '—'}")

    if clock:
        _info("[vaqt] Terminal soati…")
        cr = sync_clock_local(root)
        if cr.get("ok"):
            _ok(cr.get("message") or "Vaqt OK")
        else:
            _err(cr.get("message") or "Vaqt xato")
            return 3

    def on_progress(p: dict) -> None:
        pct = int(p.get("percent") or 0)
        syn = int(p.get("synced") or 0)
        tot = int(p.get("total") or 0)
        pend = int(p.get("pending") or 0) + int(p.get("syncing") or 0)
        msg = str(p.get("message") or "")[:80]
        mode = str(p.get("mode") or "")
        line = f"\r  [{pct:3d}%] {syn}/{tot or '?'}  navbat={pend}  {mode}  {msg}    "
        print(line, end="", flush=True)
        if p.get("done"):
            print("", flush=True)

    _info("[yuzlar] Navbat + LAN agent…")
    result = run_face_sync(
        root,
        force=force,
        failed_only=failed_only,
        queue=not no_queue,
        on_progress=on_progress,
    )
    print("", flush=True)
    if result.get("ok"):
        _ok(result.get("message") or "Sync tayyor")
        return 0
    _err(result.get("message") or "Sync xato")
    return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="worklyn", description="Worklyn Link terminal")
    parser.add_argument(
        "command",
        nargs="?",
        default="connect",
        choices=["connect", "sync", "status"],
        help="connect | sync | status",
    )
    parser.add_argument("--silka", default="", help="Web URL / connection.hrhub / pairing token")
    parser.add_argument("--admin-parol", default="", help="Qurilma admin paroli (va/yoki link key)")
    parser.add_argument("--location", default="", help="Lokatsiya id yoki nomi")
    parser.add_argument("--tenant", default="", help="Tenant kodi")
    parser.add_argument("--root", default="", help="O‘rnatish papkasi")
    parser.add_argument("--force", action="store_true", help="sync: barcha yuzlarni qayta")
    parser.add_argument("--failed-only", action="store_true", help="sync: faqat xatolar")
    parser.add_argument("--clock", action="store_true", help="sync: terminal vaqtini ham")
    parser.add_argument("--no-queue", action="store_true", help="sync: faqat mavjud navbatni drain")
    args = parser.parse_args(argv)
    root = Path(args.root) if args.root else None
    try:
        if args.command == "status":
            from face_sync import snapshot_progress
            from paths import find_root

            p = snapshot_progress(root or find_root())
            print(json.dumps(p, ensure_ascii=False, indent=2))
            return 0 if p.get("ok") or p.get("deviceId") else 1
        if args.command == "sync":
            return run_sync(
                root=root,
                force=args.force,
                failed_only=args.failed_only,
                clock=args.clock,
                no_queue=args.no_queue,
            )
        return run_connect(
            root=root,
            silka=args.silka,
            admin_parol=args.admin_parol,
            location=args.location,
            tenant=args.tenant,
        )
    except KeyboardInterrupt:
        _err("Bekor qilindi.")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
