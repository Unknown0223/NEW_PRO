"""Device state detection and provision flows (Faza 1 + best-effort Faza 3.1).

Client-side heuristics — factory activation is best-effort only (not all models).
"""
from __future__ import annotations

import socket
from typing import Any, Callable

from discovery import (
    ERROR,
    OK,
    TIMEOUT,
    UNAUTHORIZED,
    _http_get,
    _http_request,
    classify_probe,
    parse_device_payload,
    verify_password,
)
from paths import read_link_key

StatusFn = Callable[[str], None]

STATE_NEW = "new"
STATE_CONFIGURED = "configured"
STATE_UNKNOWN = "unknown"

STATE_LABELS_UZ = {
    STATE_NEW: "Новое",
    STATE_CONFIGURED: "Есть admin",
    STATE_UNKNOWN: "Неизвестно",
}


def _is_local_api(api_url: str) -> bool:
    """True when API is on this PC — Cloudflare quick tunnel not required."""
    raw = (api_url or "").strip().lower()
    if not raw:
        return False
    try:
        from urllib.parse import urlparse

        host = (urlparse(raw).hostname or "").strip().lower()
    except Exception:
        host = ""
    return host in ("127.0.0.1", "localhost", "::1") or host.endswith(".local")


def _lan_device_url(host: str, port: int = 80) -> str:
    h = (host or "").strip()
    p = int(port or 80)
    if p in (80, 0):
        return f"http://{h}"
    return f"http://{h}:{p}"


# Clear operator message when activation cannot complete (kept if attempts fail).
ACTIVATION_STUB_UZ = (
    "Автонастройка для нового (активация) устройства пока неполная. "
    "Сначала задайте admin-пароль на терминале (или через SADP), затем подключите по пути «Есть admin». "
    "На некоторых моделях Hikvision ISAPI-активация не работает."
)

# Common Hikvision activation / status probes (best-effort; model-specific).
_ACTIVATE_STATUS_PATHS = (
    "/SDK/activateStatus",
    "/ISAPI/System/activateStatus",
    "/ISAPI/System/Activated",
)
_ACTIVATE_PUT_PATHS = (
    "/ISAPI/System/activate",
    "/ISAPI/Security/activate",
    "/SDK/activate",
)


def state_label_uz(state: str) -> str:
    return STATE_LABELS_UZ.get(state, STATE_LABELS_UZ[STATE_UNKNOWN])


def _xml_escape(value: str) -> str:
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _body_text(body: bytes) -> str:
    try:
        return body.decode("utf-8", errors="replace") if body else ""
    except Exception:
        return ""


def _looks_activated(text: str) -> bool | None:
    low = (text or "").lower()
    if "<activated>true</activated>" in low or '"activated":true' in low:
        return True
    if "<activated>false</activated>" in low or '"activated":false' in low:
        return False
    return None


def _activate_payloads(password: str) -> list[bytes]:
    pwd = _xml_escape(password)
    return [
        (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f"<ActivateInfo><password>{pwd}</password></ActivateInfo>"
        ).encode("utf-8"),
        (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f"<ActivationInfo><password>{pwd}</password></ActivationInfo>"
        ).encode("utf-8"),
        f'{{"password":"{password}"}}'.encode("utf-8"),
    ]


def attempt_factory_activation(
    host: str,
    password: str,
    port: int = 80,
    timeout: float = 5.0,
    http_get: Callable[..., tuple[int, dict[str, str], bytes]] | None = None,
    http_request: Callable[..., tuple[int, dict[str, str], bytes]] | None = None,
) -> dict[str, Any]:
    """Best-effort Hikvision factory activation (not all models).

    Tries common status + PUT activate endpoints. Does **not** implement full
    RSA challenge/AES flow (needs crypto + model docs). Returns ok=True only
    when an activate call succeeds or device already looks activated.
    """
    get_fn = http_get or _http_get
    req_fn = http_request or _http_request
    host = (host or "").strip()
    password = (password or "").strip()
    attempts: list[dict[str, Any]] = []
    meta: dict[str, Any] = {"host": host, "port": port, "attempts": attempts}

    if not host or not password:
        return {
            "ok": False,
            "reason": "missing_host_or_password",
            "message": ACTIVATION_STUB_UZ,
            "meta": meta,
        }

    already: bool | None = None
    for path in _ACTIVATE_STATUS_PATHS:
        try:
            status, _hdrs, body = get_fn(host, port, path, timeout=timeout)
            text = _body_text(body)
            flag = _looks_activated(text)
            attempts.append(
                {
                    "method": "GET",
                    "path": path,
                    "status": status,
                    "activated": flag,
                }
            )
            if flag is True:
                already = True
                break
            if flag is False:
                already = False
        except (OSError, socket.timeout) as exc:
            attempts.append(
                {
                    "method": "GET",
                    "path": path,
                    "error": str(exc)[:120],
                }
            )

    if already is True:
        meta["alreadyActivated"] = True
        return {
            "ok": True,
            "reason": "already_activated",
            "message": "Устройство уже активировано.",
            "meta": meta,
        }

    for path in _ACTIVATE_PUT_PATHS:
        for payload in _activate_payloads(password):
            ctype = (
                "application/json"
                if payload[:1] == b"{"
                else "application/xml"
            )
            try:
                status, _hdrs, body = req_fn(
                    host,
                    port,
                    "PUT",
                    path,
                    body=payload,
                    headers={"Content-Type": ctype, "Accept": "*/*"},
                    timeout=timeout,
                )
                text = _body_text(body)
                low = text.lower().replace(" ", "")
                okish = status in (200, 201) and (
                    "statusstring>ok<" in low
                    or "<substatuscode>ok</substatuscode>" in text.lower()
                    or (status == 200 and ("ok" in text.lower() or not text.strip()))
                )
                attempts.append(
                    {
                        "method": "PUT",
                        "path": path,
                        "status": status,
                        "okish": okish,
                        "snippet": text[:160],
                    }
                )
                if okish:
                    meta["activatedVia"] = path
                    return {
                        "ok": True,
                        "reason": "activated",
                        "message": "Активация успешна (best-effort).",
                        "meta": meta,
                    }
            except (OSError, socket.timeout) as exc:
                attempts.append(
                    {
                        "method": "PUT",
                        "path": path,
                        "error": str(exc)[:120],
                    }
                )

    # Optional challenge probe — RSA path needs crypto; document only.
    try:
        status, _hdrs, body = req_fn(
            host,
            port,
            "POST",
            "/ISAPI/Security/challenge",
            body=b'<?xml version="1.0"?><PublicKey><key></key></PublicKey>',
            headers={"Content-Type": "application/xml"},
            timeout=timeout,
        )
        attempts.append(
            {
                "method": "POST",
                "path": "/ISAPI/Security/challenge",
                "status": status,
                "note": "RSA challenge requires model-specific crypto (not implemented)",
                "snippet": _body_text(body)[:120],
            }
        )
    except (OSError, socket.timeout) as exc:
        attempts.append(
            {
                "method": "POST",
                "path": "/ISAPI/Security/challenge",
                "error": str(exc)[:120],
            }
        )

    return {
        "ok": False,
        "reason": "activation_failed",
        "message": ACTIVATION_STUB_UZ,
        "meta": meta,
    }


def detect_state(host: str, port: int = 80, timeout: float = 4.0) -> dict[str, Any]:
    """Probe ISAPI without credentials.

    - Unauthenticated deviceInfo/ISAPI success → likely new/open
    - Digest/401 challenge without a session → configured (needs admin password)
    - Otherwise → unknown
    """
    host = (host or "").strip()
    meta: dict[str, Any] = {"host": host, "port": port}
    if not host:
        return {"state": STATE_UNKNOWN, "meta": {**meta, "reason": "empty_host"}}

    path = "/ISAPI/System/deviceInfo"
    try:
        status, headers, body = _http_get(host, port, path, timeout=timeout)
    except socket.timeout:
        return {"state": STATE_UNKNOWN, "meta": {**meta, "reason": "timeout"}}
    except OSError as exc:
        msg = str(exc).lower()
        reason = "timeout" if ("timed out" in msg or "timeout" in msg) else "offline"
        return {"state": STATE_UNKNOWN, "meta": {**meta, "reason": reason, "error": str(exc)[:160]}}

    probe = classify_probe(status, headers, body)
    meta.update(
        {
            "httpStatus": status,
            "likelyHikvision": bool(probe.get("likely_hikvision")),
            "digest": bool(probe.get("digest")),
            "hintName": probe.get("hint_name") or "",
            "server": probe.get("server") or "",
        }
    )

    if status == 200:
        parsed = parse_device_payload(body, headers.get("content-type") or "")
        meta["device"] = parsed
        # Open deviceInfo without auth → activation / open admin path (new).
        return {"state": STATE_NEW, "meta": meta}

    if status == 401:
        www = headers.get("www-authenticate") or ""
        if "digest" in www.lower() or probe.get("digest"):
            meta["reason"] = "digest_challenge"
            return {"state": STATE_CONFIGURED, "meta": meta}
        # Some firmwares return 401 with activation hints without digest.
        blob = f"{www} {body[:400].decode('utf-8', errors='replace')}".lower()
        if any(tok in blob for tok in ("activation", "activate", "not activated")):
            meta["reason"] = "activation_hint"
            return {"state": STATE_NEW, "meta": meta}
        meta["reason"] = "unauthorized"
        return {"state": STATE_CONFIGURED, "meta": meta}

    if status in (403, 404) and probe.get("likely_hikvision"):
        meta["reason"] = f"http_{status}"
        return {"state": STATE_UNKNOWN, "meta": meta}

    meta["reason"] = f"http_{status}"
    return {"state": STATE_UNKNOWN, "meta": meta}


def _progress(session: Any, **kwargs: Any) -> None:
    """Best-effort progress PATCH (needs pairing token + session id)."""
    import api_client

    sid = getattr(session, "provision_session_id", None)
    token = ""
    if hasattr(session, "pairing_token"):
        try:
            token = session.pairing_token() or ""
        except Exception:
            token = ""
    if not sid or not token:
        return
    key = read_link_key(getattr(session, "root", None))
    try:
        api_client.patch_progress(
            session.api_url,
            key,
            session.tenant,
            session_id=sid,
            pairing_token=token,
            host=(session.verified or {}).get("host")
            if getattr(session, "verified", None)
            else (session.chosen.host if getattr(session, "chosen", None) else None),
            serial=(session.verified or {}).get("serialNumber")
            if getattr(session, "verified", None)
            else None,
            **kwargs,
        )
    except Exception:
        pass


class ProvisionEngine:
    """Wrap verify → gateway/tunnel → announce → register (with locationId)."""

    def provision_new(
        self,
        session: Any,
        password: str,
        location_id: str,
        on_status: StatusFn | None = None,
    ) -> Any:
        from passwords import generate_terminal_password
        from session import SubmitResult

        host = ""
        port = 80
        if getattr(session, "chosen", None):
            host = getattr(session.chosen, "host", "") or ""
            port = int(getattr(session.chosen, "port", 80) or 80)

        username = (getattr(session, "username", None) or "admin").strip() or "admin"
        # Always invent — operator must not keep this password.
        platform_pwd = generate_terminal_password(username)

        _emit(on_status, "Новое устройство: генерация platform-пароля и активация...")
        _progress(
            session,
            status="configuring",
            step="activation_attempt",
            percent=10,
            message="Factory activation with platform password",
        )

        result = attempt_factory_activation(host, platform_pwd, port=port)
        if result.get("ok"):
            _emit(on_status, "Активация OK — управление передаётся платформе...")
            _progress(
                session,
                status="configuring",
                step="activation_ok",
                percent=25,
                message=str(result.get("reason") or "activated"),
            )
            # Password already platform-owned; skip second rotation.
            return self.provision_configured(
                session,
                platform_pwd,
                location_id,
                on_status=on_status,
                rotate_password=False,
            )

        _emit(on_status, "Активация не удалась — задайте admin вручную.")
        _progress(
            session,
            status="failed",
            step="activation_stub",
            percent=0,
            message=str(result.get("reason") or "activation_failed"),
        )
        return SubmitResult(
            kind=ERROR,
            message=str(result.get("message") or ACTIVATION_STUB_UZ),
        )

    def provision_configured(
        self,
        session: Any,
        password: str,
        location_id: str,
        on_status: StatusFn | None = None,
        *,
        rotate_password: bool = True,
    ) -> Any:
        """Verify → rotate to platform password → register (vault) → Web owns device."""
        import api_client
        import runtime_setup
        from passwords import change_admin_password, generate_terminal_password
        from session import SubmitResult

        location_id = (location_id or "").strip()
        if not location_id:
            return SubmitResult(
                kind="location",
                message="Локация не выбрана. Выберите локацию перед подключением.",
            )
        password = (password or "").strip()
        if not password:
            return SubmitResult(kind="empty", message="Пароль не введён.")
        if not session.chosen:
            return SubmitResult(kind="no_device", message="Устройство не найдено.")

        key = read_link_key(session.root)
        pairing = ""
        if hasattr(session, "pairing_token"):
            pairing = session.pairing_token() or ""
        if not key and not pairing:
            return SubmitResult(
                kind="no_key",
                message="Требуется pairing-токен или ключ администратора.",
            )

        username = (getattr(session, "username", None) or "admin").strip() or "admin"

        _progress(
            session,
            status="configuring",
            step="verify_password",
            percent=20,
            message="Проверка пароля",
        )
        _emit(on_status, "Проверка текущего пароля...")
        result = verify_password(
            session.chosen.host,
            session.chosen.port,
            username,
            password,
        )
        if result.kind == TIMEOUT:
            return SubmitResult(
                kind=TIMEOUT,
                message="Таймаут сети. Попытка пароля не засчитана.",
            )
        if result.kind in (UNAUTHORIZED,):
            _progress(
                session,
                status="failed",
                step="bad_password",
                percent=20,
                message="Неверный пароль",
            )
            return SubmitResult(kind=UNAUTHORIZED, message="Неверный пароль.")
        if result.kind != OK:
            return SubmitResult(
                kind=result.kind,
                message="Не удалось проверить пароль.",
            )

        session.auth.record_success()
        session.verified = result.as_device()

        if rotate_password:
            new_pwd = generate_terminal_password(username)
            _progress(
                session,
                status="configuring",
                step="change_password",
                percent=30,
                message="Платформа устанавливает новый пароль",
            )
            _emit(
                on_status,
                "1/4 Смена admin-пароля (новый пароль принадлежит платформе)...",
            )
            changed = change_admin_password(
                session.chosen.host,
                int(session.chosen.port or 80),
                username,
                password,
                new_pwd,
            )
            if not changed.get("ok"):
                reason = str(changed.get("reason") or "")
                msg = str(changed.get("message") or "Не удалось сменить пароль")
                _progress(
                    session,
                    status="failed",
                    step="change_password_failed",
                    percent=30,
                    message=msg[:120],
                )
                if reason == TIMEOUT:
                    return SubmitResult(kind=TIMEOUT, message=msg)
                if reason == UNAUTHORIZED:
                    return SubmitResult(kind=UNAUTHORIZED, message=msg)
                return SubmitResult(kind=ERROR, message=msg)
            password = new_pwd
            # Persist IMMEDIATELY — if API/tunnel fails later, password is recoverable.
            try:
                from credential_store import save_device_credential

                save_device_credential(
                    host=session.chosen.host,
                    port=int(session.chosen.port or 80),
                    username=username,
                    password=password,
                    serial=str((session.verified or {}).get("serialNumber") or ""),
                    location_id=location_id,
                    phase="rotated_on_device",
                    root=session.root,
                )
            except Exception:
                pass
            # change_admin_password already verifies; double-check for seal path.
            recheck = verify_password(
                session.chosen.host,
                int(session.chosen.port or 80),
                username,
                password,
                timeout=6.0,
            )
            if recheck.kind != OK:
                return SubmitResult(
                    kind=ERROR,
                    message=(
                        "Пароль на терминале изменён, но повторный вход с новым паролем не удался. "
                        "Подключение остановлено. "
                        f"ПАРОЛЬ ВОССТАНОВЛЕНИЯ: {password}"
                    ),
                )
            _emit(on_status, "1/4 Готово: новый admin-пароль работает на терминале (сохранён локально)")
        else:
            _emit(on_status, "1/4 Пароль уже принадлежит платформе")

        # Tiklanish pochtasi (parol unutilganda) — config.json recoveryEmail
        try:
            from device_email import apply_recovery_email_from_config, normalize_recovery_email

            cfg = getattr(session, "cfg", None) or {}
            email_target = normalize_recovery_email(str(cfg.get("recoveryEmail") or ""))
            _emit(on_status, f"1b/4 Почта восстановления: {email_target}")
            _progress(
                session,
                status="configuring",
                step="recovery_email",
                percent=35,
                message=f"Recovery email → {email_target}",
            )
            email_res = apply_recovery_email_from_config(
                session.chosen.host,
                int(session.chosen.port or 80),
                username,
                password,
                cfg if isinstance(cfg, dict) else {},
            )
            if email_res.get("ok"):
                _emit(
                    on_status,
                    f"Почта восстановления установлена: {email_res.get('email') or email_target}",
                )
            else:
                _emit(
                    on_status,
                    "Не удалось записать почту восстановления "
                    f"({email_res.get('message') or 'ошибка'}) — подключение продолжается",
                )
        except Exception as exc:
            _emit(on_status, f"Почта восстановления: {exc} — подключение продолжается")

        # Face anti-spoof / living-body — strongest ISAPI level on this model.
        try:
            from device_security import ensure_live_detection

            _emit(on_status, "1c/4 Защита от подмены лица (professional)…")
            _progress(
                session,
                status="configuring",
                step="live_detection",
                percent=38,
                message="Living body / anti-spoof → professional",
            )
            live_res = ensure_live_detection(
                session.chosen.host,
                username,
                password,
            )
            if live_res.get("ok") and live_res.get("ready"):
                _emit(
                    on_status,
                    "Защита от подмены лица: livingBody + professional + anti-attack ON",
                )
            elif live_res.get("ok"):
                _emit(
                    on_status,
                    "Защита от подмены лица обновлена "
                    f"(level={live_res.get('liveDetLevelSet')})",
                )
            else:
                _emit(
                    on_status,
                    "Не удалось записать защиту от подмены лица "
                    f"({live_res.get('error') or 'ошибка'}) — подключение продолжается",
                )
        except Exception as exc:
            _emit(on_status, f"Защита от подмены лица: {exc} — подключение продолжается")

        session.password = password
        session.location_id = location_id
        session.username = username

        runtime_setup.ensure_runtime(session.root, on_status)
        bundle = runtime_setup.ServiceBundle()
        bundle.root = session.root
        try:
            # GW needs long-lived punch key; prefer link.key (may arrive via pairing bind).
            gw_key = key or pairing
            _progress(
                session,
                status="configuring",
                step="gateway",
                percent=40,
                message="Gateway",
            )
            _emit(on_status, "2/4 Открытие gateway + tunnel...")
            local_api = _is_local_api(str(session.api_url or ""))
            if local_api:
                # Local API on same LAN: no Cloudflare, device GW optional.
                url = _lan_device_url(
                    session.chosen.host,
                    int(session.chosen.port or 80),
                )
                bundle.gw = None
                bundle.tunnel = None
                bundle.tunnel_url = url
                _emit(
                    on_status,
                    f"2/4 Lokal API — Cloudflare/GW kerak emas, LAN: {url}",
                )
            else:
                bundle.gw = runtime_setup.start_gateway(
                    session.api_url, gw_key, session.root, on_status
                )
                _progress(
                    session,
                    status="configuring",
                    step="tunnel",
                    percent=55,
                    message="Tunnel",
                )
                proc, url = runtime_setup.start_tunnel(session.root, on_status)
                bundle.tunnel = proc
                bundle.tunnel_url = url
            _progress(
                session,
                status="configuring",
                step="tunnel",
                percent=55,
                message="Tunnel" if not local_api else "LAN reach",
            )
            if not (url or "").strip():
                bundle.stop()
                _progress(
                    session,
                    status="failed",
                    step="tunnel_url_missing",
                    percent=55,
                    message="URL туннеля отсутствует",
                )
                return SubmitResult(
                    kind="api",
                    message=(
                        "URL туннеля не найден. Проверьте trycloudflare или namedTunnelUrl / cloudflareTunnelToken в config.json."
                    ),
                )

            _emit(on_status, "3/4 Запись нового пароля и устройства на Web-сервер...")
            _progress(
                session,
                status="configuring",
                step="ping",
                percent=65,
                message="Ping платформы",
            )
            code, _ping = api_client.ping(
                session.api_url, key, session.tenant, pairing_token=pairing or None
            )
            if not api_client.is_success(code):
                bundle.stop()
                _progress(
                    session,
                    status="failed",
                    step="ping_failed",
                    percent=65,
                    message="Не удалось подключиться к платформе",
                )
                return SubmitResult(
                    kind="api",
                    message="Не удалось подключиться к платформе. Проверьте интернет или pairing/ключ администратора.",
                )

            _progress(
                session,
                status="configuring",
                step="announce",
                percent=75,
                message="Tunnel announce",
            )
            code, _ann = api_client.announce(
                session.api_url,
                key,
                session.tenant,
                url,
                pairing_token=pairing or None,
            )
            if not api_client.is_success(code):
                bundle.stop()
                _progress(
                    session,
                    status="failed",
                    step="announce_failed",
                    percent=75,
                    message="Туннель не записан",
                )
                return SubmitResult(
                    kind="api",
                    message=f"Туннель не записан на платформу (HTTP {code}).",
                )

            _progress(
                session,
                status="configuring",
                step="register",
                percent=90,
                message="Register + vault",
            )
            code, linked = api_client.register_device(
                session.api_url,
                key,
                session.tenant,
                session.verified,
                username,
                session.password,
                location_id=location_id,
                pairing_token=pairing or None,
            )
            if not api_client.is_success(code):
                bundle.stop()
                _progress(
                    session,
                    status="failed",
                    step="register_failed",
                    percent=90,
                    message="Ошибка register",
                )
                recovery = (session.password or "").strip()
                try:
                    from credential_store import save_device_credential

                    save_device_credential(
                        host=session.chosen.host if session.chosen else "",
                        port=int(session.chosen.port or 80) if session.chosen else 80,
                        username=username,
                        password=recovery,
                        serial=str((session.verified or {}).get("serialNumber") or ""),
                        location_id=location_id,
                        phase="register_failed_keep_local",
                        root=session.root,
                    )
                except Exception:
                    pass
                tip = (
                    f" ПАРОЛЬ ВОССТАНОВЛЕНИЯ (скопируйте): {recovery}"
                    if recovery
                    else " проверьте data\\device-credential.json."
                )
                return SubmitResult(
                    kind="api",
                    message=(
                        f"Устройство/пароль не записаны на платформу (HTTP {code}). "
                        "Новый пароль на терминале сохранён локально."
                        + tip
                    ),
                )

            # Bind reach URL to the new device row (LAN or Cloudflare).
            try:
                did = str(
                    ((linked.get("device") if isinstance(linked, dict) else {}) or {}).get(
                        "id"
                    )
                    or ""
                )
                if did and (url or "").strip():
                    api_client.announce(
                        session.api_url,
                        key,
                        session.tenant,
                        url,
                        pairing_token=pairing or None,
                        device_id=did,
                    )
            except Exception:
                pass

            # Keep local recovery copy even after successful server write.
            try:
                from credential_store import save_device_credential

                save_device_credential(
                    host=session.chosen.host if session.chosen else "",
                    port=int(session.chosen.port or 80) if session.chosen else 80,
                    username=username,
                    password=session.password or "",
                    serial=str((session.verified or {}).get("serialNumber") or ""),
                    location_id=location_id,
                    phase="registered_awaiting_admin_confirm",
                    device_id=str(
                        ((linked.get("device") if isinstance(linked, dict) else {}) or {}).get(
                            "id"
                        )
                        or ""
                    ),
                    root=session.root,
                )
            except Exception:
                pass

            # Device → cloud punch push (HttpHostNotification). Soft-fail.
            # Default: direct HTTPS to Railway (Link not required). LAN proxy = fallback.
            try:
                from device_push import apply_hik_push_prefer_lan

                hik_push = (
                    linked.get("hikPush") if isinstance(linked, dict) else None
                )
                if isinstance(hik_push, dict) and hik_push.get("urlPath"):
                    _emit(on_status, "3b/4 HttpHost (otmetkalar → web)…")
                    push_res = apply_hik_push_prefer_lan(
                        session.chosen.host if session.chosen else "",
                        int(session.chosen.port or 80) if session.chosen else 80,
                        username,
                        session.password or "",
                        hik_push,
                        api_base=str(session.api_url or ""),
                    )
                    if push_res.get("ok"):
                        if push_res.get("mode") == "direct_https":
                            _emit(
                                on_status,
                                "HttpHost OK — otmetkalar terminal → server "
                                "(Link kerak emas)",
                            )
                        elif push_res.get("mode") == "lan_proxy":
                            _emit(
                                on_status,
                                "HttpHost OK — otmetkalar PC orqali webga "
                                f"({push_res.get('lanIp')}:{push_res.get('proxyPort')}) "
                                "— Link/service ochiq bo‘lishi kerak",
                            )
                        else:
                            _emit(on_status, "HttpHost OK — otmetkalar → web")
                        try:
                            from auto_resume import persist_hik_push_to_service

                            persist_hik_push_to_service(
                                session.root,
                                str(session.api_url or ""),
                                str(session.tenant or "demo"),
                                hik_push,
                                host=str(
                                    session.chosen.host if session.chosen else ""
                                ),
                                port=int(
                                    session.chosen.port or 80
                                )
                                if session.chosen
                                else 80,
                                device_id=str(
                                    (
                                        (
                                            linked.get("device")
                                            if isinstance(linked, dict)
                                            else {}
                                        )
                                        or {}
                                    ).get("id")
                                    or ""
                                ),
                            )
                        except Exception:
                            pass
                    else:
                        _emit(
                            on_status,
                            f"HttpHost: {push_res.get('message') or push_res.get('status')} — davom",
                        )
            except Exception as exc:
                _emit(on_status, f"HttpHost: {exc} — davom")

            session.services = bundle
            # Do NOT wipe recovery file. Clear in-memory only.
            session.password = ""
            sealed = bool(isinstance(linked, dict) and linked.get("sealed"))
            needs_confirm = bool(
                isinstance(linked, dict) and linked.get("needsAdminConfirm")
            )
            # New flow: always wait for web admin confirm after password push.
            if needs_confirm or not sealed:
                needs_confirm = True
                sealed = False
            dev = linked.get("device") if isinstance(linked, dict) else {}
            device_id = (dev or {}).get("id")
            _progress(
                session,
                status="configuring" if needs_confirm else "linked",
                step="awaiting_admin_confirm" if needs_confirm else ("sealed" if sealed else "linked"),
                percent=90 if needs_confirm else 100,
                message=(
                    "Ожидается подтверждение web-admin"
                    if needs_confirm
                    else (
                        "Подключение закреплено"
                        if sealed
                        else "Подключено — управление в Web"
                    )
                ),
                device_id=device_id,
            )

            name = (dev or {}).get("name") or session.verified.get("name")
            if needs_confirm:
                _emit(
                    on_status,
                    "4/4 Пароль установлен на терминале и отправлен на Web — подтвердите в уведомлении admin",
                )
            elif sealed:
                _emit(
                    on_status,
                    "4/4 Подключение закреплено: пароль сохранён на сервере и подтверждён через GW",
                )
            else:
                _emit(
                    on_status,
                    "4/4 Подключено (пароль записан на сервер). В Web нажмите «Синхронизировать».",
                )
            return SubmitResult(
                kind="linked",
                message=(
                    "Пароль установлен. Отметки → web (HttpHost). "
                    "Подтвердите в Web. Лица — только Web «Синхронизировать» (приложение не нужно)."
                    if needs_confirm
                    else (
                        "Подключено. Отметки → web. "
                        "Лица — только Web «Синхронизировать»."
                        if sealed
                        else "Подключено. Отметки → web; лица — Web sync."
                    )
                ),
                device={
                    "name": name,
                    "host": session.verified.get("host"),
                    "tunnel": url,
                    "locationId": location_id,
                    "sealed": sealed,
                    "needsAdminConfirm": needs_confirm,
                    "id": device_id,
                    "ownedByPlatform": True,
                    "hikPush": linked.get("hikPush") if isinstance(linked, dict) else None,
                },
            )
        except Exception as exc:
            bundle.stop()
            _progress(
                session,
                status="failed",
                step="exception",
                percent=0,
                message=str(exc)[:160],
            )
            return SubmitResult(kind=ERROR, message=str(exc)[:240])

    def provision_network_reconnect(
        self,
        session: Any,
        password: str,
        *,
        device_id: str,
        on_status: StatusFn | None = None,
    ) -> Any:
        """After Wi‑Fi change: GW+tunnel+announce + host update — no password rotate."""
        import api_client
        import runtime_setup
        from session import SubmitResult

        password = (password or "").strip()
        device_id = (device_id or "").strip()
        if not password:
            return SubmitResult(kind="empty", message="Пароль не введён.")
        if not device_id:
            return SubmitResult(kind="api", message="deviceId отсутствует.")
        if not session.chosen:
            return SubmitResult(kind="no_device", message="Устройство не найдено.")
        if not session.verified:
            return SubmitResult(kind=ERROR, message="Сначала подтвердите пароль.")

        key = read_link_key(session.root)
        pairing = ""
        if hasattr(session, "pairing_token"):
            pairing = session.pairing_token() or ""
        if not key and not pairing:
            return SubmitResult(
                kind="no_key",
                message="Требуется pairing-токен или ключ администратора.",
            )

        username = (getattr(session, "username", None) or "admin").strip() or "admin"
        session.password = password
        session.username = username
        host = session.chosen.host
        port = int(session.chosen.port or 80)
        serial = str((session.verified or {}).get("serialNumber") or "")

        runtime_setup.ensure_tunnel_tools(session.root, on_status)
        bundle = runtime_setup.ServiceBundle()
        bundle.root = session.root
        try:
            _progress(
                session,
                status="configuring",
                step="tunnel",
                percent=40,
                message="Tunnel",
                device_id=device_id,
            )
            # Prefer direct tunnel → terminal (no local :8800). Faces use this path.
            target = f"http://{host}:{port}"
            if _is_local_api(str(session.api_url or "")):
                url = _lan_device_url(host, port)
                bundle.tunnel = None
                bundle.tunnel_url = url
                bundle.gw = None
                _emit(on_status, f"1/3 Lokal API — LAN reach {url} (Cloudflare yo‘q)")
            else:
                _emit(on_status, f"1/3 Туннель → терминал {host}:{port}…")
                proc, url = runtime_setup.start_tunnel(
                    session.root, on_status, target_url=target
                )
                bundle.tunnel = proc
                bundle.tunnel_url = url
                bundle.gw = None
            if not (url or "").strip():
                bundle.stop()
                return SubmitResult(
                    kind="api",
                    message=(
                        "URL туннеля не найден. Проверьте trycloudflare или namedTunnelUrl / cloudflareTunnelToken в config.json."
                    ),
                )

            from paths import (
                load_config,
                resolve_tunnel_token,
                write_service_config,
                write_tunnel_url,
            )

            write_tunnel_url(url, session.root)
            cfg = getattr(session, "cfg", None) or load_config(session.root)
            write_service_config(
                api_url=session.api_url,
                tenant=session.tenant,
                tunnel_mode="named" if resolve_tunnel_token(cfg, session.root) else "quick",
                root=session.root,
                extra={
                    "tunnelUrl": url,
                    "autoHeal": True,
                    "faceAgent": True,
                    "deviceId": device_id,
                    "host": host,
                    "port": port,
                    "reachMode": "device",
                },
            )

            _emit(on_status, "2/3 Запись туннеля на платформу...")
            _progress(
                session,
                status="configuring",
                step="announce",
                percent=55,
                message="Announce",
                device_id=device_id,
            )
            code, _ping = api_client.ping(
                session.api_url, key, session.tenant, pairing_token=pairing or None
            )
            if not api_client.is_success(code):
                bundle.stop()
                return SubmitResult(
                    kind="api",
                    message="Не удалось подключиться к платформе. Проверьте интернет или pairing/ключ администратора.",
                )

            code, _ann = api_client.announce(
                session.api_url,
                key,
                session.tenant,
                url,
                pairing_token=pairing or None,
                device_id=device_id,
            )
            if not api_client.is_success(code):
                bundle.stop()
                return SubmitResult(
                    kind="api",
                    message=f"Туннель не записан на платформу (HTTP {code}).",
                )

            _emit(on_status, "3/3 Запись нового IP на сервер (пароль не меняется)...")
            _progress(
                session,
                status="configuring",
                step="reconnect",
                percent=90,
                message="Host reconnect",
                device_id=device_id,
            )
            code, linked = api_client.reconnect_device(
                session.api_url,
                key,
                session.tenant,
                device_id=device_id,
                host=host,
                port=port,
                serial_number=serial or None,
                pairing_token=pairing or None,
            )
            if not api_client.is_success(code):
                bundle.stop()
                tip = ""
                if isinstance(linked, dict):
                    tip = str(linked.get("message") or linked.get("error") or "")
                return SubmitResult(
                    kind="api",
                    message=(
                        f"Сеть не обновлена (HTTP {code}). {tip}".strip()
                    ),
                )

            # Critical: rewrite HttpHost — prefer LAN punch-proxy on this PC
            # (terminal often cannot open outbound HTTPS to Railway).
            try:
                from device_push import apply_hik_push_prefer_lan

                hik_push = (
                    linked.get("hikPush") if isinstance(linked, dict) else None
                )
                if isinstance(hik_push, dict) and hik_push.get("urlPath"):
                    _emit(on_status, "3b/3 HttpHost (otmetkalar → web)…")
                    api_base = ""
                    try:
                        api_base = str(
                            (session.api_url if session else None)
                            or ""
                        )
                    except Exception:
                        api_base = ""
                    if not api_base:
                        try:
                            from paths import load_config, find_root

                            api_base = str(
                                load_config(find_root()).get("apiUrl") or ""
                            )
                        except Exception:
                            api_base = ""
                    push_res = apply_hik_push_prefer_lan(
                        host,
                        port,
                        username,
                        password,
                        hik_push,
                        api_base=api_base,
                    )
                    if push_res.get("ok"):
                        if push_res.get("mode") == "direct_https":
                            _emit(
                                on_status,
                                "HttpHost OK — otmetkalar terminal → server "
                                "(Link kerak emas)",
                            )
                        elif push_res.get("mode") == "lan_proxy":
                            _emit(
                                on_status,
                                "HttpHost OK — otmetkalar PC orqali → web "
                                f"({push_res.get('lanIp')}:{push_res.get('proxyPort')}) "
                                "— Link/service kerak",
                            )
                        else:
                            _emit(
                                on_status,
                                "HttpHost OK — otmetkalar terminal → web",
                            )
                        try:
                            from auto_resume import persist_hik_push_to_service

                            persist_hik_push_to_service(
                                session.root,
                                str(session.api_url or ""),
                                str(session.tenant or "demo"),
                                hik_push,
                                host=host,
                                port=port,
                                device_id=device_id,
                            )
                        except Exception:
                            pass
                    else:
                        _emit(
                            on_status,
                            f"HttpHost: {push_res.get('message') or push_res.get('status')} — "
                            "terminal internet/DNS/TLS ni tekshiring",
                        )
                else:
                    _emit(
                        on_status,
                        "HttpHost config yo‘q (API hikPush) — Web ensure-push kerak",
                    )
            except Exception as exc:
                _emit(on_status, f"HttpHost: {exc}")

            try:
                from credential_store import save_device_credential

                save_device_credential(
                    host=host,
                    port=port,
                    username=username,
                    password=password,
                    serial=serial,
                    location_id=str(
                        ((linked.get("device") if isinstance(linked, dict) else {}) or {}).get(
                            "locationId"
                        )
                        or getattr(session, "location_id", None)
                        or ""
                    ),
                    phase="network_reconnected",
                    device_id=device_id,
                    root=session.root,
                )
            except Exception:
                pass

            session.services = bundle
            session.password = ""
            dev = linked.get("device") if isinstance(linked, dict) else {}
            name = (dev or {}).get("name") or (session.verified or {}).get("name")
            _progress(
                session,
                status="linked",
                step="reconnected",
                percent=100,
                message="Сеть обновлена",
                device_id=device_id,
            )
            _emit(on_status, "Сеть обновлена — пароль не изменился, лица сохранены")
            return SubmitResult(
                kind="reconnected",
                message="Сеть обновлена. Пароль не изменился, лица не перезагружаются.",
                device={
                    "name": name,
                    "host": host,
                    "port": port,
                    "tunnel": url,
                    "id": device_id,
                    "reconnected": True,
                    "hikPush": linked.get("hikPush") if isinstance(linked, dict) else None,
                    "gwVerified": bool(
                        isinstance(linked, dict) and linked.get("gwVerified")
                    ),
                },
            )
        except Exception as exc:
            bundle.stop()
            _progress(
                session,
                status="failed",
                step="reconnect_exception",
                percent=0,
                message=str(exc)[:160],
                device_id=device_id,
            )
            return SubmitResult(kind=ERROR, message=str(exc)[:240])


def _emit(cb: StatusFn | None, msg: str) -> None:
    if cb:
        cb(msg)
