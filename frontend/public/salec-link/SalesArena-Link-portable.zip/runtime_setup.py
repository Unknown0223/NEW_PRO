"""Install portable Python / cloudflared, copy device-gw, start/stop services.

GUI never shows a console. Child processes use CREATE_NO_WINDOW on Windows.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

from paths import find_root, gw_dir, runtime_dir, user_data_root

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
PYTHON_EMBED_URL = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip"
GET_PIP_URL = "https://bootstrap.pypa.io/get-pip.py"
CLOUDFLARED_URL = (
    "https://github.com/cloudflare/cloudflared/releases/latest/download/"
    "cloudflared-windows-amd64.exe"
)
UA = {"User-Agent": "HRHUB-OfficeLink/1.0"}
GW_PORT = 8800

StatusFn = Callable[[str], None]


def _status(cb: StatusFn | None, msg: str) -> None:
    if cb:
        cb(msg)


def _download(url: str, dest: Path, cb: StatusFn | None = None) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=120) as resp, dest.open("wb") as f:
        shutil.copyfileobj(resp, f)


def _run_hidden(
    args: list[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    timeout: int | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        env=env,
        timeout=timeout,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )


def _clean_child_env(base: dict[str, str] | None = None) -> dict[str, str]:
    """Drop PyInstaller / parent Python vars so portable python starts cleanly."""
    env = dict(base if base is not None else os.environ)
    for key in (
        "PYTHONHOME",
        "PYTHONPATH",
        "PYTHONSTARTUP",
        "PYTHONEXECUTABLE",
        "PYTHONNOUSERSITE",
        "__PYVENV_LAUNCHER__",
        "VIRTUAL_ENV",
        "_MEIPASS",
    ):
        env.pop(key, None)
    return env


def _tail_text(path: Path, limit: int = 800) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    text = text.strip()
    if len(text) <= limit:
        return text
    return text[-limit:]


def _popen_hidden(
    args: list[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
) -> subprocess.Popen[str]:
    return subprocess.Popen(
        args,
        cwd=str(cwd) if cwd else None,
        env=env,
        stdout=stdout,
        stderr=stderr,
        stdin=subprocess.DEVNULL,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )


def bundled_python(root: Path | None = None) -> Path | None:
    """Python shipped inside the package (build_bundle.py); read-only install dirs are fine."""
    py = (root or find_root()) / "runtime" / "python" / "python.exe"
    return py if py.is_file() else None


def portable_python(root: Path | None = None) -> Path:
    return bundled_python(root) or runtime_dir(root) / "python" / "python.exe"


def portable_pythonw(root: Path | None = None) -> Path:
    return portable_python(root).with_name("pythonw.exe")


def cloudflared_exe(root: Path | None = None) -> Path:
    bundled = (root or find_root()) / "runtime" / "cloudflared.exe"
    return bundled if bundled.is_file() else runtime_dir(root) / "cloudflared.exe"


def _copy_gw_tree(src: Path, dest: Path, cb: StatusFn | None = None) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "adapters").mkdir(parents=True, exist_ok=True)
    _status(cb, "Gateway kodlari nusxalanmoqda...")
    shutil.copy2(src / "main.py", dest / "main.py")
    if (src / "nats_client.py").is_file():
        shutil.copy2(src / "nats_client.py", dest / "nats_client.py")
    if (src / "requirements.txt").is_file():
        shutil.copy2(src / "requirements.txt", dest / "requirements.txt")
    adapters = src / "adapters"
    if adapters.is_dir():
        for py in adapters.glob("*.py"):
            shutil.copy2(py, dest / "adapters" / py.name)


def _gw_seed_candidates(root: Path) -> list[Path]:
    """Locations that may ship device-gw with the Link install / repo checkout."""
    meipass = getattr(sys, "_MEIPASS", None)
    cands: list[Path | None] = [
        root / "gw",
        root.parent / "gw",  # BOSHLASH.bat root when exe lives in ilova\
        Path(meipass) / "gw" if meipass else None,
        root.parent.parent / "apps" / "device-gw",
        root.parent / "apps" / "device-gw",
        Path(__file__).resolve().parent.parent.parent / "apps" / "device-gw",
        Path(__file__).resolve().parent / "gw",
    ]
    out: list[Path] = []
    seen: set[str] = set()
    for cand in cands:
        if cand is None:
            continue
        try:
            key = str(cand.resolve())
        except OSError:
            key = str(cand)
        if key in seen:
            continue
        seen.add(key)
        out.append(cand)
    return out


def copy_gw_sources(root: Path | None = None, cb: StatusFn | None = None) -> Path:
    """Copy device-gw into a writable gw_dir (never leave Program Files half-updated)."""
    root = root or find_root()
    dest = gw_dir(root)

    # Already present in the writable tree — nothing to do.
    if (dest / "main.py").is_file():
        return dest

    src = None
    for cand in _gw_seed_candidates(root):
        if (cand / "main.py").is_file():
            src = cand
            break

    if src is None:
        raise FileNotFoundError(
            "Gateway kodlari yo‘q (gw/main.py). "
            "Link paketiga gw qo‘shilgan bo‘lishi kerak — pack-release.bat ni qayta ishga tushiring."
        )

    try:
        if src.resolve() != dest.resolve():
            _copy_gw_tree(src, dest, cb)
    except OSError as exc:
        if (dest / "main.py").is_file():
            _status(cb, f"Gateway mavjud fayllardan ishlatiladi ({exc})")
            return dest
        raise RuntimeError(
            "Gateway kodlarini yozib bo‘lmadi (Permission denied). "
            "Ilovani LocalAppData o‘rnatishidan oching yoki administrator bilan qayta o‘rnating."
        ) from exc

    if not (dest / "main.py").is_file():
        raise FileNotFoundError(
            "Gateway kodlari yo‘q. Link o‘rnatilishida gw papkasi bo‘lishi shart."
        )
    return dest


def install_portable_python(root: Path | None = None, cb: StatusFn | None = None) -> Path:
    root = root or find_root()
    py = portable_python(root)
    if py.is_file():
        return py
    _status(cb, "Python yuklanmoqda...")
    rt = runtime_dir(root)
    zpath = rt / "python-embed.zip"
    _download(PYTHON_EMBED_URL, zpath, cb)
    py_dir = rt / "python"
    py_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zpath, "r") as zf:
        zf.extractall(py_dir)
    zpath.unlink(missing_ok=True)
    pth = next(py_dir.glob("python*._pth"), None)
    if pth:
        pth.write_text(
            "python312.zip\n.\nLib\\site-packages\nimport site\n",
            encoding="ascii",
        )
    get_pip = rt / "get-pip.py"
    _status(cb, "pip o‘rnatilmoqda...")
    _download(GET_PIP_URL, get_pip, cb)
    r = _run_hidden([str(py), str(get_pip), "--no-warn-script-location"], cwd=py_dir, env=_clean_child_env(), timeout=180)
    get_pip.unlink(missing_ok=True)
    if r.returncode != 0:
        raise RuntimeError("pip o‘rnatilmadi (internet kerak).")
    return py


def install_cloudflared(root: Path | None = None, cb: StatusFn | None = None) -> Path:
    root = root or find_root()
    exe = cloudflared_exe(root)
    if exe.is_file():
        return exe
    meipass = getattr(sys, "_MEIPASS", None)
    nearby_candidates = (
        root / "runtime" / "cloudflared.exe",
        root.parent / "runtime" / "cloudflared.exe",
        root / "cloudflared.exe",
        Path(meipass) / "cloudflared.exe" if meipass else None,
        root.parent.parent / "tools" / "cloudflared.exe",
        Path(__file__).resolve().parent.parent / "cloudflared.exe",
    )
    for nearby in nearby_candidates:
        if nearby is not None and nearby.is_file():
            exe.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(nearby, exe)
            return exe
    _status(cb, "Tunnel dasturi yuklanmoqda...")
    _download(CLOUDFLARED_URL, exe, cb)
    return exe


def ensure_tunnel_tools(root: Path | None = None, cb: StatusFn | None = None) -> Path:
    """Ensure cloudflared is available (device-direct tunnel — no local :8800 GW)."""
    return install_cloudflared(root, cb)


def _gw_deps_ready(py: Path) -> bool:
    """True if device-gw + face-agent imports already work (skip slow pip)."""
    try:
        r = _run_hidden(
            [
                str(py),
                "-c",
                "import fastapi,uvicorn,httpx,pydantic_settings,nats,multipart,PIL",
            ],
            env=_clean_child_env(),
            timeout=20,
        )
        return r.returncode == 0
    except Exception:
        return False


def install_gw_deps(root: Path | None = None, cb: StatusFn | None = None) -> None:
    root = root or find_root()
    py = portable_python(root)
    req = gw_dir(root) / "requirements.txt"
    if not req.is_file():
        raise FileNotFoundError("Gateway requirements.txt yo‘q.")
    if _gw_deps_ready(py):
        _status(cb, "Kutubxonalar tayyor — o‘tkazib yuborildi")
        return
    if bundled_python(root) is not None:
        raise RuntimeError(
            "Ilova ichidagi kutubxonalar shikastlangan. Worklyn Link’ni qayta o‘rnating."
        )
    _status(cb, "Kerakli kutubxonalar o‘rnatilmoqda… (1–2 daqiqa)")
    try:
        r = _run_hidden(
            [
                str(py),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "--no-input",
                "-q",
                "-r",
                str(req),
            ],
            cwd=gw_dir(root),
            env=_clean_child_env(),
            timeout=180,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            "Kutubxona o‘rnatish vaqti tugadi (internet/PyPI). "
            "Keyinroq qayta urining yoki BOSHLASH.bat."
        ) from exc
    if r.returncode != 0:
        err = ((r.stderr or "") + "\n" + (r.stdout or "")).strip()[:220]
        raise RuntimeError(
            "Kutubxona o‘rnatilmadi (internet kerak)."
            + (f" {err}" if err else "")
        )
    if not _gw_deps_ready(py):
        # Face-agent needs Pillow; older gw/requirements.txt may omit it.
        _status(cb, "Yetishmayotgan kutubxona (Pillow) o‘rnatilmoqda…")
        try:
            r2 = _run_hidden(
                [
                    str(py),
                    "-m",
                    "pip",
                    "install",
                    "--disable-pip-version-check",
                    "--no-input",
                    "-q",
                    "Pillow>=10.0.0",
                ],
                cwd=gw_dir(root),
                env=_clean_child_env(),
                timeout=120,
            )
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(
                "Pillow o‘rnatish vaqti tugadi. Keyinroq qayta urining."
            ) from exc
        if r2.returncode != 0 or not _gw_deps_ready(py):
            err = ((r2.stderr or "") + "\n" + (r2.stdout or "")).strip()[:220]
            raise RuntimeError(
                "Kutubxona o‘rnatildi, lekin import tekshiruvi yiqildi."
                + (f" {err}" if err else "")
            )



def ensure_runtime(root: Path | None = None, cb: StatusFn | None = None) -> None:
    """Full stack: device-gw sources + portable Python + deps + cloudflared."""
    copy_gw_sources(root, cb)
    install_portable_python(root, cb)
    install_cloudflared(root, cb)
    install_gw_deps(root, cb)


def _kill_pid(pid: int) -> None:
    if pid <= 0:
        return
    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                creationflags=CREATE_NO_WINDOW,
            )
        else:
            os.kill(pid, 15)
    except OSError:
        pass


def _read_pid(path: Path) -> int:
    try:
        return int(path.read_text(encoding="ascii").strip() or "0")
    except (OSError, ValueError):
        return 0


def _write_pid(path: Path, pid: int) -> None:
    path.write_text(str(pid), encoding="ascii")


class ServiceBundle:
    def __init__(self) -> None:
        self.gw: subprocess.Popen[str] | None = None
        self.tunnel: subprocess.Popen[str] | None = None
        self.tunnel_url: str = ""
        self.root: Path | None = None

    def stop(self) -> None:
        for proc in (self.tunnel, self.gw):
            if proc and proc.poll() is None:
                _kill_pid(proc.pid)
        self.tunnel = None
        self.gw = None
        self.tunnel_url = ""
        if self.root:
            rt = runtime_dir(self.root)
            for name in ("gw.pid", "tunnel.pid"):
                pid = _read_pid(rt / name)
                if pid:
                    _kill_pid(pid)
                try:
                    (rt / name).unlink(missing_ok=True)
                except OSError:
                    pass


def start_gateway(
    api_url: str,
    punch_key: str,
    root: Path | None = None,
    cb: StatusFn | None = None,
) -> subprocess.Popen[str]:
    root = root or find_root()
    py = portable_python(root)
    gwd = gw_dir(root)
    rt = runtime_dir(root)
    old = _read_pid(rt / "gw.pid")
    if old:
        _kill_pid(old)
    if not py.is_file():
        raise RuntimeError("Portable Python yo‘q — avval runtime o‘rnating.")
    if not (gwd / "main.py").is_file():
        raise RuntimeError("Gateway kodlari yo‘q (gw/main.py).")

    env = _clean_child_env()
    env.update(
        {
            "DEVICE_GW_PORT": str(GW_PORT),
            "DEVICE_GW_HOST": "127.0.0.1",
            "DEVICE_GW_API_URL": api_url,
            "DEVICE_GW_PUNCH_KEY": punch_key,
            # Skip NATS in office-link — HTTP ingest to Railway is enough.
            "DEVICE_GW_NATS_URL": "disabled",
            "DEFAULT_ADAPTER": "hikvision_isapi",
        }
    )
    log_path = rt / "gw.log"
    _status(cb, "Gateway yoqilmoqda...")
    # Never use PIPE here — uvicorn logs fill the buffer and freeze the child.
    log_f = open(log_path, "a", encoding="utf-8", errors="replace")
    try:
        log_f.write(f"\n--- gateway start {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        log_f.flush()
        proc = _popen_hidden(
            [str(py), "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", str(GW_PORT)],
            cwd=gwd,
            env=env,
            stdout=log_f,
            stderr=subprocess.STDOUT,
        )
    except Exception:
        log_f.close()
        raise
    _write_pid(rt / "gw.pid", proc.pid)
    import http.client

    for _ in range(50):
        if proc.poll() is not None:
            try:
                log_f.flush()
            except Exception:
                pass
            detail = _tail_text(log_path) or f"exit={proc.returncode}"
            raise RuntimeError(f"Gateway ochilmadi. {detail[:220]}")
        try:
            conn = http.client.HTTPConnection("127.0.0.1", GW_PORT, timeout=2)
            conn.request("GET", "/health")
            resp = conn.getresponse()
            resp.read()
            conn.close()
            if resp.status == 200:
                return proc
        except OSError:
            pass
        time.sleep(0.4)
    detail = _tail_text(log_path)
    raise RuntimeError(
        "Gateway ochilmadi (health timeout)."
        + (f" {detail[:180]}" if detail else "")
    )


def start_named_tunnel(
    token: str,
    public_url: str,
    root: Path | None = None,
    cb: StatusFn | None = None,
) -> tuple[subprocess.Popen[str], str]:
    """cloudflared tunnel run --token (stable hostname from config)."""
    root = root or find_root()
    exe = cloudflared_exe(root)
    rt = runtime_dir(root)
    old = _read_pid(rt / "tunnel.pid")
    if old:
        _kill_pid(old)
    url = (public_url or "").strip().rstrip("/")
    if not url:
        raise RuntimeError(
            "Named tunnel uchun namedTunnelUrl / tunnelPublicUrl kerak."
        )
    _status(cb, "Named tunnel ochilmoqda...")
    log_path = rt / "tunnel.log"
    log_f = open(log_path, "a", encoding="utf-8", errors="replace")
    try:
        log_f.write(f"\n--- named tunnel start {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        log_f.flush()
        proc = _popen_hidden(
            [str(exe), "tunnel", "run", "--token", token.strip()],
            cwd=rt,
            env=_clean_child_env(),
            stdout=log_f,
            stderr=subprocess.STDOUT,
        )
    except Exception:
        log_f.close()
        raise
    _write_pid(rt / "tunnel.pid", proc.pid)
    # Named tunnels do not print trycloudflare URLs; wait briefly for process health.
    for _ in range(15):
        if proc.poll() is not None:
            detail = _tail_text(log_path)
            raise RuntimeError(
                "Named tunnel ochilmadi (token / cloudflared)."
                + (f" {detail[:180]}" if detail else "")
            )
        time.sleep(0.3)
    return proc, url


def start_quick_tunnel(
    root: Path | None = None,
    cb: StatusFn | None = None,
    target_url: str | None = None,
) -> tuple[subprocess.Popen[str], str]:
    root = root or find_root()
    exe = cloudflared_exe(root)
    rt = runtime_dir(root)
    old = _read_pid(rt / "tunnel.pid")
    if old:
        _kill_pid(old)
    target = (target_url or "").strip() or f"http://127.0.0.1:{GW_PORT}"
    _status(cb, f"Internet tunnel ochilmoqda… ({target})")
    env = _clean_child_env()
    log_path = rt / "tunnel.log"
    # Never leave stdout on PIPE after URL parse — buffer fill freezes cloudflared.
    log_f = open(log_path, "a", encoding="utf-8", errors="replace")
    try:
        log_f.write(
            f"\n--- quick tunnel start {time.strftime('%Y-%m-%d %H:%M:%S')} target={target} ---\n"
        )
        log_f.flush()
        proc = _popen_hidden(
            [str(exe), "tunnel", "--url", target],
            cwd=rt,
            env=env,
            stdout=log_f,
            stderr=subprocess.STDOUT,
        )
    except Exception:
        log_f.close()
        raise
    _write_pid(rt / "tunnel.pid", proc.pid)
    pattern = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")
    deadline = time.time() + 70
    offset = max(0, log_path.stat().st_size - 4096) if log_path.is_file() else 0
    while time.time() < deadline:
        if proc.poll() is not None:
            detail = _tail_text(log_path)
            low = detail.lower()
            if "429" in detail or "1015" in detail or "rate" in low:
                raise RuntimeError(
                    "Cloudflare quick tunnel limithi (429). "
                    "Bir necha daqiqa kutib qayta urining; "
                    "tez-tez «Восстановить» bosilsa bloklanadi. "
                    "LAN face sync ishlashi mumkin."
                    + (f" {detail[-120:]}" if detail else "")
                )
            raise RuntimeError(
                "Tunnel ochilmadi."
                + (f" {detail[:180]}" if detail else "")
            )
        try:
            with open(log_path, "r", encoding="utf-8", errors="replace") as fh:
                fh.seek(offset)
                chunk = fh.read()
            if chunk:
                m = pattern.search(chunk)
                if m:
                    return proc, m.group(0)
                if "429" in chunk or "1015" in chunk:
                    # cloudflared may still be dying; surface rate-limit early
                    raise RuntimeError(
                        "Cloudflare quick tunnel limithi (429). "
                        "Bir necha daqiqa kutib qayta urining."
                    )
        except RuntimeError:
            raise
        except OSError:
            pass
        time.sleep(0.35)
    raise RuntimeError("Tunnel URL topilmadi.")


def start_tunnel(
    root: Path | None = None,
    cb: StatusFn | None = None,
    target_url: str | None = None,
) -> tuple[subprocess.Popen[str], str]:
    """Prefer named tunnel token; fall back to trycloudflare quick tunnel.

    target_url: when set (e.g. http://192.168.1.115:80), quick tunnel exposes
    the terminal directly so Railway API can reach it.
    """
    from paths import load_config, resolve_named_tunnel_url, resolve_tunnel_token

    root = root or find_root()
    cfg = load_config(root)
    token = resolve_tunnel_token(cfg, root)
    if token and not target_url:
        return start_named_tunnel(
            token,
            resolve_named_tunnel_url(cfg, root),
            root,
            cb,
        )
    return start_quick_tunnel(root, cb, target_url=target_url)
