﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Worklyn Link — GitHubdan yuklash + terminal orqali bir martalik ulash.

.DESCRIPTION
  Foydalanuvchidan faqat 3 ta narsa so‘raladi:
    1) Silka (Web URL / connection.hrhub / pairing token)
    2) Admin parol (qurilma; ping uchun link-key ham bo‘lishi mumkin)
    3) Lokatsiya (ro‘yxatdan)

  Qolgani avtomatik: paket → config → LAN qidiruv → ulash → tunnel.

.EXAMPLE
  # Birinchi marta (GitHubdan):
  irm https://raw.githubusercontent.com/Unknown0223/HR_HUB/main/tools/office-link/worklyn.ps1 | iex

.EXAMPLE
  worklyn
  worklyn -Silka "https://hr-hubweb-production.up.railway.app" -Tenant demo
#>
[CmdletBinding()]
param(
  [ValidateSet("install", "connect", "sync", "status", "all", "help")]
  [string]$Command = "all",

  [string]$Silka = "",
  [string]$AdminParol = "",
  [string]$Location = "",
  [string]$Tenant = "",

  [switch]$Force,
  [switch]$FailedOnly,
  [switch]$Clock,
  [switch]$NoQueue,

  [string]$InstallDir = "",
  [string]$Repo = "Unknown0223/HR_HUB",
  [string]$Branch = "main"
)

$ErrorActionPreference = "Stop"

$Script:AppName = "Worklyn Link"
$Script:DefaultInstall = Join-Path $env:LOCALAPPDATA "Programs\HRHUB-Link"
$Script:BinDir = Join-Path $env:LOCALAPPDATA "HRHUB-Link\bin"

function Write-Step([string]$msg) {
  Write-Host $msg -ForegroundColor Cyan
}
function Write-Ok([string]$msg) {
  Write-Host "  OK  $msg" -ForegroundColor Green
}
function Write-Warn([string]$msg) {
  Write-Host "  !   $msg" -ForegroundColor Yellow
}
function Write-Err([string]$msg) {
  Write-Host "  XATO $msg" -ForegroundColor Red
}

function Get-InstallRoot {
  if ($InstallDir) { return $InstallDir }
  $pf = Join-Path ${env:ProgramFiles} "HRHUB-Link"
  if (Test-Path (Join-Path $pf "office_link_cli.py")) { return $pf }
  if (Test-Path (Join-Path $Script:DefaultInstall "office_link_cli.py")) {
    return $Script:DefaultInstall
  }
  # Dev: skript tools\office-link ichida
  if ($PSScriptRoot -and (Test-Path (Join-Path $PSScriptRoot "office_link_cli.py"))) {
    return $PSScriptRoot
  }
  return $Script:DefaultInstall
}

function Get-BundlePython([string]$root) {
  $cand = @(
    (Join-Path $root "runtime\python\python.exe"),
    (Join-Path $root "runtime\python\pythonw.exe")
  )
  foreach ($p in $cand) {
    if (Test-Path $p) { return $p }
  }
  $sys = Get-Command python -ErrorAction SilentlyContinue
  if ($sys) { return $sys.Source }
  return $null
}

function Get-DownloadUrls {
  $base = "https://github.com/$Repo"
  $raw = "https://raw.githubusercontent.com/$Repo/$Branch"
  $githubRaw = "https://github.com/$Repo/raw/$Branch"
  return @(
    "$githubRaw/apps/api/assets/office-link/HRHUB-Link-portable.zip",
    "$base/releases/latest/download/HRHUB-Link-portable.zip",
    "$raw/apps/api/assets/office-link/HRHUB-Link-portable.zip"
  )
}

function Install-WorklynPackage {
  $dest = if ($InstallDir) { $InstallDir } else { $Script:DefaultInstall }
  Write-Step ""
  Write-Step "=== $Script:AppName — o'rnatish ==="
  Write-Step "Papka: $dest"

  $tmp = Join-Path $env:TEMP ("worklyn-pack-" + [guid]::NewGuid().ToString("n"))
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  $zip = Join-Path $tmp "HRHUB-Link-portable.zip"

  $downloaded = $false
  foreach ($url in Get-DownloadUrls) {
    try {
      Write-Step "Yuklanmoqda: $url"
      Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing -TimeoutSec 600
      if ((Get-Item $zip).Length -lt 1MB) { throw "Fayl juda kichik" }
      $downloaded = $true
      Write-Ok ("Yuklandi ({0:N1} MB)" -f ((Get-Item $zip).Length / 1MB))
      break
    } catch {
      Write-Warn "O'tkazib yuborildi: $($_.Exception.Message)"
    }
  }
  if (-not $downloaded) {
    throw "GitHubdan paket yuklanmadi. Internet / repo manzilini tekshiring."
  }

  $extract = Join-Path $tmp "extract"
  New-Item -ItemType Directory -Force -Path $extract | Out-Null
  Expand-Archive -Path $zip -DestinationPath $extract -Force

  # Zip ichida HRHUB-Link\ yoki to'g'ridan fayllar
  $payload = $extract
  $inner = Join-Path $extract "HRHUB-Link"
  if (Test-Path (Join-Path $inner "office_link_app.py")) {
    $payload = $inner
  } elseif (-not (Test-Path (Join-Path $extract "office_link_app.py"))) {
    $hit = Get-ChildItem $extract -Recurse -Filter "office_link_app.py" -ErrorAction SilentlyContinue |
      Select-Object -First 1
    if ($hit) { $payload = $hit.Directory.FullName }
  }
  if (-not (Test-Path (Join-Path $payload "office_link_app.py"))) {
    throw "Paket ichida office_link_app.py topilmadi."
  }

  # Ensure CLI files exist (eski zipda bo'lmasa — raw dan)
  foreach ($extra in @("office_link_cli.py", "worklyn.ps1")) {
    $local = Join-Path $payload $extra
    if (-not (Test-Path $local)) {
      try {
        $u = "https://raw.githubusercontent.com/$Repo/$Branch/tools/office-link/$extra"
        Write-Step "Qo'shimcha: $extra"
        Invoke-WebRequest -Uri $u -OutFile $local -UseBasicParsing -TimeoutSec 60
      } catch {
        Write-Warn "$extra yuklanmadi (keyinroq qo'shiladi)"
      }
    }
  }

  if (Test-Path $dest) {
    Write-Step "Eski nusxa yangilanmoqda..."
    # data/ saqlansin
    $keepData = Join-Path $dest "data"
    $dataBackup = $null
    if (Test-Path $keepData) {
      $dataBackup = Join-Path $tmp "data-backup"
      Copy-Item $keepData $dataBackup -Recurse -Force
    }
    Get-ChildItem $dest -Force | Where-Object { $_.Name -ne "data" } | ForEach-Object {
      Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }
  }
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  Copy-Item (Join-Path $payload "*") $dest -Recurse -Force
  if ($dataBackup -and (Test-Path $dataBackup)) {
    $dataDest = Join-Path $dest "data"
    New-Item -ItemType Directory -Force -Path $dataDest | Out-Null
    Copy-Item (Join-Path $dataBackup "*") $dataDest -Recurse -Force -ErrorAction SilentlyContinue
  }

  Install-WorklynShim -Root $dest
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Write-Ok "O'rnatildi: $dest"
  return $dest
}

function Install-WorklynShim([string]$Root) {
  New-Item -ItemType Directory -Force -Path $Script:BinDir | Out-Null
  $cmd = Join-Path $Script:BinDir "worklyn.cmd"
  $ps1 = Join-Path $Root "worklyn.ps1"
  if (-not (Test-Path $ps1)) {
    $ps1 = Join-Path $PSScriptRoot "worklyn.ps1"
  }
  @"
@echo off
setlocal
set "ROOT=$Root"
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%\worklyn.ps1" %*
"@ | Set-Content -Path $cmd -Encoding ASCII

  $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
  if (-not $userPath) { $userPath = "" }
  $parts = $userPath -split ";" | Where-Object { $_ -and $_.Trim() }
  if ($parts -notcontains $Script:BinDir) {
    $newPath = ($parts + $Script:BinDir) -join ";"
    [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    $env:Path = $Script:BinDir + ";" + $env:Path
    Write-Ok "PATH ga qo'shildi: worklyn"
  } else {
    Write-Ok "worklyn buyrug'i tayyor"
  }
}

function Invoke-WorklynCli([string]$Root, [string]$CliCommand) {
  $py = Get-BundlePython $Root
  if (-not $py) {
    throw "Python topilmadi. Avval: worklyn install"
  }
  $cli = Join-Path $Root "office_link_cli.py"
  if (-not (Test-Path $cli)) {
    # Dev / raw bootstrap: tools papkasidagi CLI
    $alt = Join-Path $PSScriptRoot "office_link_cli.py"
    if (Test-Path $alt) { $cli = $alt }
  }
  if (-not (Test-Path $cli)) {
    throw "office_link_cli.py yo'q — worklyn install qiling."
  }

  $args = @($cli, $CliCommand, "--root", $Root)
  if ($CliCommand -eq "connect") {
    Write-Step ""
    Write-Step "=== Ulash (avtomatik ketma-ketlik) ==="
    Write-Host "  So'raladi: silka → admin parol → lokatsiya" -ForegroundColor DarkGray
    Write-Host "  Avto:      server → LAN → ulash → tunnel → sync" -ForegroundColor DarkGray
    Write-Step ""
    if ($Silka) { $args += @("--silka", $Silka) }
    if ($AdminParol) { $args += @("--admin-parol", $AdminParol) }
    if ($Location) { $args += @("--location", $Location) }
    if ($Tenant) { $args += @("--tenant", $Tenant) }
  } elseif ($CliCommand -eq "sync") {
    Write-Step ""
    Write-Step "=== Sinhron (yuzlar / vaqt) ==="
    Write-Host "  Link yoki worker bilan tezroq; usiz ham LAN orqali ishlaydi" -ForegroundColor DarkGray
    Write-Step ""
    if ($Force) { $args += "--force" }
    if ($FailedOnly) { $args += "--failed-only" }
    if ($Clock) { $args += "--clock" }
    if ($NoQueue) { $args += "--no-queue" }
  }

  & $py @args
  return $LASTEXITCODE
}

function Show-Help {
  @"
Worklyn Link — terminal

O'rnatish + ulash (birinchi marta):
  irm https://raw.githubusercontent.com/Unknown0223/HR_HUB/main/tools/office-link/worklyn.ps1 | iex

Keyin:
  worklyn
  worklyn install
  worklyn connect
  worklyn sync
  worklyn sync -Clock -Force
  worklyn status

Parametrlar:
  -Silka "https://..."     Web / connection.hrhub / pairing
  -AdminParol "****"       Qurilma admin paroli
  -Location "Ofis"         Lokatsiya nomi yoki id
  -Tenant demo
  -InstallDir "C:\..."
  -Force / -FailedOnly / -Clock / -NoQueue   (sync)

connect: silka → admin parol → lokatsiya (qolgani avto).
sync: yuzlar loader + LAN agent (Link bilan yoki usiz).
"@ | Write-Host
}

# ── entry ─────────────────────────────────────────────────────
try {
  if ($Command -eq "help") {
    Show-Help
    return
  }

  $root = Get-InstallRoot
  $needInstall = ($Command -eq "install") -or ($Command -eq "all" -and -not (Test-Path (Join-Path $root "office_link_cli.py")))

  # irm | iex: PSScriptRoot bo'sh — doim o'rnatishga urinish agar paket yo'q
  if (-not $PSScriptRoot -and -not (Test-Path (Join-Path $root "office_link_app.py"))) {
    $needInstall = $true
  }

  if ($needInstall -or $Command -eq "install") {
    $root = Install-WorklynPackage
  } else {
    # Shim yangilash
    if (Test-Path (Join-Path $root "office_link_app.py")) {
      Install-WorklynShim -Root $root
    }
  }

  if ($Command -eq "install") {
    Write-Ok "O'rnatish tugadi. Ulash: worklyn connect"
    return
  }

  $cliCmd = switch ($Command) {
    "sync" { "sync" }
    "status" { "status" }
    "connect" { "connect" }
    default { "connect" }
  }
  $code = Invoke-WorklynCli -Root $root -CliCommand $cliCmd
  if ($null -eq $code) { $code = 0 }
  if ($code -ne 0) { exit $code }
} catch {
  Write-Err $_.Exception.Message
  exit 1
}
