# `worklyn` — terminal orqali bir martalik o‘rnatish

## Birinchi marta (ofis PC)

PowerShell (**Admin shart emas**):

```powershell
irm https://raw.githubusercontent.com/Unknown0223/HR_HUB/main/tools/office-link/worklyn.ps1 | iex
```

Ketma-ketlik (avtomatik tartiblanadi):

1. GitHubdan `HRHUB-Link-portable.zip` yuklanadi → `%LOCALAPPDATA%\Programs\HRHUB-Link`
2. `worklyn` buyrug‘i PATH ga qo‘shiladi
3. **Silka** so‘raladi — Web URL, `connection.hrhub` yoki pairing token
4. **Admin parol** — qurilma admin paroli (server `DEVICE_LINK_KEY` bo‘lsa, shu ham ishlaydi)
5. **Lokatsiya** — ro‘yxatdan tanlash
6. LAN qidiruv → ulash → tunnel / fon worker

## Keyingi marta

```powershell
worklyn
worklyn connect
worklyn install
```

Parametrlar (ixtiyoriy):

```powershell
worklyn connect -Silka "https://hr-hubweb-production.up.railway.app" -Tenant demo -Location "Ofis"
```

## Silka formatlari

| Kirish | Natija |
|--------|--------|
| `https://…web…` | `apiUrl` / `webUrl` avtomatik |
| `connection.hrhub` matni | tenant + API/Web bog‘lanadi |
| Pairing token | `data\pairing.token` |

## Eslatma

- Qurilma va PC **bir LAN** da bo‘lishi kerak.
- Yangi qurilmada Webda admin tasdiq kerak bo‘lishi mumkin.
- Yuzlar: Web → «Синхронизировать».
