"""
Face + clock sync helper for Worklyn Link.

Works:
  - with Link GUI / service_worker running (drains queue faster),
  - without them (one-shot CLI / desktop button still enrolls on LAN),
  - when server pushes via tunnel (helper mainly polls progress).

Progress source of truth = GET office-link/.../sync-progress (same as Web).
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from api_client import is_success, queue_face_sync, sync_progress
from credential_store import read_device_credential
from paths import (
    find_root,
    load_config,
    load_service_config,
    read_link_key,
    read_pairing_token,
)

logger = logging.getLogger("face_sync")

ProgressFn = Callable[[dict[str, Any]], None]


def _ctx(root=None) -> dict[str, Any]:
    root = root or find_root()
    cfg = load_config(root)
    svc = load_service_config(root) or {}
    cred = read_device_credential(root) or {}
    api = str(svc.get("apiUrl") or cfg.get("apiUrl") or "").rstrip("/")
    tenant = str(svc.get("tenantCode") or cfg.get("tenantCode") or "demo")
    device_id = str(cred.get("deviceId") or svc.get("deviceId") or "").strip()
    host = str(cred.get("host") or svc.get("host") or "").strip()
    port = int(cred.get("port") or svc.get("port") or 80)
    username = str(cred.get("username") or svc.get("username") or "admin").strip() or "admin"
    password = str(cred.get("password") or "").strip()
    key = read_link_key(root)
    pairing = read_pairing_token(root) or None
    return {
        "root": root,
        "api": api,
        "tenant": tenant,
        "key": key,
        "pairing": pairing,
        "device_id": device_id,
        "host": host,
        "port": port,
        "username": username,
        "password": password,
    }


def snapshot_progress(root=None) -> dict[str, Any]:
    """Poll server sync-progress (+ local credential hints)."""
    c = _ctx(root)
    out: dict[str, Any] = {
        "ok": False,
        "running": False,
        "phase": "idle",
        "percent": 0,
        "synced": 0,
        "total": 0,
        "pending": 0,
        "failed": 0,
        "message": "",
        "deviceId": c["device_id"],
        "host": c["host"],
        "hasCredentials": bool(c["key"] or c["pairing"]),
        "mode": "unknown",
    }
    if not c["api"] or not c["device_id"]:
        out["message"] = "Ulash qilinmagan (deviceId yo‘q)"
        return out
    if not c["key"] and not c["pairing"]:
        out["message"] = "link.key yoki pairing token kerak"
        return out
    code, data = sync_progress(
        c["api"],
        c["key"],
        c["tenant"],
        device_id=c["device_id"],
        pairing_token=c["pairing"],
    )
    if not is_success(code) or not isinstance(data, dict):
        msg = ""
        if isinstance(data, dict):
            msg = str(data.get("message") or data.get("error") or "")
        out["message"] = msg or f"sync-progress HTTP {code}"
        return out
    out.update(
        {
            "ok": True,
            "running": bool(data.get("running")),
            "phase": str(data.get("phase") or "idle"),
            "percent": int(data.get("percent") or 0),
            "synced": int(data.get("synced") or 0),
            "total": int(data.get("total") or 0),
            "pending": int(data.get("pending") or 0),
            "syncing": int(data.get("syncing") or 0),
            "failed": int(data.get("failed") or 0),
            "done": int(data.get("done") or 0),
            "message": str(data.get("message") or ""),
            "currentNames": data.get("currentNames") or [],
            "failures": data.get("failures") or [],
            "inFlight": bool(data.get("inFlight")),
        }
    )
    remaining = out["pending"] + int(out.get("syncing") or 0)
    phase = out["phase"]
    if phase == "awaiting_office_agent" or (remaining > 0 and not out.get("inFlight")):
        out["mode"] = "agent"  # LAN drain helps most
    elif out["running"] or remaining > 0:
        out["mode"] = "server"  # tunnel/API waves
    else:
        out["mode"] = "idle"
    return out


def queue_sync(root=None, *, force: bool = False, failed_only: bool = False) -> dict[str, Any]:
    c = _ctx(root)
    if not c["api"] or not c["device_id"]:
        return {"ok": False, "message": "Ulash qilinmagan"}
    if not c["key"] and not c["pairing"]:
        return {"ok": False, "message": "link.key yoki pairing token kerak"}
    code, data = queue_face_sync(
        c["api"],
        c["key"],
        c["tenant"],
        device_id=c["device_id"],
        force=force,
        failed_only=failed_only,
        pairing_token=c["pairing"],
    )
    if not is_success(code):
        msg = ""
        if isinstance(data, dict):
            msg = str(data.get("message") or data.get("error") or "")
        return {"ok": False, "message": msg or f"sync HTTP {code}", "http": code}
    if isinstance(data, dict):
        return {"ok": True, **data}
    return {"ok": True, "raw": data}


def drain_once(root=None) -> dict[str, Any]:
    """One LAN enroll cycle (same as service_worker). Safe if tunnel also pushes."""
    from face_agent import tick_once

    return tick_once(root)


def sync_clock_local(root=None) -> dict[str, Any]:
    """Set terminal clock via LAN ISAPI (no Web/GW required)."""
    c = _ctx(root)
    if not c["host"] or not c["password"]:
        return {"ok": False, "message": "host/password yo‘q — avval Ulash"}
    from isapi_http import digest_httpx

    # Asia/Tashkent UTC+5 (same as API reach client)
    now = datetime.now(timezone.utc) + timedelta(hours=5)
    local = now.strftime("%Y-%m-%dT%H:%M:%S")
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        "<Time>"
        "<timeMode>manual</timeMode>"
        f"<localTime>{local}+05:00</localTime>"
        "<timeZone>CST-5:00:00</timeZone>"
        "</Time>"
    )
    try:
        code, text = digest_httpx(
            c["host"],
            c["port"],
            "PUT",
            "/ISAPI/System/time",
            c["username"],
            c["password"],
            content=xml.encode("utf-8"),
            content_type="application/xml",
            timeout=(5.0, 20.0),
            retries=2,
        )
        if 200 <= int(code or 0) < 400:
            return {"ok": True, "message": f"Vaqt yangilandi: {local} (+05:00)", "localTime": local}
        return {"ok": False, "message": f"sync_clock HTTP {code}: {(text or '')[:160]}"}
    except Exception as exc:
        return {"ok": False, "message": str(exc)[:200]}


def run_face_sync(
    root=None,
    *,
    force: bool = False,
    failed_only: bool = False,
    queue: bool = True,
    max_seconds: float = 1800.0,
    idle_rounds: int = 4,
    on_progress: ProgressFn | None = None,
) -> dict[str, Any]:
    """
    Queue (optional) + drain pending faces until done or timeout.

    Speeds up sync when Link/worker is up by tight LAN drain; still works
    alone. If server is already uploading via tunnel, we mostly poll + help.
    """
    root = root or find_root()
    started = time.monotonic()
    summary: dict[str, Any] = {
        "ok": False,
        "queued": False,
        "ticks": 0,
        "upsertOk": 0,
        "upsertFail": 0,
        "deleteOk": 0,
        "message": "",
    }

    if queue:
        q = queue_sync(root, force=force, failed_only=failed_only)
        summary["queued"] = bool(q.get("ok"))
        summary["queue"] = q
        if not q.get("ok"):
            summary["message"] = str(q.get("message") or "Navbatga qo‘yilmadi")
            if on_progress:
                on_progress({**snapshot_progress(root), "local": summary})
            return summary

    quiet = 0
    while True:
        prog = snapshot_progress(root)
        if on_progress:
            on_progress({**prog, "local": dict(summary)})

        remaining = int(prog.get("pending") or 0) + int(prog.get("syncing") or 0)
        running = bool(prog.get("running"))
        phase = str(prog.get("phase") or "")

        # Help drain whenever there is work (agent mode or assisting server).
        if remaining > 0 or phase in ("awaiting_office_agent", "queuing", "uploading", "purging"):
            tick = drain_once(root)
            summary["ticks"] += 1
            summary["upsertOk"] += int(tick.get("upsertOk") or 0)
            summary["upsertFail"] += int(tick.get("upsertFail") or 0)
            summary["deleteOk"] += int(tick.get("deleteOk") or 0)
            did_work = (
                int(tick.get("upsertOk") or 0)
                + int(tick.get("upsertFail") or 0)
                + int(tick.get("deleteOk") or 0)
                + int(tick.get("deleteFail") or 0)
                + int(tick.get("purgeOk") or 0)
            ) > 0
            pending_local = int(tick.get("pending") or 0)
            if did_work or pending_local > 0:
                quiet = 0
            else:
                quiet += 1
            # Brief pause — faster than service_worker 20s loop
            time.sleep(0.35 if did_work else 0.8)
        else:
            quiet += 1
            time.sleep(0.6)

        if time.monotonic() - started > max_seconds:
            summary["message"] = "Vaqt tugadi — sync fonida davom etishi mumkin"
            summary["ok"] = int(prog.get("synced") or 0) > 0
            break

        if remaining == 0 and not running and phase in ("completed", "idle", "failed", ""):
            # Confirm with a couple of quiet rounds (server may lag meta)
            if quiet >= idle_rounds:
                failed = int(prog.get("failed") or 0)
                synced = int(prog.get("synced") or 0)
                total = int(prog.get("total") or 0)
                summary["ok"] = failed == 0 or synced > 0
                if phase == "failed" or (failed and synced == 0):
                    summary["message"] = prog.get("message") or "Sync xato bilan tugadi"
                    summary["ok"] = False
                elif failed:
                    summary["message"] = (
                        f"Tayyor: {synced}/{total}, xato: {failed}"
                    )
                else:
                    summary["message"] = prog.get("message") or f"Tayyor: {synced}/{total or synced}"
                break

    final = snapshot_progress(root)
    summary["progress"] = final
    if on_progress:
        on_progress({**final, "local": dict(summary), "done": True})
    return summary
