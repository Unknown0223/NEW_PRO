"""Shared GW + Cloudflare tunnel health checks and autonomous restore."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.error import URLError
from urllib.request import Request, urlopen

from paths import (
    find_root,
    load_config,
    load_service_config,
    read_link_key,
    read_tunnel_url,
    resolve_named_tunnel_url,
    resolve_tunnel_token,
    runtime_dir,
    service_status_file,
    set_tunnel_cooldown,
    tunnel_cooldown_remaining,
    user_data_root,
    write_service_config,
    write_tunnel_url,
)
from runtime_setup import (
    CREATE_NO_WINDOW,
    GW_PORT,
    ServiceBundle,
    ensure_runtime,
    ensure_tunnel_tools,
    portable_pythonw,
    start_gateway,
    start_tunnel,
)

StatusFn = Callable[[str], None]


@dataclass
class TunnelHealth:
    gw_process: bool
    tunnel_process: bool
    gw_http: bool
    tunnel_http: bool | None  # None = could not probe (DNS / no URL)
    tunnel_url: str
    mode: str
    ok: bool
    message: str
    reach_mode: str = "gw"  # "device" = direct tunnel to terminal (no local :8800)


def _resolve_device_host(root: Path, svc: dict) -> tuple[str, int]:
    """Host/port for direct terminal tunnel (preferred over local GW)."""
    try:
        from credential_store import peek_device_host, read_device_credential

        cred = read_device_credential(root) or peek_device_host(root) or {}
    except Exception:
        cred = {}
    host = str(cred.get("host") or svc.get("host") or "").strip()
    port = int(cred.get("port") or svc.get("port") or 80)
    return host, port


def probe_local_gw(timeout: float = 2.0) -> bool:
    try:
        with urlopen(f"http://127.0.0.1:{GW_PORT}/health", timeout=timeout) as resp:
            if resp.status != 200:
                return False
            body = resp.read().decode("utf-8", errors="replace")
            data = json.loads(body) if body.strip().startswith("{") else {}
            return data.get("status") == "ok" or "hr-hub-device-gw" in body
    except Exception:
        return False


def probe_tunnel_url(url: str, timeout: float = 8.0) -> bool | None:
    """Return True/False if reachable; None if URL empty or local DNS likely broken."""
    clean = (url or "").strip().rstrip("/")
    if not clean.startswith("http"):
        return None
    try:
        req = Request(f"{clean}/health", method="GET")
        with urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return False
            body = resp.read().decode("utf-8", errors="replace")
            return "hr-hub-device-gw" in body or '"status":"ok"' in body.replace(" ", "")
    except URLError as e:
        reason = str(getattr(e, "reason", e)).lower()
        # Windows often cannot resolve *.trycloudflare.com via local DNS.
        if "getaddrinfo" in reason or "name or service" in reason or "11001" in reason:
            return None
        return False
    except Exception:
        return False


def _proc_alive(proc) -> bool:
    return proc is not None and getattr(proc, "poll", lambda: 0)() is None


def snapshot_health(
    bundle: ServiceBundle | None = None,
    root: Path | None = None,
) -> TunnelHealth:
    root = root or find_root()
    cfg = load_config(root)
    svc = load_service_config(root)
    mode = "named" if resolve_tunnel_token(cfg, root) else "quick"
    reach_mode = str(svc.get("reachMode") or "").strip().lower()
    host, _port = _resolve_device_host(root, svc)
    # Direct tunnel to the terminal does not use local :8800 gateway.
    # Infer device mode when credentials already know the terminal IP.
    device_reach = reach_mode == "device" or (not reach_mode and bool(host))
    if device_reach:
        reach_mode = "device"
    url = ""
    if bundle is not None:
        url = str(getattr(bundle, "tunnel_url", "") or "").strip()
    if not url:
        url = read_tunnel_url(root) or resolve_named_tunnel_url(cfg, root)

    gw_proc = _proc_alive(getattr(bundle, "gw", None)) if bundle else False
    tun_proc = _proc_alive(getattr(bundle, "tunnel", None)) if bundle else False
    # Also treat pid files as hint when GUI detached.
    if not gw_proc:
        gw_proc = _pidfile_alive(runtime_dir(root) / "gw.pid")
    if not tun_proc:
        tun_proc = _pidfile_alive(runtime_dir(root) / "tunnel.pid")

    gw_http = False if device_reach else probe_local_gw()
    # /health is device-gw only; direct terminal tunnels won't match that body.
    tun_http = None
    if url and not device_reach:
        tun_http = probe_tunnel_url(url)
    elif url and tun_proc:
        tun_http = True
    elif url:
        tun_http = probe_tunnel_url(url)

    lan_fallback = bool(svc.get("lanFallback"))
    lan_url = bool(url) and (
        "trycloudflare.com" not in url.lower()
        and "cfargotunnel.com" not in url.lower()
        and url.lower().startswith("http://")
    )

    if device_reach:
        if lan_fallback and lan_url:
            ok = True
            message = "LAN (Cloudflare siz) — API → терминал"
            mode = "lan"
        elif tun_proc and url:
            ok = True
            message = "Туннель -> терминал работает"
        elif tun_proc:
            ok = False
            message = "cloudflared есть, URL туннеля пуст"
        elif url and tun_http is not False:
            ok = False
            message = "Процесс cloudflared отсутствует — нажмите «Восстановить туннель»"
        else:
            ok = False
            message = "Туннель к терминалу не активен — нажмите «Восстановить туннель»"
    elif gw_http and (tun_http is True or (tun_http is None and tun_proc)):
        ok = True
        message = "Шлюз и туннель работают"
    elif not gw_http:
        ok = False
        message = "Локальный шлюз (8800) не отвечает"
    elif tun_http is False:
        ok = False
        message = "URL туннеля мёртв — нужно открыть снова"
    elif not tun_proc:
        ok = False
        message = "Процесс cloudflared отсутствует"
    else:
        ok = False
        message = "Состояние туннеля неизвестно"

    return TunnelHealth(
        gw_process=gw_proc,
        tunnel_process=tun_proc,
        gw_http=gw_http,
        tunnel_http=tun_http,
        tunnel_url=url,
        mode=mode,
        ok=ok,
        message=message,
        reach_mode=reach_mode or "gw",
    )


def _pidfile_alive(path: Path) -> bool:
    try:
        if not path.is_file():
            return False
        pid = int(path.read_text(encoding="utf-8").strip().splitlines()[0])
        if pid <= 0:
            return False
        if sys.platform == "win32":
            import ctypes

            SYNCHRONIZE = 0x00100000
            handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def write_status(root: Path, payload: dict) -> None:
    path = service_status_file(root)
    body = dict(payload)
    body["updatedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def announce_best_effort(
    root: Path,
    api_url: str,
    tenant: str,
    tunnel_url: str,
    device_id: str | None = None,
) -> bool:
    from paths import read_pairing_token

    key = read_link_key(root)
    pairing = read_pairing_token(root)
    if (not key and not pairing) or not tunnel_url:
        return False
    try:
        import api_client

        code, _ = api_client.announce(
            api_url,
            key or "",
            tenant,
            tunnel_url,
            pairing_token=pairing or None,
            device_id=device_id,
        )
        return 200 <= int(code) < 300
    except Exception:
        return False


def restore_lan_reach(
    *,
    root: Path,
    host: str,
    port: int,
    api_url: str,
    tenant: str,
    device_id: str,
    bundle: ServiceBundle | None,
    on_status: StatusFn | None = None,
) -> tuple[ServiceBundle, str]:
    """Announce device LAN URL to API when Cloudflare quick-tunnel is blocked.

    Local/dev API on the same LAN can reach the terminal without cloudflared.
    """
    def emit(msg: str) -> None:
        if on_status:
            on_status(msg)

    if not host:
        raise RuntimeError(
            "LAN host noma’lum — avval «Восстановить сеть» yoki qurilmani tanlang"
        )
    url = f"http://{host}:{int(port or 80)}"
    emit(f"LAN ulanish: {url} (Cloudflare siz)…")
    if bundle is None:
        bundle = ServiceBundle()
        bundle.root = root
    bundle.tunnel_url = url
    write_tunnel_url(url, root)
    ok = announce_best_effort(
        root, api_url, tenant, url, device_id=device_id or None
    )
    if not ok:
        raise RuntimeError(
            "LAN announce API ga yetmadi. Pairing-token / link.key va "
            f"apiUrl ({api_url}) ni tekshiring."
        )
    write_service_config(
        api_url=api_url,
        tenant=tenant,
        tunnel_mode="quick",
        root=root,
        extra={
            "tunnelUrl": url,
            "autoHeal": True,
            "faceAgent": True,
            "deviceId": device_id,
            "host": host,
            "port": int(port or 80),
            "reachMode": "device",
            "lanFallback": True,
        },
    )
    write_status(
        root,
        {
            "ok": True,
            "state": "running",
            "tunnelMode": "lan",
            "tunnelUrl": url,
            "apiUrl": api_url,
            "tenantCode": tenant,
            "deviceId": device_id,
            "reachTarget": f"{host}:{int(port or 80)}",
            "announced": True,
            "lanFallback": True,
            "faceAgent": True,
            "message": f"LAN announce OK: {url}",
        },
    )
    emit(f"LAN announce OK: {url}")
    return bundle, url

def restore_tunnel(
    *,
    root: Path | None = None,
    bundle: ServiceBundle | None = None,
    on_status: StatusFn | None = None,
    keep_bundle: bool = True,
) -> tuple[ServiceBundle, str]:
    """Open Cloudflare tunnel to the terminal (preferred) so Railway can reach it.

    If Cloudflare quick-tunnel is rate-limited, fall back to LAN announce
    (enough for local API on the same network as the terminal).
    """
    root = root or find_root()
    cfg = load_config(root)
    svc = load_service_config(root)
    api_url = str(svc.get("apiUrl") or cfg.get("apiUrl") or "").rstrip("/")
    tenant = str(svc.get("tenantCode") or cfg.get("tenantCode") or "demo")
    from paths import read_pairing_token

    key = read_link_key(root)
    pairing = read_pairing_token(root)
    if not api_url:
        raise RuntimeError("apiUrl отсутствует (config / service.json)")
    if not key and not pairing:
        raise RuntimeError("Нет data/link.key / pairing.token — сначала подключение / pairing")

    from credential_store import peek_device_host, read_device_credential

    cred = read_device_credential(root) or {}
    peek = peek_device_host(root) if not cred else {}
    host = str(
        cred.get("host") or peek.get("host") or svc.get("host") or ""
    ).strip()
    port = int(cred.get("port") or peek.get("port") or svc.get("port") or 80)
    device_id = str(
        cred.get("deviceId") or peek.get("deviceId") or svc.get("deviceId") or ""
    ).strip()

    def emit(msg: str) -> None:
        if on_status:
            on_status(msg)

    left = tunnel_cooldown_remaining(root)
    if left > 0:
        mins = max(1, (left + 59) // 60)
        if host:
            emit(f"Cloudflare limithi (~{mins} daq) — LAN orqali davom etamiz…")
            return restore_lan_reach(
                root=root,
                host=host,
                port=port,
                api_url=api_url,
                tenant=tenant,
                device_id=device_id,
                bundle=bundle,
                on_status=on_status,
            )
        raise RuntimeError(
            f"Cloudflare limithi hali kuchda. Yana ~{mins} daqiqa kutib, "
            "keyin bir marta «Восстановить туннель» bosing. "
            "Avval «Восстановить сеть» bilan qurilma IP ni toping — "
            "keyin LAN orqali ishlaydi."
        )

    if bundle is None:
        bundle = ServiceBundle()
        bundle.root = root
    else:
        emit("Остановка старого GW/tunnel…")
        bundle.stop()

    # Prefer direct tunnel → terminal so API (Railway) can sync faces.
    target = f"http://{host}:{port}" if host else ""
    try:
        if target:
            # Device path only needs cloudflared — skip portable Python / gw pip.
            emit("Проверка tunnel dasturi…")
            ensure_tunnel_tools(root, on_status)
            emit(f"Туннель -> терминал {host}:{port}...")
            proc, url = start_tunnel(root, on_status, target_url=target)
            bundle.tunnel = proc
            bundle.tunnel_url = url
            bundle.gw = None
        else:
            emit("Проверка runtime…")
            ensure_runtime(root, on_status)
            emit("Запуск gateway…")
            bundle.gw = start_gateway(api_url, key, root, on_status)
            emit("Открытие туннеля…")
            proc, url = start_tunnel(root, on_status)
            bundle.tunnel = proc
            bundle.tunnel_url = url
    except Exception as exc:
        msg = str(exc)
        if "429" in msg or "1015" in msg or "limithi" in msg.lower():
            set_tunnel_cooldown(900, reason="cloudflare_429", root=root)
            if host:
                emit("Cloudflare 429 — LAN announce ga o‘tamiz…")
                return restore_lan_reach(
                    root=root,
                    host=host,
                    port=port,
                    api_url=api_url,
                    tenant=tenant,
                    device_id=device_id,
                    bundle=bundle,
                    on_status=on_status,
                )
        raise

    if not url:
        raise RuntimeError("URL туннеля не получен")

    write_tunnel_url(url, root)
    emit("Announce на платформу…")
    ok = announce_best_effort(root, api_url, tenant, url, device_id=device_id or None)
    mode = "named" if resolve_tunnel_token(cfg, root) else "quick"
    write_service_config(
        api_url=api_url,
        tenant=tenant,
        tunnel_mode=mode,
        root=root,
        extra={
            "tunnelUrl": url,
            "namedTunnelUrl": resolve_named_tunnel_url(cfg, root),
            "autoHeal": True,
            "faceAgent": True,
            "deviceId": device_id,
            "host": host,
            "port": port,
            "reachMode": "device" if target else "gw",
        },
    )
    write_status(
        root,
        {
            "ok": True,
            "state": "running",
            "tunnelMode": mode,
            "tunnelUrl": url,
            "apiUrl": api_url,
            "tenantCode": tenant,
            "deviceId": device_id,
            "reachTarget": target or f"127.0.0.1:{GW_PORT}",
            "announced": ok,
            "message": (
                "Server->terminal tunnel OK"
                if ok
                else "Туннель открыт (announce хато — qayta uriniladi)"
            ),
        },
    )
    if not keep_bundle:
        pass
    return bundle, url


def _worker_pythonw(root: Path) -> str:
    """Bundled runtime first — the package must not depend on a system Python."""
    for cand in (
        portable_pythonw(root),
        user_data_root() / "runtime" / "python" / "pythonw.exe",
        Path(sys.executable).with_name("pythonw.exe"),
    ):
        if cand.is_file():
            return str(cand)
    return sys.executable


def install_startup_task(root: Path | None = None) -> bool:
    """Register ONLOGON scheduled task so tunnel stays up without opening the GUI.

    No admin required for current-user tasks. Returns True if created/updated.
    """
    if sys.platform != "win32":
        return False
    root = root or find_root()
    worker = root / "service_worker.py"
    if not worker.is_file():
        worker = root / "face_worker.py"
    if not worker.is_file():
        return False

    tr = f'"{_worker_pythonw(root)}" "{worker}"'
    cmd = [
        "schtasks",
        "/Create",
        "/TN",
        "HRHUB-OfficeLink",
        "/TR",
        tr,
        "/SC",
        "ONLOGON",
        "/RL",
        "LIMITED",
        "/F",
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(root),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=CREATE_NO_WINDOW,
        )
        return proc.returncode == 0
    except Exception:
        return False


def _worker_already_running(*script_names: str) -> bool:
    """True if a service_worker / face_worker process is already alive."""
    if sys.platform != "win32" or not script_names:
        return False
    try:
        pattern = "|".join(n.replace(".", r"\.") for n in script_names)
        ps = (
            "Get-CimInstance Win32_Process | "
            f"Where-Object {{ $_.CommandLine -match '{pattern}' }} | "
            "Measure-Object | Select-Object -ExpandProperty Count"
        )
        powershell = (
            Path(os.environ.get("SystemRoot", r"C:\Windows"))
            / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
        )
        proc = subprocess.run(
            [str(powershell) if powershell.is_file() else "powershell", "-NoProfile", "-Command", ps],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=CREATE_NO_WINDOW,
            timeout=8,
        )
        return int((proc.stdout or "0").strip() or "0") > 0
    except Exception:
        return False


def spawn_detached_worker(root: Path | None = None) -> bool:
    """Start background worker: full service_worker, or face_worker if GW already up."""
    root = root or find_root()
    here = Path(__file__).resolve().parent
    worker = root / "service_worker.py"
    face_only = root / "face_worker.py"
    if not worker.is_file():
        worker = here / "service_worker.py"
    if not face_only.is_file():
        face_only = here / "face_worker.py"
    # Prefer full service_worker (punch proxy + HttpHost reconcile + face).
    # face_worker is fallback only when service_worker.py is missing.
    target = worker if worker.is_file() else face_only
    if not target.is_file():
        return False

    # Single-instance: never stack another face/service worker.
    if _worker_already_running("service_worker.py", "face_worker.py"):
        return True

    py = _worker_pythonw(root)

    flags = 0
    if sys.platform == "win32":
        flags = (
            subprocess.DETACHED_PROCESS
            | subprocess.CREATE_NEW_PROCESS_GROUP
            | CREATE_NO_WINDOW
        )
    try:
        subprocess.Popen(
            [py, str(target)],
            cwd=str(target.parent),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
            close_fds=True,
        )
        return True
    except Exception:
        return False
