@echo off
REM Worklyn Link — ilovani ochish (ichki Python, tashqi dastur kerak emas).
cd /d "%~dp0"
if exist "%~dp0runtime\python\pythonw.exe" (
  start "" /D "%~dp0" "%~dp0runtime\python\pythonw.exe" "%~dp0office_link_app.py"
  exit /b 0
)
echo [XATO] runtime\python topilmadi — paketni qayta oching yoki qayta o'rnating.
pause
exit /b 1
