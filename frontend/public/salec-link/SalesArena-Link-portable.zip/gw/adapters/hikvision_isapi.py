"""Hikvision ISAPI adapter — UserInfo, FaceDataRecord, AcsEvent, alertStream.

Reference (Hikvision TPP): Access Control ISAPI for MinMoe terminals
(DS-K1T671M, DS-K1T341, …). Digest/Basic auth via httpx.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import httpx

from .base import DeviceAdapter
from .hikvision_audit import (
    MAJOR_OPERATION,
    build_operation_log,
    diff_config,
    flatten_json,
    flatten_xml,
    person_entry,
)

logger = logging.getLogger("hikvision-isapi")

# Ignore small NTP/network jitter; larger skew is treated as clock tampering.
CLOCK_SKEW_SECONDS = 180
# While online, push server time if the terminal drifted more than this.
CLOCK_ALIGN_SECONDS = 15
# Already close enough — do not write time (avoids fighting the RTC).
CLOCK_MATCH_SECONDS = 2
# Re-check periodically; only write if still off by CLOCK_MATCH_SECONDS.
CLOCK_ALIGN_INTERVAL_SECONDS = 5 * 60
# Do not re-enable punches a few seconds after admin login (menu still open).
PUNCH_LOCK_MIN_SECONDS = 120
# Hikvision ACS operation minors (MAJOR_OPERATION = 3).
MINOR_LOCAL_LOGIN = 80  # 0x50 — admin password entered on the terminal
MINOR_LOCAL_LOGOUT = 81
# Config snapshot the admin-session diff is compared against.
CONFIG_BASELINE_REFRESH = timedelta(minutes=10)
# Report the session even if no logout event shows up (menu left open, GW missed it).
ADMIN_AUDIT_MAX_SESSION = timedelta(minutes=15)
SNAPSHOT_PATHS = (
    "/ISAPI/Streaming/channels/1/picture",
    "/ISAPI/Streaming/channels/101/picture",
    "/ISAPI/Streaming/channels/1/picture?snapShotImageType=JPEG",
)
PERSONS_PAGE_SIZE = 30
PERSONS_MAX_PAGES = 100


def _xml_text(value: str) -> str:
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _xml_local(tag: str) -> str:
    return tag.split("}")[-1] if tag else ""


def hikvision_password_error(password: str, username: str = "") -> Optional[str]:
    """Hikvision MinMoe (DS-K1T) activation-password rules."""
    pwd = password or ""
    if len(pwd) < 8 or len(pwd) > 16:
        return "Пароль должен быть от 8 до 16 символов"
    user = (username or "").strip()
    if user and user.lower() in pwd.lower():
        return "Пароль не должен содержать имя пользователя"
    classes = 0
    if any(c.islower() for c in pwd):
        classes += 1
    if any(c.isupper() for c in pwd):
        classes += 1
    if any(c.isdigit() for c in pwd):
        classes += 1
    if any(not c.isalnum() for c in pwd):
        classes += 1
    if classes < 2:
        return (
            "Нужны минимум 2 типа символов: заглавные, строчные, цифры или спецсимволы"
        )
    return None


def isapi_status_message(status_code: int, body: str) -> str:
    text = (body or "").strip()
    if not text:
        return f"HTTP {status_code}"
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            msg = (
                data.get("errorMsg")
                or data.get("subStatusCode")
                or data.get("statusString")
            )
            if msg:
                return str(msg)
    except Exception:  # noqa: BLE001
        pass
    try:
        root = ET.fromstring(text)
        found: dict[str, str] = {}
        for el in root.iter():
            loc = _xml_local(el.tag)
            if el.text and el.text.strip():
                found[loc] = el.text.strip()
        msg = (
            found.get("errorMsg")
            or found.get("subStatusCode")
            or found.get("statusString")
        )
        if msg:
            if msg == "loginPassword" or msg == "MessageParametersLack":
                return "Терминал требует текущий пароль (loginPassword)"
            return msg
    except Exception:  # noqa: BLE001
        pass
    return text[:240]


def hikvision_employee_no(employee_id: str) -> str:
    """DS-K1T343 rejects non-numeric employeeNo (errorMsg=employeeNo)."""
    digits = "".join(ch for ch in str(employee_id) if ch.isdigit())
    if not digits:
        return str(employee_id)[:32]
    return str(int(digits))


class HikvisionIsapiAdapter(DeviceAdapter):
    def __init__(
        self,
        host: str,
        port: int = 80,
        username: str = "admin",
        password: str = "",
        model: Optional[str] = None,
        use_https: bool = False,
    ):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.model = model
        self.use_https = use_https
        self._client: Optional[httpx.AsyncClient] = None
        self._subscribe_task: Optional[asyncio.Task] = None
        self._event_queue: list[dict[str, Any]] = []
        self._seen_event_keys: set[str] = set()
        self._on_realtime_event: Optional[Any] = None  # async (punch: dict) -> None
        self._pending_realtime_punch: Optional[dict[str, Any]] = None
        self._pending_realtime_flush: Optional[asyncio.Task] = None
        self._orphan_jpeg_b64: Optional[str] = None
        self._orphan_jpeg_at: Optional[datetime] = None
        self.realtime_connected: bool = False
        self.last_realtime_at: Optional[datetime] = None
        self.last_drift_seconds: float = 0.0
        self.last_device_now_iso: Optional[str] = None
        self.last_clock_sync_at: Optional[datetime] = None
        self.punch_locked: bool = False
        self.awaiting_sync_unlock: bool = False
        self.admin_login_at: Optional[str] = None
        self.admin_login_serial: int = 0
        self.last_admin_login_serial: int = 0
        self.lock_method: Optional[str] = None
        self.lock_started_at: Optional[datetime] = None
        self.clock_synced_after_lock: bool = False
        # True only after local admin login AND device clock drifted/changed.
        self.time_changed_after_lock: bool = False
        # After unlock, still reject punches that happened in the fraud window.
        self.fraud_window_start: Optional[str] = None
        self.fraud_window_end: Optional[str] = None
        self._saved_card_reader: Optional[tuple[str, dict[str, Any]]] = None
        self.saw_local_logout: bool = False
        self._acs_skip_minors: set[int] = set()
        self.auth_failed: bool = False
        self.clock_read_ok: bool = False
        self.auth_lock_until: Optional[datetime] = None
        self._config_baseline: Optional[dict[str, Any]] = None
        self._config_baseline_at: Optional[datetime] = None
        # employeeNos Worklyn itself wrote since the baseline (not the admin's doing).
        self._own_person_changes: set[str] = set()
        self._snapshot_path: Optional[str] = None
        self.admin_audit: Optional[dict[str, Any]] = None
        # Hikvision DigestAuth is not safe under concurrent ISAPI calls
        # (AcsEvent poll + face enroll) — serialize all adapter HTTP.
        self._http_lock = asyncio.Lock()

    @property
    def base_url(self) -> str:
        scheme = "https" if self.use_https else "http"
        return f"{scheme}://{self.host}:{self.port}"

    async def connect(self) -> None:
        # Prefer Digest (typical for Hikvision); fall back handled by httpx DigestAuth
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            auth=httpx.DigestAuth(self.username, self.password),
            timeout=httpx.Timeout(8.0, connect=2.0),
            verify=False,
        )
        logger.info(
            "HikvisionIsapiAdapter connected to %s model=%s",
            self.base_url,
            self.model,
        )
        try:
            await self.ensure_capture_photo_settings()
        except Exception as exc:  # noqa: BLE001
            logger.warning("ensure capture photo settings failed: %s", exc)
        if self.punch_locked:
            try:
                await self.set_punching_enabled(False)
            except Exception as exc:  # noqa: BLE001
                logger.warning("restore punch lock on connect failed: %s", exc)

    async def ensure_capture_photo_settings(self) -> None:
        """Enable terminal save/upload of authentication capture snapshots.

        Without these flags AcsEvent returns picturesNumber=1 but no pictureURL,
        and alertStream often omits the JPEG MIME part — marks ФОТО stays empty.
        """
        if not self._client:
            return
        resp = await self._client.get("/ISAPI/AccessControl/AcsCfg?format=json")
        if resp.status_code >= 400:
            logger.warning("AcsCfg read %s %s", resp.status_code, resp.text[:160])
            return
        data = resp.json()
        acs = data.get("AcsCfg") if isinstance(data, dict) else None
        if not isinstance(acs, dict):
            return
        wanted = {
            "uploadCapPic": True,
            "saveCapPic": True,
            "uploadVerificationPic": True,
            "saveVerificationPic": True,
            "showPicture": True,
        }
        changed = False
        for key, val in wanted.items():
            if key not in acs:
                continue
            if acs.get(key) is not True:
                acs[key] = val
                changed = True
        if not changed:
            return
        put = await self._client.put(
            "/ISAPI/AccessControl/AcsCfg?format=json",
            json=data,
        )
        if put.status_code >= 400:
            logger.warning("AcsCfg write %s %s", put.status_code, put.text[:160])
            return
        logger.info("AcsCfg: capture photo save/upload enabled")

    async def disconnect(self) -> None:
        if self._subscribe_task and not self._subscribe_task.done():
            self._subscribe_task.cancel()
            try:
                await self._subscribe_task
            except asyncio.CancelledError:
                pass
            self._subscribe_task = None
        if self._client:
            await self._client.aclose()
            self._client = None

    def auth_locked(self) -> bool:
        if not self.auth_lock_until:
            return False
        if datetime.now(timezone.utc) >= self.auth_lock_until:
            self.auth_lock_until = None
            return False
        return True

    def _note_auth_response(
        self,
        resp: httpx.Response,
        *,
        mark_auth_failed: bool = True,
    ) -> None:
        """Parse Hikvision 401 lockStatus/unlockTime to avoid hammering lockouts.

        alertStream often returns 401 while deviceInfo Digest auth still works —
        do not flip passwordOutOfSync from that path (mark_auth_failed=False).
        """
        if resp.status_code != 401:
            return
        if mark_auth_failed:
            self.auth_failed = True
        text = resp.text or ""
        if "<lockStatus>lock</lockStatus>" not in text and "lockStatus>lock" not in text:
            return
        # unlockTime is seconds remaining
        m = re.search(r"<unlockTime>\s*(\d+)\s*</unlockTime>", text)
        secs = int(m.group(1)) if m else 120
        secs = max(30, min(secs + 5, 3600))
        self.auth_lock_until = datetime.now(timezone.utc) + timedelta(seconds=secs)
        logger.warning(
            "device ISAPI locked — backoff %ss until %s",
            secs,
            self.auth_lock_until.isoformat(),
        )

    async def heartbeat(self) -> bool:
        """Probe deviceInfo with a fresh Digest client (shared client races AcsEvent)."""
        if self.auth_locked():
            return False
        try:
            async with await self._command_client() as client:
                resp = await client.get("/ISAPI/System/deviceInfo")
                if resp.status_code == 401:
                    self._note_auth_response(resp)
                    return False
                if resp.status_code < 400:
                    self.auth_failed = False
                    self.auth_lock_until = None
                    return True
                resp2 = await client.get("/ISAPI/System/deviceInfo?format=json")
                if resp2.status_code == 401:
                    self._note_auth_response(resp2)
                    return False
                ok = resp2.status_code < 400
                if ok:
                    self.auth_failed = False
                    self.auth_lock_until = None
                return ok
        except Exception as exc:  # noqa: BLE001
            logger.warning("heartbeat failed: %s", exc)
            return False

    async def _command_client(self) -> Any:
        """Fresh Digest client for writes — avoids racing AcsEvent/alertStream auth."""
        return httpx.AsyncClient(
            base_url=self.base_url,
            auth=httpx.DigestAuth(self.username or "admin", self.password or ""),
            timeout=httpx.Timeout(60.0, connect=10.0),
            verify=False,
        )

    async def _try_requests_on(
        self,
        client: httpx.AsyncClient,
        attempts: list[tuple[str, str, dict[str, Any]]],
        ok_log: str,
    ) -> bool:
        last_status = 0
        last_body = ""
        last_path = ""
        for method, path, kwargs in attempts:
            try:
                resp = await client.request(method, path, **kwargs)
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s %s connection error: %s", method, path, exc)
                continue
            last_status, last_body, last_path = resp.status_code, resp.text[:500], path
            if resp.status_code < 400:
                logger.info("%s via %s %s", ok_log, method, path)
                return True
            body_l = (resp.text or "").lower()
            if "deviceUserAlreadyExistFace" in (resp.text or ""):
                logger.info("%s already on device via %s %s", ok_log, method, path)
                return True
            # Delete paths: treat "already gone" as success (memory already free).
            if any(
                token in body_l
                for token in (
                    "employeenotexist",
                    "employeenonoexist",
                    "usernotexist",
                    "usernotexisted",
                    "invalidoperation",
                )
            ):
                logger.info("%s already absent via %s %s", ok_log, method, path)
                return True
            if "employeeNoAlreadyExist" in (resp.text or ""):
                logger.info(
                    "%s employee exists via %s %s — try next upsert path",
                    ok_log,
                    method,
                    path,
                )
                continue
            logger.warning(
                "%s %s -> %s %s", method, path, resp.status_code, resp.text[:400]
            )
        logger.error(
            "%s failed last=%s %s %s",
            ok_log,
            last_path,
            last_status,
            last_body,
        )
        return False

    async def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        assert self._client is not None
        async with self._http_lock:
            return await self._client.request(method, path, **kwargs)

    async def _try_requests(
        self,
        attempts: list[tuple[str, str, dict[str, Any]]],
        ok_log: str,
    ) -> bool:
        """Run HTTP attempts; treat 2xx as success. Skip 401 digest handshake noise."""
        assert self._client is not None
        return await self._try_requests_on(self._client, attempts, ok_log)

    async def upsert_user(self, employee_id: str, name: str) -> bool:
        """Create/update person: POST Record, then PUT SetUp/Modify (MinMoe ISAPI)."""
        if not self._client:
            raise RuntimeError("Adapter not connected")

        # Device clocks are often unsynced; Hikvision rejects dates after ~2037.
        begin = "2017-08-01T00:00:00"
        end = "2037-12-31T23:59:59"
        emp_no = hikvision_employee_no(employee_id)
        if emp_no != str(employee_id):
            logger.info("employeeNo normalized %s -> %s", employee_id, emp_no)
        self._own_person_changes.add(emp_no)
        safe_name = (name or emp_no)[:32]
        payload = {
            "UserInfo": {
                "employeeNo": emp_no,
                "name": safe_name,
                "userType": "normal",
                "Valid": {
                    "enable": True,
                    "beginTime": begin,
                    "endTime": end,
                    "timeType": "local",
                },
                "doorRight": "1",
                "RightPlan": [{"doorNo": 1, "planTemplateNo": "1"}],
            }
        }
        xml_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<UserInfo>
  <employeeNo>{emp_no}</employeeNo>
  <name>{safe_name}</name>
  <userType>normal</userType>
  <Valid>
    <enable>true</enable>
    <beginTime>{begin}</beginTime>
    <endTime>{end}</endTime>
    <timeType>local</timeType>
  </Valid>
  <doorRight>1</doorRight>
</UserInfo>"""
        xml_kw = {
            "content": xml_body.encode("utf-8"),
            "headers": {"Content-Type": "application/xml"},
        }
        attempts = [
            ("PUT", "/ISAPI/AccessControl/UserInfo/SetUp?format=json", {"json": payload}),
            ("PUT", "/ISAPI/AccessControl/UserInfo/Modify?format=json", {"json": payload}),
            ("POST", "/ISAPI/AccessControl/UserInfo/Record?format=json", {"json": payload}),
            ("PUT", "/ISAPI/AccessControl/UserInfo/SetUp", xml_kw),
            ("POST", "/ISAPI/AccessControl/UserInfo/Record", xml_kw),
        ]
        async with await self._command_client() as client:
            return await self._try_requests_on(
                client,
                attempts,
                f"UserInfo upsert employeeNo={emp_no}",
            )

    async def delete_user(self, employee_id: str) -> bool:
        """Remove person (+ face capacity) from terminal by employeeNo."""
        if not self._client:
            raise RuntimeError("Adapter not connected")
        emp_no = hikvision_employee_no(employee_id)
        if emp_no != str(employee_id):
            logger.info("employeeNo normalized %s -> %s", employee_id, emp_no)
        self._own_person_changes.add(emp_no)

        del_payload = {
            "UserInfoDelCond": {
                "EmployeeNoList": [{"employeeNo": emp_no}],
            }
        }
        # Alternate shapes seen across MinMoe / Access firmware.
        del_payload_alt = {
            "UserInfoDetail": {
                "mode": "byEmployeeNo",
                "EmployeeNoList": [{"employeeNo": emp_no}],
            }
        }
        xml_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<UserInfoDelCond>
  <EmployeeNoList>
    <employeeNo>{emp_no}</employeeNo>
  </EmployeeNoList>
</UserInfoDelCond>"""
        xml_kw = {
            "content": xml_body.encode("utf-8"),
            "headers": {"Content-Type": "application/xml"},
        }
        face_del = {
            "FaceDataRecord": {
                "faceLibType": "blackFD",
                "FDID": "1",
                "FPID": emp_no,
                "employeeNo": emp_no,
            }
        }
        attempts = [
            ("PUT", "/ISAPI/AccessControl/UserInfo/Delete?format=json", {"json": del_payload}),
            ("PUT", "/ISAPI/AccessControl/UserInfoDetail/Delete?format=json", {"json": del_payload_alt}),
            ("PUT", "/ISAPI/AccessControl/UserInfo/Delete", xml_kw),
            (
                "POST",
                "/ISAPI/Intelligent/FDLib/FDSearch/Delete?format=json",
                {"json": face_del},
            ),
        ]
        async with await self._command_client() as client:
            return await self._try_requests_on(
                client,
                attempts,
                f"UserInfo delete employeeNo={emp_no}",
            )

    async def enroll_face(
        self,
        employee_id: str,
        face_image_base64: Optional[str] = None,
    ) -> bool:
        """Upload face picture bound to employeeNo (FaceDataRecord)."""
        if not self._client:
            raise RuntimeError("Adapter not connected")
        if not face_image_base64:
            logger.error("enroll_face requires face_image_base64")
            return False

        b64 = face_image_base64
        if "," in b64 and b64.strip().startswith("data:"):
            b64 = b64.split(",", 1)[1]

        emp_no = hikvision_employee_no(employee_id)
        self._own_person_changes.add(emp_no)
        record = {
            "faceLibType": "blackFD",
            "FDID": "1",
            "FPID": emp_no,
            "employeeNo": emp_no,
        }
        try:
            raw = base64.b64decode(b64, validate=False)
        except Exception as exc:  # noqa: BLE001
            logger.error("face image base64 decode failed: %s", exc)
            return False

        # Oversized JPEGs disconnect some Hikvision terminals mid-upload.
        if len(raw) > 100_000:
            try:
                from io import BytesIO

                from PIL import Image  # type: ignore

                img = Image.open(BytesIO(raw)).convert("RGB")
                img.thumbnail((480, 480))
                buf = BytesIO()
                img.save(buf, format="JPEG", quality=85)
                raw = buf.getvalue()
                b64 = base64.b64encode(raw).decode("ascii")
                logger.info(
                    "face image resized for employeeNo=%s -> %s bytes",
                    emp_no,
                    len(raw),
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("face image resize skipped: %s", exc)

        json_attempts: list[tuple[str, str, dict[str, Any]]] = [
            (
                "POST",
                "/ISAPI/Intelligent/FDLib/FaceDataRecord?format=json",
                {"json": {**record, "faceData": b64}},
            ),
            (
                "POST",
                "/ISAPI/Intelligent/FDLib/FaceDataRecord?format=json",
                {"json": {"FaceDataRecord": {**record, "faceData": b64}}},
            ),
        ]
        async with await self._command_client() as client:
            if await self._try_requests_on(
                client, json_attempts, f"Face enroll json employeeNo={emp_no}"
            ):
                return True

            files = {
                "FaceDataRecord": (
                    None,
                    json.dumps(record),
                    "application/json",
                ),
                "FaceImage": ("face.jpg", raw, "image/jpeg"),
            }
            try:
                resp = await client.post(
                    "/ISAPI/Intelligent/FDLib/FaceDataRecord?format=json",
                    files=files,
                )
                if resp.status_code < 400:
                    logger.info(
                        "Face enroll multipart employeeNo=%s via %s",
                        emp_no,
                        resp.status_code,
                    )
                    return True
                if "deviceUserAlreadyExistFace" in (resp.text or ""):
                    # Stale face — delete then retry once (synced≠recognizable otherwise).
                    try:
                        await client.put(
                            "/ISAPI/Intelligent/FDLib/FDSearch/Delete?format=json",
                            json={
                                "FaceDataRecord": {
                                    "faceLibType": "blackFD",
                                    "FDID": "1",
                                    "FPID": emp_no,
                                    "employeeNo": emp_no,
                                }
                            },
                        )
                        resp2 = await client.post(
                            "/ISAPI/Intelligent/FDLib/FaceDataRecord?format=json",
                            files=files,
                        )
                        if resp2.status_code < 400:
                            return True
                    except Exception as exc:  # noqa: BLE001
                        logger.warning("Face replace after exist failed: %s", exc)
                logger.warning(
                    "Face enroll multipart -> %s %s",
                    resp.status_code,
                    resp.text[:400],
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Face enroll multipart error: %s", exc)
            return False

    async def sync_clock(self) -> bool:
        """Align terminal clock with the PC (Uzbekistan UTC+5)."""
        if not self._client:
            return False
        now = datetime.now(timezone(timedelta(hours=5)))
        local = now.strftime("%Y-%m-%dT%H:%M:%S")
        xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            "<Time>"
            "<timeMode>manual</timeMode>"
            f"<localTime>{local}+05:00</localTime>"
            "<timeZone>CST-5:00:00</timeZone>"
            "</Time>"
        )
        try:
            resp = await self._client.put(
                "/ISAPI/System/time",
                content=xml.encode("utf-8"),
                headers={"Content-Type": "application/xml"},
            )
            ok = resp.status_code < 400
            logger.info("sync_clock %s %s", resp.status_code, resp.text[:200])
            if ok:
                self.last_clock_sync_at = datetime.now(timezone.utc)
                device_now, tz = await self._device_local_now()
                self.last_drift_seconds = self._clock_drift_seconds(device_now, tz)
                tzinfo = self._offset_tz(tz)
                aware = (
                    device_now
                    if device_now.tzinfo is not None
                    else device_now.replace(tzinfo=tzinfo)
                )
                self.last_device_now_iso = aware.isoformat()
                if self.punch_locked and abs(self.last_drift_seconds) <= CLOCK_ALIGN_SECONDS:
                    self.clock_synced_after_lock = True
                logger.info(
                    "sync_clock confirmed drift=%.1fs",
                    self.last_drift_seconds,
                )
            return ok
        except Exception as exc:  # noqa: BLE001
            logger.warning("sync_clock failed: %s", exc)
            return False

    async def reboot(self) -> bool:
        if not self._client:
            return False
        return await self._try_requests(
            [
                (
                    "PUT",
                    "/ISAPI/System/reboot",
                    {
                        "content": b"",
                        "headers": {"Content-Type": "application/xml"},
                    },
                ),
                ("PUT", "/ISAPI/System/reboot?format=json", {}),
            ],
            "reboot",
        )

    async def open_door(self) -> bool:
        if not self._client:
            return False
        xml = (
            b'<?xml version="1.0" encoding="UTF-8"?>'
            b"<RemoteControlDoor><cmd>open</cmd></RemoteControlDoor>"
        )
        return await self._try_requests(
            [
                (
                    "PUT",
                    "/ISAPI/AccessControl/RemoteControl/door/1",
                    {"content": xml, "headers": {"Content-Type": "application/xml"}},
                ),
                (
                    "PUT",
                    "/ISAPI/AccessControl/RemoteControl/door/1?format=json",
                    {"json": {"RemoteControlDoor": {"cmd": "open"}}},
                ),
            ],
            "open_door",
        )

    async def maybe_align_clock(self, drift: float) -> bool:
        """Keep the terminal on the server clock whenever we can reach it."""
        if not self.clock_read_ok:
            return False
        if abs(drift) <= CLOCK_MATCH_SECONDS:
            self.last_clock_sync_at = self.last_clock_sync_at or datetime.now(timezone.utc)
            if self.punch_locked:
                self.clock_synced_after_lock = True
            return False
        due_periodic = True
        if self.last_clock_sync_at is not None:
            age = (datetime.now(timezone.utc) - self.last_clock_sync_at).total_seconds()
            due_periodic = age >= CLOCK_ALIGN_INTERVAL_SECONDS
        if abs(drift) < CLOCK_ALIGN_SECONDS and not due_periodic:
            return False
        logger.info(
            "align clock to server drift=%.1fs periodic=%s",
            drift,
            due_periodic and abs(drift) < CLOCK_ALIGN_SECONDS,
        )
        return await self.sync_clock()

    async def _stop_alert_stream(self) -> None:
        if self._subscribe_task and not self._subscribe_task.done():
            self._subscribe_task.cancel()
            try:
                await self._subscribe_task
            except asyncio.CancelledError:
                pass
        self._subscribe_task = None

    async def _security_user_id_with(self, client: httpx.AsyncClient) -> str:
        try:
            resp = await client.get("/ISAPI/Security/users")
            if resp.status_code >= 400:
                return "1"
            root = ET.fromstring(resp.text)
            wanted = (self.username or "admin").lower()
            fallback = "1"
            for el in root.iter():
                if _xml_local(el.tag) != "User":
                    continue
                uid = ""
                uname = ""
                for child in el:
                    loc = _xml_local(child.tag)
                    if loc == "id" and child.text:
                        uid = child.text.strip()
                    elif loc == "userName" and child.text:
                        uname = child.text.strip()
                if uid:
                    fallback = uid
                if uname.lower() == wanted and uid:
                    return uid
            return fallback
        except Exception as exc:  # noqa: BLE001
            logger.warning("security users lookup failed: %s", exc)
            return "1"

    async def change_password(self, new_password: str) -> tuple[bool, str]:
        """Change the terminal admin password via ISAPI, then re-auth.

        DS-K1T343 firmware requires <loginPassword> (current password) or
        it returns 400 MessageParametersLack / errorMsg=loginPassword.
        JSON /users?format=json is not supported on this model.

        Uses a dedicated HTTP client so the long-lived alertStream/poll
        connection cannot cancel the PUT.
        """
        if not new_password:
            return False, "Новый пароль пустой"
        if not (self.password or "").strip():
            return False, "Сначала сохраните текущий ISAPI-пароль устройства"
        rule = hikvision_password_error(new_password, self.username or "admin")
        if rule:
            return False, rule
        user = self.username or "admin"
        try:
            async with httpx.AsyncClient(
                base_url=self.base_url,
                auth=httpx.DigestAuth(user, self.password),
                timeout=httpx.Timeout(15.0, connect=3.0),
                verify=False,
            ) as client:
                uid = await self._security_user_id_with(client)
                xml = (
                    '<?xml version="1.0" encoding="UTF-8"?>'
                    "<User>"
                    f"<id>{_xml_text(uid)}</id>"
                    f"<userName>{_xml_text(user)}</userName>"
                    f"<password>{_xml_text(new_password)}</password>"
                    f"<loginPassword>{_xml_text(self.password)}</loginPassword>"
                    "<userLevel>Administrator</userLevel>"
                    "</User>"
                )
                resp = await client.put(
                    f"/ISAPI/Security/users/{uid}",
                    content=xml.encode("utf-8"),
                    headers={"Content-Type": "application/xml"},
                )
                if resp.status_code >= 400:
                    err = isapi_status_message(resp.status_code, resp.text)
                    logger.warning(
                        "change_password %s %s", resp.status_code, resp.text[:300]
                    )
                    return False, f"Терминал отклонил пароль: {err}"
            self.password = new_password
            await self._stop_alert_stream()
            await self.disconnect()
            await self.connect()
            logger.info("change_password OK user=%s", user)
            return True, ""
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "change_password failed: %s %r", type(exc).__name__, exc
            )
            detail = str(exc).strip() or repr(exc)
            return False, f"Ошибка смены пароля: {type(exc).__name__}: {detail}"

    def restore_punch_lock(
        self,
        locked: bool,
        last_serial: int,
        login_at: Optional[str] = None,
    ) -> None:
        """Resume lock state after GW restart (watermark from the API)."""
        self.last_admin_login_serial = max(0, int(last_serial or 0))
        if login_at:
            self.admin_login_at = str(login_at)
        if locked:
            self.punch_locked = True
            self.awaiting_sync_unlock = True
            self.admin_login_serial = self.last_admin_login_serial
            self.lock_started_at = datetime.now(timezone.utc)
            self.clock_synced_after_lock = False
            self.saw_local_logout = False
            # Baseline was lost with the restart: the report keeps the journal only.
            self._begin_admin_audit(None, None)

    async def _search_acs(
        self,
        major: int,
        minor: Optional[int],
        start: str,
        end: str,
        page_size: int = 30,
    ) -> list[dict[str, Any]]:
        """Paginate AcsEvent search. Firmware often returns oldest first."""
        if not self._client:
            return []
        if minor is not None and minor in self._acs_skip_minors:
            return []
        items: list[dict[str, Any]] = []
        position = 0
        try:
            for _ in range(20):
                cond: dict[str, Any] = {
                    "searchID": "1",
                    "searchResultPosition": position,
                    "maxResults": page_size,
                    "major": major,
                    "startTime": start,
                    "endTime": end,
                }
                if minor is not None:
                    cond["minor"] = minor
                resp = await self._client.post(
                    "/ISAPI/AccessControl/AcsEvent?format=json",
                    json={"AcsEventCond": cond},
                    timeout=20.0,
                )
                if resp.status_code >= 400:
                    body = resp.text[:200]
                    if minor is not None and "minor" in body.lower():
                        self._acs_skip_minors.add(minor)
                        logger.info(
                            "AcsEvent minor=%s not supported on this firmware — skip",
                            minor,
                        )
                    else:
                        logger.warning(
                            "AcsEvent search major=%s minor=%s -> %s %s",
                            major,
                            minor,
                            resp.status_code,
                            body,
                        )
                    break
                acs = (resp.json() or {}).get("AcsEvent") or {}
                infos = acs.get("InfoList") or acs.get("Info") or []
                if isinstance(infos, dict):
                    infos = [infos]
                if not infos:
                    break
                items.extend(x for x in infos if isinstance(x, dict))
                if acs.get("responseStatusStrg") != "MORE":
                    break
                position += len(infos)
        except Exception as exc:  # noqa: BLE001
            logger.warning("AcsEvent search failed major=%s minor=%s: %s", major, minor, exc)
        return items

    async def detect_new_admin_login(self) -> Optional[dict[str, Any]]:
        """Return the newest local-admin login newer than the persisted watermark."""
        found: list[dict[str, Any]] = []
        device_now, tz = await self._device_local_now()
        for start, end in self._login_search_windows(device_now, tz):
            found.extend(await self._search_acs(3, MINOR_LOCAL_LOGIN, start, end))
            found.extend(await self._search_acs(3, MINOR_LOCAL_LOGOUT, start, end))
            if not found:
                found.extend(
                    item
                    for item in await self._search_acs(3, None, start, end)
                    if self._acs_is_login(item) or self._acs_is_logout(item)
                )

        newest_login: Optional[dict[str, Any]] = None
        newest_login_serial = self.last_admin_login_serial
        newest_logout_serial = 0
        seen: set[int] = set()
        for item in found:
            serial = int(item.get("serialNo") or 0)
            if serial <= 0 or serial in seen:
                continue
            seen.add(serial)
            minor = int(item.get("minor") or 0)
            if minor == MINOR_LOCAL_LOGOUT or self._acs_is_logout(item):
                if serial > newest_logout_serial:
                    newest_logout_serial = serial
                continue
            if not (minor == MINOR_LOCAL_LOGIN or self._acs_is_login(item)):
                continue
            if serial > newest_login_serial:
                newest_login_serial = serial
                newest_login = item

        if (
            self.punch_locked
            and newest_logout_serial > 0
            and newest_logout_serial >= self.admin_login_serial
        ):
            self.saw_local_logout = True

        if self.last_admin_login_serial <= 0 and not self.punch_locked:
            if newest_login_serial > 0:
                self.last_admin_login_serial = newest_login_serial
                logger.info("admin-login watermark serial=%s", newest_login_serial)
            return None
        return newest_login

    def _login_search_windows(self, device_now: datetime, tz: str) -> list[tuple[str, str]]:
        """Search both device-clock and server-clock days so a rollback cannot hide login."""
        windows: list[tuple[str, str]] = []
        for naive, zone in (
            (device_now, tz),
            (datetime.now(self._offset_tz("+05:00")).replace(tzinfo=None), "+05:00"),
        ):
            start = (naive - timedelta(days=7)).strftime("%Y-%m-%dT00:00:00") + zone
            end = (naive + timedelta(days=1)).strftime("%Y-%m-%dT23:59:59") + zone
            windows.append((start, end))
        return windows

    async def lock_punching(self, login: Optional[dict[str, Any]] = None) -> bool:
        """Disable face/card authentication until a confirmed server sync."""
        serial = int((login or {}).get("serialNo") or 0)
        if serial:
            self.last_admin_login_serial = max(self.last_admin_login_serial, serial)
            self.admin_login_serial = serial
        self.admin_login_at = str(
            (login or {}).get("time") or datetime.now(timezone.utc).isoformat()
        )
        self.lock_started_at = datetime.now(timezone.utc)
        self.clock_synced_after_lock = False
        self.time_changed_after_lock = False
        self.saw_local_logout = False
        self._begin_admin_audit(login, self._config_baseline)
        ok = await self.set_punching_enabled(False)
        self.punch_locked = True
        self.awaiting_sync_unlock = True
        logger.warning(
            "punch LOCKED after local admin login serial=%s time=%s method=%s ok=%s",
            self.admin_login_serial,
            self.admin_login_at,
            self.lock_method,
            ok,
        )
        return ok

    def ready_to_unlock(self) -> str | None:
        """Unlock only when online clock is aligned with server after the lock."""
        if not self.punch_locked or not self.awaiting_sync_unlock:
            return "not_locked"
        if self.lock_started_at is None:
            return "no_lock_start"
        held = (datetime.now(timezone.utc) - self.lock_started_at).total_seconds()
        if held < PUNCH_LOCK_MIN_SECONDS and not self.saw_local_logout:
            return f"hold_{int(held)}s"
        if not self.clock_read_ok:
            return "clock_unread"
        if abs(float(self.last_drift_seconds or 0)) > CLOCK_ALIGN_SECONDS:
            return "clock_not_aligned"
        if not self.clock_synced_after_lock:
            return "clock_not_synced_after_lock"
        return None

    async def unlock_punching(self) -> bool:
        """Re-enable face/card after online + clock sync; keep fraud window for history."""
        ok = await self.set_punching_enabled(True)
        if not ok:
            logger.error("punch unlock failed method=%s — keeping lock", self.lock_method)
            return False
        now_iso = datetime.now(timezone.utc).isoformat()
        if self.time_changed_after_lock and self.admin_login_at:
            self.fraud_window_start = self.admin_login_at
            self.fraud_window_end = now_iso
            logger.warning(
                "fraud window kept %s .. %s (admin+clock change)",
                self.fraud_window_start,
                self.fraud_window_end,
            )
        self.punch_locked = False
        self.awaiting_sync_unlock = False
        self.clock_synced_after_lock = False
        self.time_changed_after_lock = False
        self.saw_local_logout = False
        self.lock_started_at = None
        logger.info(
            "punch UNLOCKED after online clock sync serial=%s — new marks accepted",
            self.last_admin_login_serial,
        )
        return True

    # --- Admin session audit -------------------------------------------------

    def _begin_admin_audit(
        self,
        login: Optional[dict[str, Any]],
        baseline: Optional[dict[str, Any]],
    ) -> None:
        now = datetime.now(timezone.utc)
        login = login or {}
        login_by = {
            k: str(login[src])
            for src, k in (("name", "name"), ("employeeNoString", "employeeNo"))
            if login.get(src)
        }
        picture = login.get("pictureURL") or login.get("pictureUrl")
        self.admin_audit = {
            "serial": self.admin_login_serial,
            "loginAt": self.admin_login_at,
            "startedAt": now,
            "before": baseline,
            "baselineAt": self._config_baseline_at.isoformat()
            if baseline is not None and self._config_baseline_at
            else None,
            "loginBy": login_by or None,
            "pictureUrl": picture if isinstance(picture, str) else None,
        }

    def admin_audit_due(self) -> Optional[str]:
        """Why the open admin session should be reported now (None = still open)."""
        audit = self.admin_audit
        if not audit:
            return None
        if not self.punch_locked:
            return "unlocked"
        if self.saw_local_logout:
            return "logout"
        if datetime.now(timezone.utc) - audit["startedAt"] > ADMIN_AUDIT_MAX_SESSION:
            return "timeout"
        return None

    async def capture_snapshot(self) -> Optional[str]:
        """Live JPEG from the terminal camera (base64), trying known ISAPI paths."""
        if not self._client:
            return None
        paths = [self._snapshot_path] if self._snapshot_path else list(SNAPSHOT_PATHS)
        for path in paths:
            try:
                resp = await self._client.get(path, timeout=8.0)
            except Exception as exc:  # noqa: BLE001
                logger.warning("snapshot %s failed: %s", path, exc)
                continue
            if resp.status_code < 400 and resp.content.startswith(b"\xff\xd8"):
                self._snapshot_path = path
                return base64.b64encode(resp.content).decode("ascii")
            logger.info("snapshot %s -> %s", path, resp.status_code)
        if self._snapshot_path:
            self._snapshot_path = None
        return None

    async def capture_admin_snapshots(
        self, count: int = 3, interval_s: float = 1.5
    ) -> list[str]:
        """Frames of whoever stands at the terminal right after the admin login."""
        shots: list[str] = []
        picture_url = (self.admin_audit or {}).get("pictureUrl")
        if picture_url:
            jpeg = await self._fetch_capture_jpeg(picture_url)
            if jpeg:
                shots.append(jpeg)
        for i in range(count):
            if i:
                await asyncio.sleep(interval_s)
            jpeg = await self.capture_snapshot()
            if jpeg:
                shots.append(jpeg)
            elif i == 0:
                break
        return shots

    async def _get_ok(self, path: str) -> Optional[httpx.Response]:
        assert self._client is not None
        try:
            resp = await self._client.get(path, timeout=8.0)
        except Exception as exc:  # noqa: BLE001
            logger.info("config read %s failed: %s", path, exc)
            return None
        return resp if resp.status_code < 400 else None

    async def _get_json(self, path: str) -> Optional[dict[str, Any]]:
        resp = await self._get_ok(path)
        if resp is None:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        return data if isinstance(data, dict) else None

    async def _read_persons(self) -> Optional[dict[str, dict[str, Any]]]:
        """employeeNo → person; None if the list could not be read completely."""
        assert self._client is not None
        persons: dict[str, dict[str, Any]] = {}
        position = 0
        for _ in range(PERSONS_MAX_PAGES):
            try:
                resp = await self._client.post(
                    "/ISAPI/AccessControl/UserInfo/Search?format=json",
                    json={
                        "UserInfoSearchCond": {
                            "searchID": "hrhub-audit",
                            "searchResultPosition": position,
                            "maxResults": PERSONS_PAGE_SIZE,
                        }
                    },
                    timeout=15.0,
                )
                if resp.status_code >= 400:
                    return None
                search = (resp.json() or {}).get("UserInfoSearch") or {}
            except Exception as exc:  # noqa: BLE001
                logger.info("UserInfo search failed: %s", exc)
                return None
            users = search.get("UserInfo") or []
            if isinstance(users, dict):
                users = [users]
            for user in users:
                if isinstance(user, dict) and user.get("employeeNo") is not None:
                    persons[str(user["employeeNo"])] = person_entry(user)
            status = str(search.get("responseStatusStrg") or "")
            if status != "MORE" or not users:
                return persons
            position += len(users)
        return None

    async def read_config_state(self) -> Optional[dict[str, Any]]:
        """Readable configuration sections, flattened for diffing."""
        if not self._client:
            return None
        state: dict[str, Any] = {}
        xml_sections = (
            ("time", "/ISAPI/System/time", {"timeMode", "timeZone"}),
            (
                "ntp",
                "/ISAPI/System/time/ntpServers",
                {"addressingFormatType", "hostName", "ipAddress", "portNo", "synchronizeInterval"},
            ),
            (
                "network",
                "/ISAPI/System/Network/interfaces/1/ipAddress",
                {"addressingType", "ipAddress", "subnetMask"},
            ),
            (
                "device",
                "/ISAPI/System/deviceInfo",
                {"deviceName", "firmwareVersion", "firmwareReleasedDate"},
            ),
        )
        for section, path, keys in xml_sections:
            resp = await self._get_ok(path)
            if resp is not None:
                state[section] = flatten_xml(resp.text, keys)
        json_sections = (
            ("acs", "/ISAPI/AccessControl/AcsCfg?format=json", "AcsCfg"),
            ("cardReader", "/ISAPI/AccessControl/CardReaderCfg/1?format=json", "CardReaderCfg"),
            ("door", "/ISAPI/AccessControl/Door/param/1?format=json", "DoorParam"),
            ("users", "/ISAPI/AccessControl/UserInfo/Count?format=json", "UserInfoCount"),
        )
        for section, path, root in json_sections:
            data = await self._get_json(path)
            if data is not None and isinstance(data.get(root), dict):
                state[section] = flatten_json(data[root])
        persons = await self._read_persons()
        if persons is not None:
            state["persons"] = persons
        return state or None

    async def refresh_config_baseline(self) -> None:
        """Keep a recent pre-login config so the admin session can be diffed."""
        if self.punch_locked or self.admin_audit or not self._client:
            return
        now = datetime.now(timezone.utc)
        if self._config_baseline_at and now - self._config_baseline_at < CONFIG_BASELINE_REFRESH:
            return
        self._config_baseline_at = now
        own_before = set(self._own_person_changes)
        state = await self.read_config_state()
        if state:
            self._config_baseline = state
            self._own_person_changes -= own_before

    @staticmethod
    def _isapi_stamp(dt: datetime) -> str:
        offset = int((dt.utcoffset() or timedelta(0)).total_seconds())
        sign = "+" if offset >= 0 else "-"
        offset = abs(offset)
        return f"{dt:%Y-%m-%dT%H:%M:%S}{sign}{offset // 3600:02d}:{offset % 3600 // 60:02d}"

    async def fetch_operation_log(
        self, login_serial: int, login_at: Optional[str]
    ) -> list[dict[str, Any]]:
        """Journal events of the session — around the login stamp and around the
        device's current clock (the admin may have moved the clock meanwhile)."""
        device_now, tz = await self._device_local_now()
        now_dt = device_now.replace(tzinfo=self._offset_tz(tz))
        windows = [
            (now_dt - timedelta(minutes=60), now_dt + timedelta(minutes=1)),
        ]
        login_dt = self._as_dt(str(login_at or ""))
        if login_dt:
            windows.insert(
                0, (login_dt - timedelta(minutes=1), login_dt + timedelta(minutes=60))
            )
        items: list[dict[str, Any]] = []
        for start, end in windows:
            items.extend(
                await self._search_acs(
                    MAJOR_OPERATION,
                    None,
                    self._isapi_stamp(start),
                    self._isapi_stamp(end),
                )
            )
        return build_operation_log(items, login_serial)

    async def finish_admin_audit(self, reason: str) -> Optional[dict[str, Any]]:
        """Close the open admin session: journal + config diff vs the pre-login baseline."""
        audit = self.admin_audit
        if not audit:
            return None
        self.admin_audit = None
        after = await self.read_config_state()
        operations = await self.fetch_operation_log(
            int(audit.get("serial") or 0), audit.get("loginAt")
        )
        before = audit.get("before")
        changes = diff_config(before, after, self._own_person_changes)
        if after:
            self._config_baseline = after
            self._config_baseline_at = datetime.now(timezone.utc)
            self._own_person_changes = set()
        logger.warning(
            "admin session audit serial=%s reason=%s operations=%s changes=%s",
            audit.get("serial"),
            reason,
            len(operations),
            len(changes),
        )
        return {
            "adminLoginSerial": int(audit.get("serial") or 0),
            "adminLoginAt": audit.get("loginAt"),
            "loginBy": audit.get("loginBy"),
            "endedAt": datetime.now(timezone.utc).isoformat(),
            "endReason": reason,
            "baselineAt": audit.get("baselineAt"),
            "diffAvailable": bool(before and after),
            "operations": operations,
            "changes": changes,
        }

    async def set_punching_enabled(self, enabled: bool) -> bool:
        """Best-effort: disable/enable terminal authentication via ISAPI."""
        if not self._client:
            return False
        if await self._set_card_reader_enabled(enabled):
            self.lock_method = "CardReaderCfg"
            return True
        if await self._set_face_recognize_enabled(enabled):
            self.lock_method = "FaceRecognizeMode"
            return True
        logger.error("could not %s punching on device ISAPI", "enable" if enabled else "disable")
        return False

    async def _set_card_reader_enabled(self, enabled: bool) -> bool:
        assert self._client is not None
        paths = (
            "/ISAPI/AccessControl/CardReaderCfg/1?format=json",
            "/ISAPI/AccessControl/CardReaderCfg?format=json",
        )
        for path in paths:
            try:
                resp = await self._client.get(path)
                if resp.status_code >= 400:
                    continue
                data = resp.json() if resp.content else {}
                cfg = data.get("CardReaderCfg") if isinstance(data, dict) else None
                if isinstance(cfg, list):
                    cfg = cfg[0] if cfg else {}
                if not isinstance(cfg, dict) or not cfg:
                    continue
                if not enabled:
                    self._saved_card_reader = (path, dict(cfg))
                payload = dict(cfg)
                if enabled and self._saved_card_reader and self._saved_card_reader[0] == path:
                    payload = dict(self._saved_card_reader[1])
                payload["enable"] = bool(enabled)
                put = await self._client.put(path, json={"CardReaderCfg": payload})
                if put.status_code < 400:
                    logger.info("CardReaderCfg enable=%s via %s", enabled, path)
                    return True
                logger.warning(
                    "CardReaderCfg PUT %s -> %s %s",
                    path,
                    put.status_code,
                    put.text[:300],
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("CardReaderCfg %s failed: %s", path, exc)
        return False

    async def _set_face_recognize_enabled(self, enabled: bool) -> bool:
        assert self._client is not None
        path = "/ISAPI/AccessControl/FaceRecognizeMode?format=json"
        try:
            resp = await self._client.get(path)
            mode: dict[str, Any] = {}
            if resp.status_code < 400 and resp.content:
                data = resp.json()
                raw = data.get("FaceRecognizeMode") if isinstance(data, dict) else None
                if isinstance(raw, dict):
                    mode = dict(raw)
            mode["enable"] = bool(enabled)
            mode["mode"] = "enable" if enabled else "disable"
            put = await self._client.put(path, json={"FaceRecognizeMode": mode})
            if put.status_code < 400:
                logger.info("FaceRecognizeMode enable=%s", enabled)
                return True
            logger.warning(
                "FaceRecognizeMode PUT -> %s %s", put.status_code, put.text[:300]
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("FaceRecognizeMode failed: %s", exc)
        return False

    async def _device_local_now(self) -> tuple[datetime, str]:
        """Return (naive local datetime, ISO offset like +05:00).

        DS-K1T343 AcsEvent search is picky: a calendar day without the
        timezone suffix often returns NO MATCH even when events exist.
        """
        fallback_tz = "+05:00"
        self.clock_read_ok = False
        if not self._client:
            return datetime.now(), fallback_tz
        try:
            resp = await self._client.get("/ISAPI/System/time")
            if resp.status_code < 400 and b"<localTime>" in resp.content:
                raw = resp.text
                start = raw.find("<localTime>") + len("<localTime>")
                end = raw.find("</localTime>")
                stamp = raw[start:end].strip()
                tz = fallback_tz
                if len(stamp) >= 25 and stamp[19] in "+-":
                    tz = stamp[19:25]
                naive = datetime.strptime(stamp[:19], "%Y-%m-%dT%H:%M:%S")
                self.clock_read_ok = True
                return naive, tz
        except Exception:
            pass
        return datetime.now(), fallback_tz

    @staticmethod
    def _offset_tz(tz: str) -> timezone:
        sign = 1 if str(tz).startswith("+") else -1
        hours = int(str(tz)[1:3] or 0)
        mins = int(str(tz)[4:6] or 0)
        return timezone(sign * timedelta(hours=hours, minutes=mins))

    def _clock_drift_seconds(self, device_now: datetime, tz: str) -> float:
        device_aware = (
            device_now
            if device_now.tzinfo is not None
            else device_now.replace(tzinfo=self._offset_tz(tz))
        )
        server_now = datetime.now(self._offset_tz(tz))
        return (device_aware - server_now).total_seconds()

    def _note_clock_after_lock(self, drift: float) -> None:
        """Admin password alone is OK; large drift after lock = time was changed."""
        if self.punch_locked and abs(float(drift or 0)) > CLOCK_SKEW_SECONDS:
            if not self.time_changed_after_lock:
                logger.warning(
                    "device clock changed after admin login (drift=%.0fs) — later punches blocked",
                    drift,
                )
            self.time_changed_after_lock = True

    def _apply_clock_trust(self, punches: list[dict[str, Any]], drift: float) -> None:
        """Tag skewed / fraud punches; keep DEVICE event time (never overwrite with server now).

        - Offline / historical marks: keep device event time, do NOT mark invalid.
        - Live punches with large drift: flag clock_tamper, keep occurred_at as on device.
        - After admin login + time change: tag punches after login as blocked.
        """
        self._note_clock_after_lock(drift)
        device_now = self._as_dt(str(self.last_device_now_iso or "")) or datetime.now(
            timezone.utc
        )
        live_window = timedelta(minutes=30)
        for punch in punches:
            punch["clock_drift_seconds"] = int(round(drift))
            after_fraud = self._punch_after_admin_login(str(punch.get("occurred_at") or ""))
            if after_fraud:
                punch["admin_login_blocked"] = True
                punch["clock_tamper"] = True
                punch["device_occurred_at"] = punch.get("occurred_at")
                continue
            if abs(drift) <= CLOCK_SKEW_SECONDS:
                continue
            event = self._as_dt(str(punch.get("occurred_at") or ""))
            is_live = bool(event and abs(event - device_now) <= live_window)
            if not is_live:
                continue
            punch["clock_tamper"] = True
            punch["device_occurred_at"] = punch.get("occurred_at")
            # Keep occurred_at = device clock stamp (UI shows terminal time).

    def _punch_from_acs_item(self, item: dict[str, Any]) -> dict[str, Any] | None:
        eid = (
            item.get("employeeNoString")
            or item.get("employeeNo")
            or item.get("cardNo")
        )
        if not eid:
            return None
        key = str(item.get("serialNo") or f"{eid}:{item.get('time')}")
        if key in self._seen_event_keys:
            return None
        self._seen_event_keys.add(key)
        if len(self._seen_event_keys) > 800:
            self._seen_event_keys = set(list(self._seen_event_keys)[-400:])
        punch = {
            "employee_external_id": hikvision_employee_no(str(eid)),
            "direction": self._map_direction(item),
            "occurred_at": item.get("time")
            or datetime.now(timezone.utc).isoformat(),
            "source": "hikvision_isapi",
            "serial_no": item.get("serialNo"),
            "raw": item,
        }
        if self._punch_after_admin_login(str(punch["occurred_at"])):
            punch["admin_login_blocked"] = True
        return punch

    @staticmethod
    def _time_stamp(raw: Any) -> str:
        return str(raw or "").strip()[:19]

    @staticmethod
    def _acs_blob(item: dict[str, Any]) -> str:
        return " ".join(str(v).lower() for v in item.values() if isinstance(v, (str, int)))

    @classmethod
    def _acs_is_login(cls, item: dict[str, Any]) -> bool:
        minor = int(item.get("minor") or 0)
        if minor == MINOR_LOCAL_LOGIN:
            return True
        blob = cls._acs_blob(item)
        return "local login" in blob or "locallogin" in blob

    @classmethod
    def _acs_is_logout(cls, item: dict[str, Any]) -> bool:
        minor = int(item.get("minor") or 0)
        if minor == MINOR_LOCAL_LOGOUT:
            return True
        blob = cls._acs_blob(item)
        return "local logout" in blob or "locallogout" in blob

    def _as_dt(self, raw: str) -> Optional[datetime]:
        s = str(raw or "").strip().replace("Z", "+00:00")
        if not s:
            return None
        try:
            dt = datetime.fromisoformat(s)
        except ValueError:
            try:
                dt = datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S")
            except ValueError:
                return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone(timedelta(hours=5)))
        return dt

    def _punch_after_admin_login(self, occurred_at: str) -> bool:
        """Block marks after admin+clock change until unlock; keep fraud window after unlock."""
        punch = self._as_dt(occurred_at)
        # Active lock episode with time change.
        if self.punch_locked and self.time_changed_after_lock:
            login = self._as_dt(str(self.admin_login_at or ""))
            if not login:
                return True
            if not punch:
                return True
            return punch >= login - timedelta(seconds=2)
        # Closed fraud window (after online clock sync unlock).
        start = self._as_dt(str(self.fraud_window_start or ""))
        end = self._as_dt(str(self.fraud_window_end or ""))
        if start and end and punch:
            return start - timedelta(seconds=2) <= punch <= end + timedelta(seconds=2)
        return False

    async def _fetch_capture_jpeg(self, picture_url: Any) -> Optional[str]:
        """Download the terminal snapshot taken at punch time (digest auth)."""
        if not self._client or not isinstance(picture_url, str) or not picture_url:
            return None
        try:
            resp = await self._client.get(picture_url, timeout=12.0)
            if resp.status_code >= 400 or not resp.content.startswith(b"\xff\xd8"):
                logger.warning(
                    "capture jpeg %s bytes=%s url=%s",
                    resp.status_code,
                    len(resp.content),
                    picture_url[-80:],
                )
                return None
            return base64.b64encode(resp.content).decode("ascii")
        except Exception as exc:  # noqa: BLE001
            logger.warning("capture jpeg failed: %s", exc)
            return None

    async def _attach_capture_photos(self, punches: list[dict[str, Any]]) -> None:
        """Attach snapshot only for punches that survive the 60s ingest dedupe."""
        last_kept: dict[str, datetime] = {}
        attached = 0
        for punch in punches:
            eid = str(punch.get("employee_external_id") or "")
            try:
                occurred = datetime.fromisoformat(
                    str(punch.get("occurred_at") or "").replace("Z", "+00:00")
                )
            except ValueError:
                occurred = datetime.now(timezone.utc)
            prev = last_kept.get(eid)
            if prev is not None and (occurred - prev).total_seconds() < 60:
                continue
            last_kept[eid] = occurred
            item = punch.get("raw") if isinstance(punch.get("raw"), dict) else {}
            url = None
            if isinstance(item, dict):
                url = (
                    item.get("pictureURL")
                    or item.get("pictureUrl")
                    or item.get("faceUrl")
                    or item.get("FaceURL")
                    or item.get("captureUrl")
                )
                alert = item.get("alert") if isinstance(item.get("alert"), dict) else None
                if not url and isinstance(alert, dict):
                    ev = alert.get("AccessControllerEvent")
                    if isinstance(ev, dict):
                        url = (
                            ev.get("pictureURL")
                            or ev.get("pictureUrl")
                            or ev.get("faceUrl")
                            or ev.get("FaceURL")
                        )
            b64 = await self._fetch_capture_jpeg(url)
            if b64:
                punch["photo_base64"] = b64
                attached += 1
        if attached:
            logger.info("AcsEvent attached %s capture photos", attached)

    async def pull_events(self) -> list[dict[str, Any]]:
        """Search successful face events (minor 75) — wide window for reconnect backfill.

        Quick reconnects must not lose terminal history: pull up to ~90 days
        (device storage permitting), paginated. Dedupes by serialNo.
        """
        if not self._client:
            return []

        queued = list(self._event_queue)
        self._event_queue.clear()
        for punch in queued:
            if self._punch_after_admin_login(str(punch.get("occurred_at") or "")):
                punch["admin_login_blocked"] = True

        device_now, tz = await self._device_local_now()
        # Old terminals reconnected after Wi‑Fi/offline — keep a long lookback.
        lookback_days = 90
        start_day = (device_now - timedelta(days=lookback_days)).strftime("%Y-%m-%d")
        end_day = device_now.strftime("%Y-%m-%d")
        start = f"{start_day}T00:00:00{tz}"
        end = f"{end_day}T23:59:59{tz}"
        punches: list[dict[str, Any]] = list(queued)
        seen_keys: set[str] = set()
        for punch in punches:
            key = str(punch.get("serial_no") or punch.get("occurred_at") or id(punch))
            seen_keys.add(key)
        position = 0
        page_size = 30
        try:
            # 90d × busy office can be thousands of rows — allow many pages.
            for _ in range(200):
                body = {
                    "AcsEventCond": {
                        "searchID": "1",
                        "searchResultPosition": position,
                        "maxResults": page_size,
                        "major": 5,
                        "minor": 75,
                        "startTime": start,
                        "endTime": end,
                        # Ask device to include capture pictureURL when available.
                        "picEnable": True,
                    }
                }
                resp = await self._client.post(
                    "/ISAPI/AccessControl/AcsEvent?format=json",
                    json=body,
                    timeout=30.0,
                )
                if resp.status_code >= 400:
                    logger.warning(
                        "AcsEvent pull %s %s", resp.status_code, resp.text[:200]
                    )
                    break
                data = resp.json()
                acs = data.get("AcsEvent") or {}
                infos = acs.get("InfoList") or acs.get("Info") or []
                if isinstance(infos, dict):
                    infos = [infos]
                strg = acs.get("responseStatusStrg")
                total = acs.get("totalMatches")
                if not infos:
                    if len(punches) == len(queued):
                        logger.info(
                            "AcsEvent empty strg=%s total=%s window=%s..%s",
                            strg,
                            total,
                            start,
                            end,
                        )
                    break
                for item in infos:
                    punch = self._punch_from_acs_item(item)
                    if not punch:
                        continue
                    key = str(
                        punch.get("serial_no")
                        or punch.get("occurred_at")
                        or f"{position}-{len(punches)}"
                    )
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)
                    punches.append(punch)
                if strg != "MORE":
                    break
                position += len(infos)
            if self.clock_read_ok:
                drift = self._clock_drift_seconds(device_now, tz)
                self.last_drift_seconds = drift
                tzinfo = self._offset_tz(tz)
                aware = (
                    device_now
                    if device_now.tzinfo is not None
                    else device_now.replace(tzinfo=tzinfo)
                )
                self.last_device_now_iso = aware.isoformat()
                if punches:
                    await self._attach_capture_photos(punches)
                    self._apply_clock_trust(punches, drift)
                    logger.info(
                        "AcsEvent pulled %s punches window=%s..%s drift=%ss",
                        len(punches),
                        start,
                        end,
                        int(round(drift)),
                    )
                if abs(drift) > CLOCK_SKEW_SECONDS:
                    logger.warning(
                        "device clock drift %.0fs (threshold %ss) — resync",
                        drift,
                        CLOCK_SKEW_SECONDS,
                    )
                    await self.maybe_align_clock(drift)
            else:
                logger.warning("device clock unread — skip trust rewrite/align")
                if punches:
                    await self._attach_capture_photos(punches)
            return punches
        except Exception as exc:  # noqa: BLE001
            logger.warning("AcsEvent pull failed: %s", exc)
            return punches

    async def subscribe_events(self, on_event: Any = None) -> None:
        """Start background alertStream consumer (realtime punches)."""
        if on_event is not None:
            self._on_realtime_event = on_event
        if not self._client:
            return
        if self._subscribe_task and not self._subscribe_task.done():
            return
        self._subscribe_task = asyncio.create_task(self._alert_stream_loop())

    @staticmethod
    def _boundary_from_content_type(content_type: str | None) -> bytes:
        """Parse multipart boundary; fall back to Hikvision's common default."""
        if content_type:
            m = re.search(r"boundary=([^;\s]+)", content_type, flags=re.I)
            if m:
                raw = m.group(1).strip().strip('"')
                if raw:
                    return b"--" + raw.encode("ascii", errors="ignore")
        return b"--MIME_boundary"

    async def _alert_stream_loop(self) -> None:
        """Long-lived multipart alertStream → queue + optional realtime callback."""
        assert self._client is not None
        # Dedicated client so poll/heartbeat timeouts cannot cancel the stream.
        stream_client = httpx.AsyncClient(
            base_url=self.base_url,
            auth=httpx.DigestAuth(self.username, self.password),
            timeout=httpx.Timeout(None, connect=5.0),
            verify=False,
            headers={"Accept": "multipart/mixed"},
        )
        # Prefer plain alertStream (some firmwares reject ?format=json under load).
        url = "/ISAPI/Event/notification/alertStream"
        logger.info("Starting alertStream subscribe on %s", self.base_url)
        try:
            while True:
                if self.auth_locked():
                    wait = max(
                        5.0,
                        (self.auth_lock_until - datetime.now(timezone.utc)).total_seconds()
                        if self.auth_lock_until
                        else 5.0,
                    )
                    await asyncio.sleep(min(wait, 600))
                    continue
                try:
                    async with stream_client.stream("GET", url) as resp:
                        if resp.status_code >= 400:
                            self.realtime_connected = False
                            body_preview = ""
                            try:
                                body_preview = (await resp.aread())[:240].decode(
                                    "utf-8", errors="ignore"
                                )
                            except Exception:  # noqa: BLE001
                                body_preview = ""
                            # Do not call _note_auth_response(resp): streaming
                            # responses break on resp.text access.
                            if resp.status_code == 401 and (
                                "lockStatus>lock" in body_preview
                                or "<lockStatus>lock</lockStatus>" in body_preview
                            ):
                                m = re.search(
                                    r"<unlockTime>\s*(\d+)\s*</unlockTime>",
                                    body_preview,
                                )
                                secs = int(m.group(1)) if m else 120
                                secs = max(30, min(secs + 5, 3600))
                                self.auth_lock_until = datetime.now(
                                    timezone.utc
                                ) + timedelta(seconds=secs)
                            logger.warning(
                                "alertStream %s status %s %s",
                                url,
                                resp.status_code,
                                body_preview.replace("\n", " ")[:160],
                            )
                            wait = 12.0 if "deployExceedMax" in body_preview else 5.0
                            if self.auth_lock_until:
                                wait = max(
                                    wait,
                                    (
                                        self.auth_lock_until
                                        - datetime.now(timezone.utc)
                                    ).total_seconds(),
                                )
                            await asyncio.sleep(min(wait, 600))
                            continue
                        self.realtime_connected = True
                        boundary = self._boundary_from_content_type(
                            resp.headers.get("content-type")
                        )
                        logger.info(
                            "alertStream connected %s boundary=%s",
                            self.base_url,
                            boundary.decode("ascii", errors="ignore"),
                        )
                        buffer = b""
                        async for chunk in resp.aiter_bytes():
                            buffer += chunk
                            if len(buffer) > 4_000_000:
                                buffer = buffer[-500_000:]
                            while True:
                                start = buffer.find(boundary)
                                if start < 0:
                                    break
                                nxt = buffer.find(boundary, start + len(boundary))
                                if nxt < 0:
                                    buffer = buffer[start:]
                                    break
                                part = buffer[start:nxt]
                                buffer = buffer[nxt:]
                                await self._handle_alert_mime_part(part)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    self.realtime_connected = False
                    logger.warning("alertStream disconnected: %s — retry in 5s", exc)
                    await asyncio.sleep(5)
        finally:
            self.realtime_connected = False
            await stream_client.aclose()

    async def _dispatch_realtime_punch(self, punch: dict[str, Any]) -> None:
        """Send realtime punch to callback / queue (with optional capture photo)."""
        self.last_realtime_at = datetime.now(timezone.utc)
        logger.info(
            "realtime punch emp=%s at=%s photo=%s",
            punch.get("employee_external_id"),
            punch.get("occurred_at"),
            "yes" if punch.get("photo_base64") else "no",
        )
        cb = self._on_realtime_event
        if cb is not None:
            try:
                result = cb(punch)
                if asyncio.iscoroutine(result):
                    await result
                return
            except Exception as exc:  # noqa: BLE001
                logger.warning("realtime callback failed: %s", exc)
        self._event_queue.append(punch)

    def _take_orphan_jpeg(self, max_age_s: float = 0.8) -> Optional[str]:
        """Only reuse a JPEG that arrived moments ago for the *pending* punch.

        Longer windows caused cross-employee photo mixups (person A recognized,
        hallway JPEG of person B attached to A's mark).
        """
        if not self._orphan_jpeg_b64 or not self._orphan_jpeg_at:
            return None
        age = (datetime.now(timezone.utc) - self._orphan_jpeg_at).total_seconds()
        b64 = self._orphan_jpeg_b64
        self._orphan_jpeg_b64 = None
        self._orphan_jpeg_at = None
        if age > max_age_s:
            return None
        return b64

    async def _flush_pending_realtime(self) -> None:
        punch = self._pending_realtime_punch
        self._pending_realtime_punch = None
        self._pending_realtime_flush = None
        if punch:
            # Prefer pictureURL from the same AccessControllerEvent — never a
            # stale orphan from another recognition.
            if not punch.get("photo_base64"):
                raw = punch.get("raw") if isinstance(punch.get("raw"), dict) else {}
                url = None
                if isinstance(raw, dict):
                    url = (
                        raw.get("pictureURL")
                        or raw.get("pictureUrl")
                        or raw.get("faceUrl")
                        or raw.get("FaceURL")
                    )
                    alert = raw.get("alert") if isinstance(raw.get("alert"), dict) else None
                    if not url and isinstance(alert, dict):
                        ev = alert.get("AccessControllerEvent")
                        if isinstance(ev, dict):
                            url = (
                                ev.get("pictureURL")
                                or ev.get("pictureUrl")
                                or ev.get("faceUrl")
                                or ev.get("FaceURL")
                            )
                b64 = await self._fetch_capture_jpeg(url)
                if b64:
                    punch["photo_base64"] = b64
            # Orphan only if still empty and extremely fresh (same MIME burst).
            if not punch.get("photo_base64"):
                orphan = self._take_orphan_jpeg(0.8)
                if orphan:
                    punch["photo_base64"] = orphan
            await self._dispatch_realtime_punch(punch)

    def _schedule_pending_realtime_flush(self, delay_s: float = 2.5) -> None:
        if self._pending_realtime_flush and not self._pending_realtime_flush.done():
            self._pending_realtime_flush.cancel()

        async def _delayed() -> None:
            try:
                await asyncio.sleep(delay_s)
                await self._flush_pending_realtime()
            except asyncio.CancelledError:
                return

        self._pending_realtime_flush = asyncio.create_task(_delayed())

    @staticmethod
    def _extract_jpeg_from_mime_part(part: bytes) -> Optional[bytes]:
        """Return JPEG bytes from an alertStream MIME part, if present."""
        head = part[:1200].lower()
        idx = part.find(b"\xff\xd8")
        if idx < 0:
            return None
        # Prefer explicit image parts; also accept raw JPEG payloads.
        if b"image/jpeg" not in head and b"content-type: image" not in head:
            # JSON parts sometimes embed tiny markers — require a meaningful size.
            if b"{" in part[:idx] and (len(part) - idx) < 2000:
                return None
        end = part.rfind(b"\xff\xd9", idx)
        if end > idx:
            return part[idx : end + 2]
        # Incomplete trailing JPEG — keep if large enough to be a real snapshot.
        if (len(part) - idx) >= 2500:
            return part[idx:]
        return None

    async def _handle_alert_mime_part(self, part: bytes) -> None:
        jpeg = self._extract_jpeg_from_mime_part(part)
        if jpeg and len(jpeg) > 500:
            b64 = base64.b64encode(jpeg).decode("ascii")
            if self._pending_realtime_punch is not None:
                if self._pending_realtime_flush and not self._pending_realtime_flush.done():
                    self._pending_realtime_flush.cancel()
                    self._pending_realtime_flush = None
                punch = self._pending_realtime_punch
                self._pending_realtime_punch = None
                punch["photo_base64"] = b64
                await self._dispatch_realtime_punch(punch)
            else:
                # Image may arrive before JSON on some firmwares — hold briefly.
                self._orphan_jpeg_b64 = b64
                self._orphan_jpeg_at = datetime.now(timezone.utc)
                logger.info("alertStream orphan jpeg held (%s bytes)", len(jpeg))
            return

        text = part.decode("utf-8", errors="ignore")
        # Skip pure binary image parts without JSON
        if "{" not in text:
            return
        for data in self._extract_json_objects(text):
            punch = self._punch_from_alert_payload(data)
            if not punch:
                continue
            # Only bind an orphan JPEG that arrived in the same MIME burst
            # (<0.8s). Older orphans belong to a different recognition.
            orphan = self._take_orphan_jpeg(0.8)
            if orphan:
                punch["photo_base64"] = orphan
                await self._dispatch_realtime_punch(punch)
                continue
            # Flush any previous punch waiting for a photo.
            if self._pending_realtime_punch is not None:
                await self._flush_pending_realtime()
            # Hold briefly so the following image/* MIME part can attach.
            self._pending_realtime_punch = punch
            self._schedule_pending_realtime_flush(1.2)

    @staticmethod
    def _extract_json_objects(text: str) -> list[dict[str, Any]]:
        """Extract top-level JSON objects with brace counting (nested-safe)."""
        objs: list[dict[str, Any]] = []
        i = 0
        n = len(text)
        while i < n:
            start = text.find("{", i)
            if start < 0:
                break
            depth = 0
            in_str = False
            esc = False
            end: Optional[int] = None
            for j in range(start, n):
                ch = text[j]
                if in_str:
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                    continue
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        end = j + 1
                        break
            if end is None:
                break
            try:
                data = json.loads(text[start:end])
                if isinstance(data, dict):
                    objs.append(data)
            except Exception:  # noqa: BLE001
                pass
            i = end
        return objs

    # Face / card / fingerprint success minors on DS-K1T (major=5 access events).
    _AUTH_OK_MINORS = frozenset({1, 38, 39, 75, 76})

    def _punch_from_alert_payload(self, data: dict[str, Any]) -> dict[str, Any] | None:
        event = data.get("AccessControllerEvent")
        if not isinstance(event, dict):
            event = data.get("EventNotificationAlert")
        if not isinstance(event, dict):
            # Some firmwares nest under EventNotificationAlert.AccessControllerEvent
            if isinstance(data.get("EventNotificationAlert"), dict):
                nested = data["EventNotificationAlert"].get("AccessControllerEvent")
                event = nested if isinstance(nested, dict) else None
        if not isinstance(event, dict):
            return None

        minor = int(event.get("subEventType") or event.get("minor") or 0)
        major = int(event.get("majorEventType") or event.get("major") or 0)
        eid = (
            event.get("employeeNoString")
            or event.get("employeeNo")
            or event.get("cardNo")
        )
        if not eid:
            return None
        # Prefer known auth-success minors; still accept if major=5 and name present.
        if major in (0, 5) and minor and minor not in self._AUTH_OK_MINORS:
            if not (event.get("name") or event.get("attendanceStatus")):
                return None

        item = dict(event)
        if not item.get("time"):
            item["time"] = data.get("dateTime") or event.get("dateTime")
        if item.get("minor") is None and minor:
            item["minor"] = minor
        if item.get("major") is None and major:
            item["major"] = major
        punch = self._punch_from_acs_item(item)
        if punch:
            punch["source"] = "hikvision_isapi_realtime"
            raw = punch.get("raw") if isinstance(punch.get("raw"), dict) else {}
            punch["raw"] = {**raw, "realtime": True, "alert": data}
        return punch

    def _try_parse_event_chunk(self, piece: bytes) -> None:
        """Legacy single-chunk parser (kept for tests); prefer MIME path."""
        for data in self._extract_json_objects(piece.decode("utf-8", errors="ignore")):
            punch = self._punch_from_alert_payload(data)
            if punch:
                self._event_queue.append(punch)
        # XML fallback
        try:
            root = ET.fromstring(piece.decode("utf-8", errors="ignore"))
            eid = root.findtext(".//employeeNoString") or root.findtext(".//employeeNo")
            if not eid:
                return
            punch = self._punch_from_acs_item(
                {
                    "employeeNoString": eid,
                    "time": root.findtext(".//dateTime")
                    or datetime.now(timezone.utc).isoformat(),
                    "minor": 75,
                    "major": 5,
                }
            )
            if punch:
                punch["source"] = "hikvision_isapi_realtime"
                self._event_queue.append(punch)
        except Exception:
            return

    @staticmethod
    def _map_direction(item: dict[str, Any]) -> str:
        # attendanceStatus / currentVerifyMode hints; default AUTO
        status = str(item.get("attendanceStatus") or item.get("type") or "").lower()
        if "checkin" in status or status in ("1", "in"):
            return "IN"
        if "checkout" in status or status in ("2", "out"):
            return "OUT"
        return "AUTO"
