"""Worklyn Device Gateway — FastAPI + Hikvision / ZKTeco / Mock adapters."""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings
import httpx

from adapters.base import DeviceAdapter, PunchEvent
from adapters.mock import MockAdapter
from adapters.hikvision_isapi import HikvisionIsapiAdapter, hikvision_password_error
from adapters.zkteco_push import ZktecoPushAdapter
from nats_client import PunchPublisher

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("device-gw")


class Settings(BaseSettings):
    model_config = {"env_file": ".env", "extra": "ignore"}

    device_gw_host: str = "0.0.0.0"
    device_gw_port: int = 8800
    device_gw_nats_url: str = "nats://localhost:4222"
    device_gw_nats_subject: str = "hrhub.punch.raw"
    # Nest API base (local or Railway public URL) for HTTP punch ingest fallback
    device_gw_api_url: str = "http://localhost:3002"
    # Must match API PUNCH_INGEST_API_KEY when set
    device_gw_punch_key: str = ""
    default_adapter: str = "mock"


settings = Settings()
app = FastAPI(
    title="Worklyn Device Gateway",
    version="0.2.0",
    description="Hikvision ISAPI + ZKTeco Push + Mock adapters for Face ID punch events",
)

publisher = PunchPublisher(
    url=settings.device_gw_nats_url,
    subject=settings.device_gw_nats_subject,
    api_url=settings.device_gw_api_url,
    punch_key=settings.device_gw_punch_key,
)


class AdapterType(str, Enum):
    mock = "mock"
    hikvision_isapi = "hikvision_isapi"
    hikvision = "hikvision"  # alias → hikvision_isapi
    zkteco_push = "zkteco_push"
    zkteco = "zkteco"  # alias → zkteco_push


class DeviceRegister(BaseModel):
    id: Optional[str] = Field(default=None, description="Optional stable id (Nest device UUID)")
    tenant_id: str
    name: str
    serial: str
    adapter: AdapterType = AdapterType.mock
    host: Optional[str] = None
    port: Optional[int] = 80
    username: Optional[str] = None
    password: Optional[str] = None
    model: Optional[str] = Field(default=None, description="e.g. DS-K1T671M")
    use_https: bool = False
    punch_locked: bool = False
    last_admin_login_serial: int = 0
    admin_login_at: Optional[str] = None


class DeviceInfo(BaseModel):
    id: str
    tenant_id: str
    name: str
    serial: str
    adapter: AdapterType
    status: str
    last_seen: Optional[str] = None
    model: Optional[str] = None


class SyncFaceRequest(BaseModel):
    employee_external_id: str
    employee_name: str
    face_image_base64: Optional[str] = None


class DeleteUserRequest(BaseModel):
    employee_external_id: str


class DeviceRecord:
    def __init__(self, info: DeviceInfo, adapter_impl: DeviceAdapter):
        self.info = info
        self.adapter = adapter_impl


devices: dict[str, DeviceRecord] = {}


def normalize_adapter(adapter: AdapterType) -> AdapterType:
    if adapter in (AdapterType.hikvision, AdapterType.hikvision_isapi):
        return AdapterType.hikvision_isapi
    if adapter in (AdapterType.zkteco, AdapterType.zkteco_push):
        return AdapterType.zkteco_push
    return AdapterType.mock


def make_adapter(dto: DeviceRegister) -> DeviceAdapter:
    kind = normalize_adapter(dto.adapter)
    if kind == AdapterType.mock:
        return MockAdapter(device_serial=dto.serial)
    if kind == AdapterType.zkteco_push:
        return ZktecoPushAdapter(device_serial=dto.serial, host=dto.host)
    return HikvisionIsapiAdapter(
        host=dto.host or "127.0.0.1",
        port=dto.port or 80,
        username=dto.username or "admin",
        password=dto.password or "",
        model=dto.model,
        use_https=dto.use_https,
    )


@app.on_event("startup")
async def startup() -> None:
    await publisher.connect()
    asyncio.create_task(poll_hikvision_events())


@app.on_event("shutdown")
async def shutdown() -> None:
    await publisher.close()


def punch_from_adapter_event(
    device_id: str, rec: DeviceRecord, ev: dict[str, Any]
) -> PunchEvent:
    photo_b64 = ev.get("photo_base64")
    raw = {k: v for k, v in ev.items() if k != "photo_base64"}
    return PunchEvent(
        tenant_id=rec.info.tenant_id,
        device_id=device_id,
        employee_external_id=ev.get("employee_external_id"),
        direction=ev.get("direction", "AUTO"),
        occurred_at=ev.get("occurred_at") or datetime.now(timezone.utc).isoformat(),
        source=ev.get("source", rec.info.adapter.value),
        raw=raw,
        photo_base64=photo_b64 if isinstance(photo_b64, str) else None,
    )


async def publish_adapter_events(device_id: str, rec: DeviceRecord) -> int:
    events = await rec.adapter.pull_events()
    count = 0
    for ev in events:
        punch = punch_from_adapter_event(device_id, rec, ev)
        await publisher.publish(punch)
        count += 1
    return count


def bind_realtime_publisher(device_id: str, rec: DeviceRecord) -> None:
    """Publish alertStream punches immediately (do not wait for AcsEvent poll)."""
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        return

    async def _on_realtime(ev: dict[str, Any]) -> None:
        punch = punch_from_adapter_event(device_id, rec, ev)
        await publisher.publish(punch)
        rec.info.last_seen = datetime.now(timezone.utc).isoformat()
        rec.info.status = "online"
        logger.info(
            "realtime published device=%s emp=%s",
            device_id,
            ev.get("employee_external_id"),
        )

    rec.adapter._on_realtime_event = _on_realtime


async def start_realtime(device_id: str, rec: DeviceRecord) -> None:
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        return
    bind_realtime_publisher(device_id, rec)
    try:
        await rec.adapter.subscribe_events()
    except Exception as exc:  # noqa: BLE001
        logger.warning("subscribe_events skipped device=%s: %s", device_id, exc)


async def apply_admin_login_guard(device_id: str, rec: DeviceRecord) -> bool:
    """Lock punching after local admin password; unlock only after a later sync cycle."""
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        return False
    adapter = rec.adapter
    login = await adapter.detect_new_admin_login()
    if login:
        if adapter.admin_audit:
            await report_admin_session(device_id, rec, "next_login")
        await adapter.lock_punching(login)
        return True
    return False


def _admin_audit_message(device_id: str, rec: DeviceRecord, phase: str) -> dict[str, Any]:
    return {
        "type": "admin_audit",
        "phase": phase,
        "tenantId": rec.info.tenant_id,
        "deviceId": device_id,
    }


async def report_admin_login_snapshots(device_id: str, rec: DeviceRecord) -> None:
    """Camera frames of whoever just entered the admin password (server identifies)."""
    adapter = rec.adapter
    if not isinstance(adapter, HikvisionIsapiAdapter) or not adapter.admin_audit:
        return
    audit = adapter.admin_audit
    try:
        shots = await adapter.capture_admin_snapshots()
    except Exception as exc:  # noqa: BLE001
        logger.warning("admin snapshot failed device=%s: %s", device_id, exc)
        shots = []
    logger.warning("admin login snapshots device=%s frames=%s", device_id, len(shots))
    await publisher.publish_admin_audit(
        {
            **_admin_audit_message(device_id, rec, "login"),
            "adminLoginSerial": int(audit.get("serial") or 0),
            "adminLoginAt": audit.get("loginAt"),
            "loginBy": audit.get("loginBy"),
            "snapshots": shots,
        }
    )


async def report_admin_session(device_id: str, rec: DeviceRecord, reason: str) -> None:
    """Journal + config diff once the admin left the menu (or the lock ended)."""
    adapter = rec.adapter
    if not isinstance(adapter, HikvisionIsapiAdapter):
        return
    try:
        report = await adapter.finish_admin_audit(reason)
    except Exception as exc:  # noqa: BLE001
        logger.warning("admin session audit failed device=%s: %s", device_id, exc)
        return
    if report:
        await publisher.publish_admin_audit(
            {**_admin_audit_message(device_id, rec, "complete"), **report}
        )


async def run_admin_audit_cycle(
    device_id: str, rec: DeviceRecord, locked_this_cycle: bool
) -> None:
    adapter = rec.adapter
    if not isinstance(adapter, HikvisionIsapiAdapter):
        return
    if locked_this_cycle:
        await report_admin_login_snapshots(device_id, rec)
        return
    reason = adapter.admin_audit_due()
    if reason:
        await report_admin_session(device_id, rec, reason)
        return
    try:
        await adapter.refresh_config_baseline()
    except Exception as exc:  # noqa: BLE001
        logger.info("config baseline refresh failed device=%s: %s", device_id, exc)


async def maybe_unlock_after_sync(
    rec: DeviceRecord, locked_this_cycle: bool, hb_ok: bool
) -> None:
    """After admin+time change: unlock only when online AND clock re-aligned with server."""
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        return
    adapter = rec.adapter
    if locked_this_cycle:
        return
    if not hb_ok:
        logger.info("punch unlock deferred — device offline / heartbeat failed")
        return
    reason = adapter.ready_to_unlock()
    if reason is not None:
        if adapter.punch_locked:
            logger.info(
                "punch unlock deferred — %s (need online + clock sync)",
                reason,
            )
        return
    if not publisher.server_ready:
        logger.info(
            "punch unlock deferred — server not ready (status=%s)",
            publisher.status,
        )
        return
    await adapter.unlock_punching()


async def poll_hikvision_events() -> None:
    await asyncio.sleep(2)
    while True:
        cycle_had_punch = False
        for device_id, rec in list(devices.items()):
            if rec.info.adapter != AdapterType.hikvision_isapi:
                continue
            # Worklyn catalog rows often register without LAN host → would poll 127.0.0.1
            # and block the heartbeat loop for real terminals.
            if isinstance(rec.adapter, HikvisionIsapiAdapter):
                host = (rec.adapter.host or "").strip().lower()
                if not host or host in ("127.0.0.1", "localhost", "::1"):
                    continue
                # Avoid hammering ISAPI while the terminal login lock is active.
                if rec.adapter.auth_locked():
                    continue
            try:
                locked_this_cycle = await apply_admin_login_guard(device_id, rec)
                n = await publish_adapter_events(device_id, rec)
                if n:
                    cycle_had_punch = True
                drift = 0.0
                device_now = None
                punch_locked = False
                admin_login_at = None
                admin_login_serial = 0
                auth_failed = False
                hb_ok = False
                if isinstance(rec.adapter, HikvisionIsapiAdapter):
                    drift = float(rec.adapter.last_drift_seconds or 0)
                    device_now = rec.adapter.last_device_now_iso
                    punch_locked = bool(rec.adapter.punch_locked)
                    admin_login_at = rec.adapter.admin_login_at
                    admin_login_serial = int(rec.adapter.last_admin_login_serial or 0)
                    hb_ok = await rec.adapter.heartbeat()
                    auth_failed = bool(rec.adapter.auth_failed)
                    if auth_failed:
                        rec.info.status = "auth_failed"
                    elif hb_ok:
                        rec.info.status = "online"
                        rec.info.last_seen = datetime.now(timezone.utc).isoformat()
                    else:
                        rec.info.status = "offline"
                else:
                    hb_ok = True
                    rec.info.last_seen = datetime.now(timezone.utc).isoformat()
                    rec.info.status = "online"
                await publisher.publish_heartbeat(
                    {
                        "type": "heartbeat",
                        "source": "device_heartbeat",
                        "tenantId": rec.info.tenant_id,
                        "deviceId": device_id,
                        "tenant_id": rec.info.tenant_id,
                        "device_id": device_id,
                        "deviceNow": device_now,
                        "clockDriftSeconds": int(round(drift)),
                        "punches": n,
                        "punchLocked": punch_locked,
                        "adminLoginDetected": locked_this_cycle,
                        "adminLoginAt": admin_login_at,
                        "adminLoginSerial": admin_login_serial,
                        "authFailed": auth_failed,
                        "timeChangedAfterLock": bool(
                            getattr(rec.adapter, "time_changed_after_lock", False)
                        ),
                    }
                )
                if hb_ok:
                    await run_admin_audit_cycle(device_id, rec, locked_this_cycle)
                await maybe_unlock_after_sync(rec, locked_this_cycle, hb_ok)
            except Exception as exc:  # noqa: BLE001
                rec.info.status = "offline"
                auth_failed = (
                    isinstance(rec.adapter, HikvisionIsapiAdapter)
                    and rec.adapter.auth_failed
                )
                if auth_failed:
                    rec.info.status = "auth_failed"
                    try:
                        await publisher.publish_heartbeat(
                            {
                                "type": "heartbeat",
                                "source": "device_heartbeat",
                                "tenantId": rec.info.tenant_id,
                                "deviceId": device_id,
                                "tenant_id": rec.info.tenant_id,
                                "device_id": device_id,
                                "authFailed": True,
                                "punchLocked": bool(rec.adapter.punch_locked),
                                "adminLoginSerial": int(
                                    rec.adapter.last_admin_login_serial or 0
                                ),
                            }
                        )
                    except Exception:  # noqa: BLE001
                        pass
                logger.warning("event poll %s failed: %s", device_id, exc)
        # Faster loop when punches are flowing; otherwise ~2s online pulse.
        await asyncio.sleep(0.5 if cycle_had_punch else 2)


@app.get("/health")
async def health() -> dict[str, Any]:
    realtime = []
    for did, rec in devices.items():
        if isinstance(rec.adapter, HikvisionIsapiAdapter):
            realtime.append(
                {
                    "deviceId": did,
                    "connected": bool(rec.adapter.realtime_connected),
                    "lastAt": rec.adapter.last_realtime_at.isoformat()
                    if rec.adapter.last_realtime_at
                    else None,
                }
            )
    return {
        "status": "ok",
        "service": "hr-hub-device-gw",
        "nats": publisher.status,
        "devices": len(devices),
        "realtime": realtime,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/adapters")
async def list_adapters() -> list[dict[str, str]]:
    return [
        {
            "id": "mock",
            "name": "MockAdapter",
            "description": "Emits fake punch events for local E2E without hardware",
        },
        {
            "id": "hikvision_isapi",
            "name": "HikvisionIsapiAdapter",
            "description": "ISAPI: UserInfo, FaceDataRecord, AcsEvent, alertStream",
        },
        {
            "id": "zkteco_push",
            "name": "ZktecoPushAdapter",
            "description": "ZKTeco Push/ADMS MVP — accept pushed punches + user sync",
        },
    ]


@app.get("/devices", response_model=list[DeviceInfo])
async def list_devices() -> list[DeviceInfo]:
    return [d.info for d in devices.values()]


@app.post("/devices", response_model=DeviceInfo)
async def register_device(body: DeviceRegister) -> DeviceInfo:
    kind = normalize_adapter(body.adapter)
    device_id = body.id or str(uuid.uuid4())
    if device_id in devices:
        # Re-register / refresh adapter
        old = devices[device_id]
        await old.adapter.disconnect()

    adapter = make_adapter(body)
    if isinstance(adapter, HikvisionIsapiAdapter):
        adapter.restore_punch_lock(
            locked=body.punch_locked,
            last_serial=body.last_admin_login_serial,
            login_at=body.admin_login_at,
        )
    await adapter.connect()
    if kind == AdapterType.hikvision_isapi:
        if isinstance(adapter, HikvisionIsapiAdapter):
            try:
                await adapter.sync_clock()
            except Exception as exc:  # noqa: BLE001
                logger.warning("sync_clock skipped: %s", exc)

    ok = await adapter.heartbeat()
    info = DeviceInfo(
        id=device_id,
        tenant_id=body.tenant_id,
        name=body.name,
        serial=body.serial,
        adapter=kind,
        status="online" if ok or kind == AdapterType.mock else "offline",
        last_seen=datetime.now(timezone.utc).isoformat(),
        model=body.model,
    )
    devices[device_id] = DeviceRecord(info, adapter)
    if kind == AdapterType.hikvision_isapi:
        await start_realtime(device_id, devices[device_id])
    logger.info("Registered device %s (%s) tenant=%s", device_id, kind, body.tenant_id)
    return info


class ChangePasswordRequest(BaseModel):
    new_password: str = Field(min_length=8, max_length=16)


class VerifyPasswordRequest(BaseModel):
    password: str = Field(min_length=8, max_length=16)


@app.post("/devices/{device_id}/change-password")
async def change_password(device_id: str, body: ChangePasswordRequest) -> dict[str, Any]:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        raise HTTPException(400, "Password change is only supported for Hikvision")
    rule = hikvision_password_error(body.new_password, rec.adapter.username or "admin")
    if rule:
        raise HTTPException(400, rule)
    ok, err = await rec.adapter.change_password(body.new_password)
    if not ok:
        raise HTTPException(502, err or "Terminal rejected password change")
    try:
        await start_realtime(device_id, rec)
    except Exception as exc:  # noqa: BLE001
        logger.warning("resubscribe after password change: %s", exc)
    rec.info.status = "online"
    rec.info.last_seen = datetime.now(timezone.utc).isoformat()
    return {"ok": True, "device_id": device_id}


@app.post("/devices/{device_id}/verify-password")
async def verify_password(device_id: str, body: VerifyPasswordRequest) -> dict[str, Any]:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        raise HTTPException(400, "Password verify is only supported for Hikvision")
    adapter = rec.adapter
    rule = hikvision_password_error(body.password, adapter.username or "admin")
    if rule:
        raise HTTPException(400, rule)
    try:
        async with httpx.AsyncClient(
            base_url=adapter.base_url,
            auth=httpx.DigestAuth(adapter.username or "admin", body.password),
            timeout=httpx.Timeout(8.0, connect=3.0),
            verify=False,
        ) as client:
            resp = await client.get("/ISAPI/System/deviceInfo")
            if resp.status_code >= 400:
                raise HTTPException(401, "Пароль терминала не принят")
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(502, f"Не удалось проверить пароль: {exc}") from exc
    adapter.password = body.password
    adapter.auth_failed = False
    try:
        await adapter.disconnect()
        await adapter.connect()
    except Exception as exc:  # noqa: BLE001
        logger.warning("reconnect after verify-password: %s", exc)
    await start_realtime(device_id, rec)
    rec.info.status = "online"
    rec.info.last_seen = datetime.now(timezone.utc).isoformat()
    return {"ok": True, "device_id": device_id}


@app.post("/devices/{device_id}/heartbeat", response_model=DeviceInfo)
async def heartbeat(device_id: str) -> DeviceInfo:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    ok = await rec.adapter.heartbeat()
    rec.info.status = "online" if ok else "offline"
    rec.info.last_seen = datetime.now(timezone.utc).isoformat()
    return rec.info


@app.post("/devices/{device_id}/unlock-punching")
async def unlock_punching(device_id: str) -> dict[str, Any]:
    """Force re-enable face/card auth after local admin login lock."""
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    if not isinstance(rec.adapter, HikvisionIsapiAdapter):
        raise HTTPException(400, "Only Hikvision ISAPI devices support unlock")
    # Ensure client is connected with stored credentials
    try:
        await rec.adapter.connect()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(502, f"Device connect failed: {exc}") from exc
    ok = await rec.adapter.unlock_punching()
    if not ok:
        # Still try enable flags even if adapter thought it wasn't locked
        ok = await rec.adapter.set_punching_enabled(True)
        rec.adapter.punch_locked = False
        rec.adapter.awaiting_sync_unlock = False
    rec.info.status = "online" if ok else rec.info.status
    return {
        "ok": bool(ok),
        "device_id": device_id,
        "punch_locked": bool(rec.adapter.punch_locked),
        "lock_method": rec.adapter.lock_method,
    }


@app.post("/devices/{device_id}/sync-face")
async def sync_face(device_id: str, body: SyncFaceRequest) -> dict[str, Any]:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    try:
        user_ok = await rec.adapter.upsert_user(
            employee_id=body.employee_external_id,
            name=body.employee_name,
        )
        if not user_ok:
            raise HTTPException(502, "Device rejected UserInfo upsert")
        face_ok = await rec.adapter.enroll_face(
            employee_id=body.employee_external_id,
            face_image_base64=body.face_image_base64,
        )
        if not face_ok:
            raise HTTPException(502, "Device rejected face enroll")
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.warning("sync-face failed device=%s: %s", device_id, exc)
        raise HTTPException(502, f"Device sync failed: {exc}") from exc
    return {
        "device_id": device_id,
        "employee_external_id": body.employee_external_id,
        "synced": True,
        "face_enrolled": True,
        "adapter": normalize_adapter(rec.info.adapter).value,
    }


@app.post("/devices/{device_id}/delete-user")
async def delete_user(device_id: str, body: DeleteUserRequest) -> dict[str, Any]:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    try:
        ok = await rec.adapter.delete_user(employee_id=body.employee_external_id)
        if not ok:
            raise HTTPException(502, "Device rejected user delete")
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.warning("delete-user failed device=%s: %s", device_id, exc)
        raise HTTPException(502, f"Device delete failed: {exc}") from exc
    return {
        "device_id": device_id,
        "employee_external_id": body.employee_external_id,
        "deleted": True,
        "adapter": normalize_adapter(rec.info.adapter).value,
    }


class RemoteCommandRequest(BaseModel):
    action: str


@app.post("/devices/{device_id}/remote")
async def remote_command(device_id: str, body: RemoteCommandRequest) -> dict[str, Any]:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    action = (body.action or "").strip().lower()
    if action == "heartbeat":
        ok = await rec.adapter.heartbeat()
        rec.info.status = "online" if ok else "offline"
        rec.info.last_seen = datetime.now(timezone.utc).isoformat()
        return {"ok": ok, "action": action, "status": rec.info.status}
    if action == "sync_clock":
        fn = getattr(rec.adapter, "sync_clock", None)
        if not callable(fn):
            raise HTTPException(400, "Синхронизация часов не поддерживается")
        ok = await fn()
        return {"ok": bool(ok), "action": action}
    if action == "pull_events":
        events = await rec.adapter.pull_events()
        published = 0
        for ev in events:
            punch = punch_from_adapter_event(device_id, rec, ev)
            await publisher.publish(punch)
            published += 1
        return {"ok": True, "action": action, "count": published}
    if action == "open_door":
        fn = getattr(rec.adapter, "open_door", None)
        if not callable(fn):
            raise HTTPException(400, "Открытие двери не поддерживается")
        ok = await fn()
        return {"ok": bool(ok), "action": action}
    if action == "reboot":
        fn = getattr(rec.adapter, "reboot", None)
        if not callable(fn):
            raise HTTPException(400, "Перезагрузка не поддерживается")
        ok = await fn()
        return {"ok": bool(ok), "action": action}
    raise HTTPException(400, f"Unknown action: {action}")


@app.post("/devices/{device_id}/pull-events")
async def pull_events(device_id: str, publish: bool = True) -> dict[str, Any]:
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    events = await rec.adapter.pull_events()
    published: list[dict[str, Any]] = []
    for ev in events:
        punch = punch_from_adapter_event(device_id, rec, ev)
        if publish:
            await publisher.publish(punch)
        dumped = punch.model_dump()
        dumped.pop("photo_base64", None)
        published.append(dumped)
    return {"count": len(published), "events": published}


@app.post("/devices/{device_id}/emit-mock-punch")
async def emit_mock_punch(
    device_id: str,
    employee_external_id: str = "face-0001",
    direction: str = "IN",
) -> dict[str, Any]:
    """Convenience: force a mock punch and publish to NATS."""
    rec = devices.get(device_id)
    if not rec:
        raise HTTPException(404, "Device not found")
    if not isinstance(rec.adapter, MockAdapter):
        raise HTTPException(400, "Only available for MockAdapter devices")
    punch = await rec.adapter.emit_punch(
        employee_external_id=employee_external_id,
        direction=direction,
    )
    event = PunchEvent(
        tenant_id=rec.info.tenant_id,
        device_id=device_id,
        employee_external_id=punch["employee_external_id"],
        direction=punch["direction"],
        occurred_at=punch["occurred_at"],
        source="mock",
        raw=punch,
    )
    await publisher.publish(event)
    return event.model_dump()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.device_gw_host,
        port=settings.device_gw_port,
        reload=True,
    )
