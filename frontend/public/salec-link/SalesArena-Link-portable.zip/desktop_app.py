"""Native-feeling Windows desktop shell (WebView2) for Worklyn Link."""
from __future__ import annotations

import ctypes
import json
import sys
import threading
from pathlib import Path
from typing import Any

from discovery import OFFLINE, OK, TIMEOUT, UNAUTHORIZED
from paths import app_icon_names, bound_web_label, find_root, load_config, read_pairing_token, read_tunnel_url
from session import OfficeLinkSession, SubmitResult
from auth_lock import CONFIRM, LOCKED

APP_TITLE = "Sales Arena Link"
APP_AUMID = "HRHUB.OfficeLink.Desktop"

# Win32 helpers for frameless chrome (min/max/resize).
_SW_MINIMIZE = 6
_SW_MAXIMIZE = 3
_SW_RESTORE = 9
_WM_NCLBUTTONDOWN = 0x00A1
_HT_BY_EDGE = {
    "w": 10,   # HTLEFT
    "e": 11,   # HTRIGHT
    "n": 12,   # HTTOP
    "nw": 13,  # HTTOPLEFT
    "ne": 14,  # HTTOPRIGHT
    "s": 15,   # HTBOTTOM
    "sw": 16,  # HTBOTTOMLEFT
    "se": 17,  # HTBOTTOMRIGHT
}


def _ui_dir() -> Path:
    here = Path(__file__).resolve().parent
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        exe_dir = Path(sys.executable).resolve().parent
        # Prefer on-disk ui next to the exe so CSS/JS patches apply without rebuild.
        candidates = [
            exe_dir / "ui",
            exe_dir / "_internal" / "ui",
            here / "ui",
        ]
        if meipass:
            candidates.append(Path(meipass) / "ui")
        for cand in candidates:
            if (cand / "index.html").is_file():
                return cand
    return here / "ui"


def _set_aumid() -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_AUMID)
    except Exception:
        pass


def _dump(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)


class LinkApi:
    def __init__(self, window_holder: dict[str, Any]) -> None:
        self._holder = window_holder
        self.session = OfficeLinkSession()
        self._locations: list[dict[str, str]] = []
        self._reconnect_steps: list[dict[str, str]] = []
        self._last_device: dict[str, Any] = {}
        self._events: list[dict[str, Any]] = []
        self._events_lock = threading.Lock()
        self._sync_busy = False

    def _window(self):
        return self._holder.get("window")

    def _hwnd(self) -> int | None:
        win = self._window()
        if win is None:
            return None
        try:
            native = getattr(win, "native", None)
            if native is None:
                return None
            handle = getattr(native, "Handle", None)
            if handle is None:
                return None
            if hasattr(handle, "ToInt32"):
                return int(handle.ToInt32())
            return int(handle)
        except Exception:
            return None

    def _is_maximized(self) -> bool:
        hwnd = self._hwnd()
        if hwnd and sys.platform == "win32":
            try:
                return bool(ctypes.windll.user32.IsZoomed(hwnd))
            except Exception:
                pass
        win = self._window()
        if win is None:
            return False
        try:
            native = getattr(win, "native", None)
            state = getattr(native, "WindowState", None) if native is not None else None
            return str(state).endswith("Maximized")
        except Exception:
            return False

    def _emit(self, fn: str, payload: Any) -> None:
        """Queue UI events — JS polls them (evaluate_js from worker threads is unreliable)."""
        with self._events_lock:
            self._events.append({"fn": fn, "payload": payload})
            # Keep memory bounded if UI stopped polling.
            if len(self._events) > 100:
                self._events = self._events[-50:]

    def poll_events(self) -> list[dict[str, Any]]:
        with self._events_lock:
            batch = list(self._events)
            self._events.clear()
        return batch

    def clipboard_text(self) -> str:
        """Read clipboard without Tk (Tk+WebView2 can deadlock the UI)."""
        if sys.platform != "win32":
            return ""
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            CF_UNICODETEXT = 13
            if not user32.OpenClipboard(None):
                return ""
            try:
                handle = user32.GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return ""
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return ""
                try:
                    return ctypes.wstring_at(ptr)
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except Exception:
            return ""

    def bootstrap(self) -> dict[str, Any]:
        cfg = load_config(self.session.root)
        token = read_pairing_token(self.session.root)
        bound = ""
        try:
            bound = bound_web_label(cfg, self.session.root) or ""
        except Exception:
            bound = str(cfg.get("webUrl") or "")
        status = {
            "title": "Готово к подключению",
            "sub": "Устройство: —",
            "kind": "accent",
            "badge": "ГОТОВО",
        }
        alert = None
        if not self.session.has_credentials():
            status = {
                "title": "Нужен токен",
                "sub": "Web → Связь с офисом",
                "kind": "warn",
                "badge": "ТОКЕН",
            }
            alert = {
                "text": "Нужен pairing-токен или ключ администратора.",
                "kind": "warn",
            }
        # Kick location load in background (results arrive via poll_events).
        threading.Thread(target=self._load_locations_worker, args=(token,), daemon=True).start()
        has_key = self.session.has_link_key()
        return {
            "tenantCode": self.session.tenant,
            "tenantName": str(cfg.get("tenantName") or self.session.tenant),
            "webUrl": self.session.web_url,
            "apiUrl": self.session.api_url,
            "boundWeb": bound,
            "token": token,
            "hasLinkKey": has_key,
            "tokenOptional": has_key,
            "ip": "",
            "locations": [],
            "locationId": self.session.location_id,
            "status": status,
            "alert": alert,
            "device": {"name": "—", "host": "—", "state": "—", "location": "—"},
            # Light snapshot only — full tunnel probe can hang bootstrap.
            "tunnel": self._tunnel_payload(light=True),
        }

    def save_server_urls(
        self,
        api_url: str = "",
        web_url: str = "",
        tenant_code: str = "",
    ) -> dict[str, Any]:
        """One server link field — API URL; web URL is derived when omitted."""
        from paths import load_config, write_config_urls
        from urllib.parse import urlparse, urlunparse

        raw = (api_url or web_url or "").strip().rstrip("/")
        tenant = (tenant_code or "").strip()
        if not raw:
            return {
                "ok": False,
                "alert": {
                    "text": "Server URL bo‘sh bo‘lmasin (masalan http://127.0.0.1:3002).",
                    "kind": "warn",
                },
            }
        if not (raw.startswith("http://") or raw.startswith("https://")):
            return {
                "ok": False,
                "alert": {
                    "text": "URL http:// yoki https:// bilan boshlansin.",
                    "kind": "warn",
                },
            }

        def _swap_port(url: str, port: int) -> str:
            p = urlparse(url)
            host = p.hostname or ""
            if not host:
                return url
            netloc = f"{host}:{port}"
            if p.username:
                auth = p.username
                if p.password:
                    auth += f":{p.password}"
                netloc = f"{auth}@{netloc}"
            return urlunparse((p.scheme, netloc, "", "", "", "")).rstrip("/")

        api = raw
        web = (web_url or "").strip().rstrip("/")
        low = raw.lower()
        # Single field: accept either API or Web and fill the pair.
        if ":3001" in low or "hubweb" in low or "/web" in low:
            web = raw
            if ":3001" in low:
                api = _swap_port(raw, 3002)
            elif "hubweb" in low:
                api = raw.replace("hr-hubweb", "hr-hubapi").replace("hubweb", "hubapi")
            else:
                api = raw
        elif not web:
            if ":3002" in low:
                web = _swap_port(raw, 3001)
            elif "hubapi" in low:
                web = raw.replace("hr-hubapi", "hr-hubweb").replace("hubapi", "hubweb")
            else:
                web = raw

        write_config_urls(
            api_url=api,
            web_url=web or None,
            tenant_code=tenant or None,
            root=self.session.root,
        )
        self.session.cfg = load_config(self.session.root)
        bound = ""
        try:
            bound = bound_web_label(self.session.cfg, self.session.root) or ""
        except Exception:
            bound = str(self.session.cfg.get("webUrl") or web or "")
        # Refresh locations against the new API when credentials exist.
        if self.session.has_credentials():
            threading.Thread(
                target=self._load_locations_worker,
                args=(self.session.pairing_token(),),
                daemon=True,
            ).start()
        return {
            "ok": True,
            "apiUrl": self.session.api_url,
            "webUrl": self.session.web_url,
            "tenantCode": self.session.tenant,
            "boundWeb": bound or self.session.web_url or api,
            "hasLinkKey": self.session.has_link_key(),
            "tokenOptional": self.session.has_link_key(),
            "status": {
                "title": "Сервер saqlandi",
                "sub": self.session.api_url,
                "kind": "ok",
                "badge": "API",
            },
            "alert": {
                "text": f"Server ssilkasi: {self.session.api_url}",
                "kind": "ok",
            },
        }

    def save_token(self, token: str) -> dict[str, Any]:
        saved = (token or "").strip()
        self.session.set_pairing_token(saved)
        ok = self.session.has_credentials()
        if saved:
            threading.Thread(
                target=self._load_locations_worker, args=(saved,), daemon=True
            ).start()
        return {
            "status": {
                "title": "Токен сохранён" if ok else "Токен пуст",
                "sub": "Локации обновляются…" if saved else "Устройство: —",
                "kind": "ok" if ok else "warn",
                "badge": "ТОКЕН",
            },
            "alert": {
                "text": (
                    "Pairing-токен сохранён — локации загружаются."
                    if ok
                    else "Вставьте токен из Web."
                ),
                "kind": "ok" if ok else "warn",
            },
        }

    def unlock_auth(self) -> dict[str, Any]:
        """Clear app-side password lock so operator can retry immediately."""
        self.session.auth.reset()
        return {
            "status": {
                "title": "Готово к подключению",
                "sub": "Блокировка снята — введите пароль терминала",
                "kind": "accent",
                "badge": "ГОТОВО",
            },
            "alert": {
                "text": (
                    "Блокировка снята. Нужен текущий пароль администратора "
                    "на терминале Hikvision (не пароль Web Worklyn)."
                ),
                "kind": "ok",
            },
            "locked": False,
        }

    def auth_status(self) -> dict[str, Any]:
        locked = self.session.auth.is_locked()
        return {
            "locked": locked,
            "remaining": self.session.auth.remaining_seconds(),
            "fails": self.session.auth.fail_count,
            "maxFails": self.session.auth.max_fails,
        }

    def set_location(self, location_id: str) -> bool:
        self.session.set_location_id(location_id)
        return True

    def refresh_locations(self, token: str = "") -> bool:
        if token and token.strip() != (self.session.pairing_token() or ""):
            self.session.set_pairing_token(token.strip())
        threading.Thread(
            target=self._load_locations_worker, args=(self.session.pairing_token(),), daemon=True
        ).start()
        return True

    def _load_locations_worker(self, token: str) -> None:
        try:
            import api_client

            from paths import read_link_key, write_pairing_token

            pairing = (token or self.session.pairing_token() or "").strip()
            link_key = read_link_key(self.session.root)
            code, data = api_client.list_locations(
                self.session.api_url,
                link_key,
                self.session.tenant,
                pairing_token=pairing or None,
            )
            # Expired short-lived token must not block long-lived link.key.
            if code == 401 and pairing and link_key:
                msg = ""
                if isinstance(data, dict):
                    msg = str(data.get("message") or data.get("error") or "")
                if "expired" in msg.lower() or "invalid" in msg.lower() or not msg:
                    try:
                        write_pairing_token("", self.session.root)
                    except Exception:
                        pass
                    code, data = api_client.list_locations(
                        self.session.api_url,
                        link_key,
                        self.session.tenant,
                        pairing_token=None,
                    )
        except Exception as exc:
            self._emit(
                "onLocations",
                {
                    "locations": [],
                    "alert": {"text": f"Локации недоступны: {exc}", "kind": "warn"},
                },
            )
            return
        items: list[dict[str, str]] = []
        if code == 200 and isinstance(data, dict):
            raw = data.get("locations") or data.get("items") or data.get("data") or []
            if isinstance(raw, list):
                for row in raw:
                    if not isinstance(row, dict):
                        continue
                    lid = str(row.get("id") or row.get("locationId") or "").strip()
                    name = str(row.get("name") or row.get("title") or lid).strip()
                    if lid:
                        items.append({"id": lid, "label": name})
        self._locations = items
        if items and not self.session.location_id:
            self.session.set_location_id(items[0]["id"])
        alert = None
        if not items:
            detail = ""
            if isinstance(data, dict):
                detail = str(data.get("message") or data.get("error") or "").strip()
            if code == 401:
                alert = {
                    "text": (
                        "Токен устарел или ключ неверный. "
                        "Создайте новый pairing-токен в Web или проверьте link.key. "
                        + (detail[:80] if detail else "")
                    ).strip(),
                    "kind": "warn",
                }
            else:
                alert = {
                    "text": (
                        "Локации не найдены. Проверьте токен и доступ к API."
                        + (f" ({detail})" if detail else f" (HTTP {code})")
                    ),
                    "kind": "warn",
                }
        self._emit(
            "onLocations",
            {
                "locations": items,
                "locationId": self.session.location_id,
                "alert": alert,
            },
        )

    def scan(self, ip: str = "") -> bool:
        threading.Thread(target=self._scan_worker, args=(ip or "",), daemon=True).start()
        return True

    def _scan_worker(self, ip: str) -> None:
        try:
            if ip.strip():
                chosen = self.session.choose_ip(ip.strip())
                if chosen is None:
                    self._emit(
                        "onScanDone",
                        {"ok": False, "message": "Некорректный IP-адрес."},
                    )
                    return
                devices = [chosen] if chosen.online else []
                if not chosen.online:
                    self._emit(
                        "onScanDone",
                        {
                            "ok": False,
                            "message": "Устройство не в сети.",
                            "ip": ip.strip(),
                        },
                    )
                    return
            else:
                devices = self.session.scan()
            if not devices:
                self._emit(
                    "onScanDone",
                    {"ok": False, "message": "Терминал в LAN не найден."},
                )
                return
            if len(devices) == 1:
                pick = devices[0]
                self.session.choose(pick.host, pick.port)
            else:
                pick = self.session.chosen or devices[0]
            state = self.session.detected_state_label() if self.session.chosen else "—"
            self._emit(
                "onScanDone",
                {
                    "ok": True,
                    "ip": (pick.host if pick else ""),
                    "needPick": len(devices) > 1 and self.session.chosen is None,
                    "devices": [
                        {
                            "host": d.host,
                            "port": int(d.port or 80),
                            "name": d.hint_name or "Hikvision",
                        }
                        for d in devices
                    ],
                    "sub": (
                        f"Устройство: {pick.host}"
                        if len(devices) == 1
                        else f"Найдено: {len(devices)} — выберите IP"
                    ),
                    "status": {
                        "title": (
                            "Терминал найден"
                            if len(devices) == 1
                            else f"Найдено: {len(devices)}"
                        ),
                        "sub": (
                            f"Устройство: {pick.host}"
                            if len(devices) == 1
                            else "Выберите терминал или проверьте пароль"
                        ),
                        "kind": "ok" if len(devices) == 1 else "warn",
                        "badge": "ОНЛАЙН" if len(devices) == 1 else "ВЫБОР",
                    },
                    "device": {
                        "name": getattr(pick, "hint_name", "") or "Hikvision",
                        "host": pick.host if pick else "",
                        "state": state,
                        "location": self._location_label(),
                        "apiUrl": self.session.api_url,
                    },
                    "alert": {
                        "text": (
                            "Устройство найдено."
                            if len(devices) == 1
                            else f"LAN da {len(devices)} ta terminal — tanlang yoki parolni tekshiring."
                        ),
                        "kind": "ok" if len(devices) == 1 else "warn",
                    },
                },
            )
        except Exception as exc:
            self._emit("onScanDone", {"ok": False, "message": str(exc)})

    def choose_device(self, host: str, port: int = 80) -> dict[str, Any]:
        info = self.session.select_scanned_host(str(host or "").strip(), int(port or 80))
        if info is None:
            return {
                "ok": False,
                "alert": {"text": "Некорректный IP.", "kind": "warn"},
            }
        return {
            "ok": True,
            "ip": info.host,
            "status": {
                "title": "Выбрано",
                "sub": f"Устройство: {info.host}",
                "kind": "ok",
                "badge": "ONLINE",
            },
            "device": {
                "name": info.hint_name or "Hikvision",
                "host": info.host,
                "state": self.session.detected_state_label(),
                "location": self._location_label(),
                "apiUrl": self.session.api_url,
            },
        }

    def probe_passwords(self, password: str, ip_hint: str = "") -> bool:
        threading.Thread(
            target=self._probe_passwords_worker,
            args=(str(password or ""), str(ip_hint or "").strip()),
            daemon=True,
        ).start()
        return True

    def _probe_passwords_worker(self, password: str, ip_hint: str) -> None:
        try:
            if not self.session.devices:
                self.session.scan(ip_hint=ip_hint or None)
            results, match, reason = self.session.pick_password_match(
                password, host_hint=ip_hint or None
            )
            devices = [
                {
                    "host": r.host,
                    "port": int(r.port or 80),
                    "name": r.name or "Hikvision",
                    "serialNumber": r.serialNumber or "",
                    "ok": bool(r.ok),
                }
                for r in results
            ]
            if reason == "ok" and match is not None:
                self._emit(
                    "onProbeDone",
                    {
                        "reason": "ok",
                        "ip": match.host,
                        "devices": devices,
                        "status": {
                            "title": "Пароль совпал",
                            "sub": f"Устройство: {match.host}",
                            "kind": "ok",
                            "badge": "ПАРОЛЬ OK",
                        },
                        "alert": {
                            "text": f"Parol mos: {match.host}. «Подключить» bilan davom eting.",
                            "kind": "ok",
                        },
                        "device": {
                            "name": match.name or "Hikvision",
                            "host": match.host,
                            "state": self.session.detected_state_label(),
                            "location": self._location_label(),
                            "apiUrl": self.session.api_url,
                        },
                    },
                )
                return
            if reason == "need_pick":
                self._emit(
                    "onProbeDone",
                    {
                        "reason": "need_pick",
                        "needPick": True,
                        "devices": devices,
                        "status": {
                            "title": "Выберите устройство",
                            "sub": "Parol bir nechta IP da mos",
                            "kind": "warn",
                            "badge": "ВЫБОР",
                        },
                        "alert": {
                            "text": "Parol bir nechta terminalga mos. Ro‘yxatdan keraklisini tanlang.",
                            "kind": "warn",
                        },
                    },
                )
                return
            if reason == "none":
                self._emit(
                    "onProbeDone",
                    {
                        "reason": "none",
                        "devices": devices,
                        "status": {
                            "title": "Пароль не подошёл",
                            "kind": "danger",
                            "badge": "ПАРОЛЬ",
                            "sub": "Нет совпадений",
                        },
                        "alert": {
                            "text": "Parol hech qaysi topilgan terminalga mos kelmadi.",
                            "kind": "danger",
                        },
                    },
                )
                return
            self._emit(
                "onProbeDone",
                {
                    "reason": reason,
                    "devices": devices,
                    "alert": {
                        "text": "Avval «Найти» bilan terminallarni qidiring yoki parolni yozing.",
                        "kind": "warn",
                    },
                },
            )
        except Exception as exc:
            self._emit(
                "onProbeDone",
                {"reason": "error", "alert": {"text": str(exc), "kind": "danger"}},
            )

    def confirm_connect(self, ip: str, location_label: str, password: str) -> bool:
        try:
            from device_email import normalize_recovery_email

            recovery = normalize_recovery_email(
                str((self.session.cfg or {}).get("recoveryEmail") or "")
            )
        except Exception:
            recovery = "—"
        msg = (
            "Подтвердите перед подключением.\n\n"
            f"IP: {ip or '—'}\n"
            f"Локация: {location_label or '—'}\n"
            f"Пароль администратора: {password}\n"
            f"Почта восстановления: {recovery}\n\n"
            "Будет установлен новый пароль и выполнена привязка."
        )
        win = self._window()
        if win is None:
            return True
        try:
            return bool(win.create_confirmation_dialog("Подтверждение", msg))
        except Exception:
            # If native dialog fails, proceed — operator already clicked Connect.
            return True

    def connect(self, payload: dict[str, Any] | None = None) -> bool:
        data = payload or {}
        threading.Thread(target=self._connect_worker, args=(data,), daemon=True).start()
        return True

    def _connect_worker(self, data: dict[str, Any]) -> None:
        try:
            self._connect_worker_inner(data)
        except Exception as exc:
            self._emit(
                "onConnectDone",
                {
                    "clearPassword": False,
                    "status": {
                        "title": "Ошибка подключения",
                        "kind": "danger",
                        "badge": "ОШИБКА",
                        "sub": str(exc)[:160],
                    },
                    "alert": {"text": str(exc)[:240], "kind": "danger"},
                },
            )

    def _connect_worker_inner(self, data: dict[str, Any]) -> None:
        token = str(data.get("token") or "").strip()
        ip = str(data.get("ip") or "").strip()
        location_id = str(data.get("locationId") or "").strip()
        password = str(data.get("password") or "")
        if token != (self.session.pairing_token() or ""):
            self.session.set_pairing_token(token)
        self.session.set_location_id(location_id or None)
        if not (self.session.location_id or "").strip():
            self._emit(
                "onConnectDone",
                {
                    "clearPassword": False,
                    "status": {
                        "title": "Локация не выбрана",
                        "kind": "warn",
                        "badge": "ЛОКАЦИЯ",
                        "sub": "Устройство: —",
                    },
                    "alert": {
                        "text": "Перед подключением выберите локацию.",
                        "kind": "warn",
                    },
                },
            )
            return
        if not self.session.has_credentials():
            self._emit(
                "onConnectDone",
                {
                    "clearPassword": False,
                    "status": {
                        "title": "Нужен токен",
                        "kind": "warn",
                        "badge": "ТОКЕН",
                        "sub": "Устройство: —",
                    },
                    "alert": {
                        "text": "Нужен pairing-токен или ключ администратора.",
                        "kind": "warn",
                    },
                },
            )
            return
        if ip:
            chosen = self.session.choose_ip(ip)
            if chosen is None or not chosen.online:
                self._emit(
                    "onConnectDone",
                    {
                        "clearPassword": False,
                        "status": {
                            "title": "Устройство не в сети",
                            "kind": "danger",
                            "badge": "OFFLINE",
                            "sub": f"Устройство: {ip}",
                        },
                        "alert": {"text": "Устройство не в сети.", "kind": "danger"},
                    },
                )
                return
        elif not self.session.chosen:
            # Multi-device / no IP: resolve by password across scanned LAN.
            if not self.session.devices:
                self._emit(
                    "onConnectDone",
                    {
                        "clearPassword": False,
                        "status": {
                            "title": "Устройство не найдено",
                            "kind": "warn",
                            "badge": "ПОИСК",
                            "sub": "Сначала нажмите «Найти»",
                        },
                        "alert": {
                            "text": "Сначала найдите терминал в LAN.",
                            "kind": "warn",
                        },
                    },
                )
                return
            results, match, reason = self.session.pick_password_match(password)
            devices = [
                {
                    "host": r.host,
                    "port": int(r.port or 80),
                    "name": r.name or "Hikvision",
                    "serialNumber": r.serialNumber or "",
                    "ok": bool(r.ok),
                }
                for r in results
            ]
            if reason == "need_pick":
                matched = [d for d in devices if d.get("ok")]
                self._emit(
                    "onConnectDone",
                    {
                        "clearPassword": False,
                        "needPick": True,
                        "matches": matched,
                        "devices": devices,
                        "status": {
                            "title": "Выберите устройство",
                            "kind": "warn",
                            "badge": "ВЫБОР",
                            "sub": f"Parol {len(matched)} ta IP da mos",
                        },
                        "alert": {
                            "text": "Parol bir nechta terminalga mos. Ro‘yxatdan tanlang, keyin yana «Подключить».",
                            "kind": "warn",
                        },
                    },
                )
                return
            if reason != "ok" or match is None:
                self._emit(
                    "onConnectDone",
                    {
                        "clearPassword": False,
                        "devices": devices,
                        "status": {
                            "title": "Пароль не подошёл",
                            "kind": "danger",
                            "badge": "ПАРОЛЬ",
                            "sub": "Нет совпадений",
                        },
                        "alert": {
                            "text": "Parol hech qaysi topilgan terminalga mos kelmadi.",
                            "kind": "danger",
                        },
                    },
                )
                return
        elif len(self.session.devices or []) > 1 and not ip:
            # Chosen set but operator didn't confirm IP field — keep chosen.
            pass

        def progress(msg: str) -> None:
            self._emit(
                "onConnectProgress",
                {
                    "status": {
                        "title": (msg or "Подключение…")[:120],
                        "kind": "accent",
                        "badge": "ПОДКЛЮЧЕНИЕ",
                        "sub": f"Устройство: {self.session.chosen.host if self.session.chosen else '—'}",
                    },
                },
            )

        state = (self.session.detected_state or {}).get("state")
        if state == "new":
            self.session.password = password or self.session.password or ""
            linked = self.session.link_to_cloud(progress)
            self._emit("onConnectDone", self._connect_result(linked, clear_pwd=True, linked=True))
            return
        result = self.session.submit_password(password)
        if result.kind == OK:
            linked = self.session.link_to_cloud(progress)
            self._emit("onConnectDone", self._connect_result(linked, clear_pwd=True, linked=True))
            return
        self._emit(
            "onConnectDone",
            self._connect_result(result, clear_pwd=result.kind in (CONFIRM, LOCKED), linked=False),
        )

    def _connect_result(
        self, result: SubmitResult, *, clear_pwd: bool, linked: bool
    ) -> dict[str, Any]:
        kind = result.kind
        host = ""
        if self.session.chosen:
            host = self.session.chosen.host
        if kind == CONFIRM:
            return {
                "clearPassword": False,
                "status": {
                    "title": "Неверный пароль",
                    "kind": "danger",
                    "badge": "ПАРОЛЬ",
                    "sub": f"Устройство: {host or '—'}",
                },
                "alert": {
                    "text": result.message or "Неверный пароль. Введите снова.",
                    "kind": "danger",
                },
            }
        if kind == LOCKED:
            left = ""
            if result.remaining:
                mins, rem = divmod(int(result.remaining), 60)
                left = f" ({mins:02d}:{rem:02d})"
            return {
                "clearPassword": False,
                "status": {
                    "title": "Заблокировано" + left,
                    "kind": "danger",
                    "badge": "LOCK",
                    "sub": f"Устройство: {host or '—'}",
                },
                "alert": {
                    "text": result.message
                    or "Слишком много неверных попыток. Нажмите «Сбросить блокировку».",
                    "kind": "danger",
                },
                "locked": True,
                "remaining": int(result.remaining or 0),
            }
        if kind in (TIMEOUT, OFFLINE, UNAUTHORIZED, "location", "no_key", "empty"):
            return {
                "clearPassword": clear_pwd,
                "status": {
                    "title": result.message or "Ошибка",
                    "kind": "danger" if kind == OFFLINE else "warn",
                    "badge": str(kind).upper(),
                    "sub": f"Устройство: {host or '—'}",
                },
                "alert": {"text": result.message or "Ошибка подключения", "kind": "warn"},
            }
        if kind == "reconnected":
            host = (result.device or {}).get("host") or host
            self._last_device = dict(result.device or {})
            try:
                self.session.write_service_handoff()
            except Exception:
                pass
            try:
                self.session.ensure_tunnel_supervisor()
            except Exception:
                pass
            try:
                from auto_resume import reconcile_link

                reconcile_link(
                    self.session.root,
                    self.session.api_url,
                    self.session.tenant,
                    force_httphost=True,
                )
            except Exception:
                pass
            # Persist hikPush from reconnect response for later auto-resume.
            try:
                hik = (result.device or {}).get("hikPush")
                if isinstance(hik, dict) and hik.get("urlPath"):
                    from paths import load_service_config, write_service_config

                    svc = load_service_config(self.session.root) or {}
                    extra = {
                        k: v
                        for k, v in svc.items()
                        if k
                        not in (
                            "enabled",
                            "apiUrl",
                            "tenantCode",
                            "tunnelMode",
                            "writtenAt",
                        )
                    }
                    extra.update(
                        {
                            "hikPushUrlPath": str(hik.get("urlPath") or ""),
                            "hikPushHost": str(hik.get("hostName") or ""),
                            "hikPushPort": int(hik.get("portNo") or 443),
                            "hikPushProtocol": str(
                                hik.get("protocolType") or "HTTPS"
                            ),
                        }
                    )
                    write_service_config(
                        api_url=self.session.api_url,
                        tenant=self.session.tenant,
                        tunnel_mode=str(svc.get("tunnelMode") or "quick"),
                        root=self.session.root,
                        extra=extra,
                    )
            except Exception:
                pass
            return {
                "clearPassword": False,
                "status": {
                    "title": "Сеть обновлена",
                    "kind": "ok",
                    "badge": "ОБНОВЛЕНО",
                    "sub": f"Устройство: {host or '—'}",
                },
                "alert": {
                    "text": result.message or "Сеть успешно обновлена.",
                    "kind": "ok",
                },
                "device": {
                    "name": (result.device or {}).get("name") or "Hikvision",
                    "host": host,
                    "state": "reconnected",
                    "location": self._location_label(),
                    "apiUrl": self.session.api_url,
                },
                "tunnel": self._tunnel_payload(),
            }
        if kind == "need_pick":
            matches = list((result.device or {}).get("matches") or [])
            return {
                "clearPassword": False,
                "needPick": True,
                "matches": matches,
                "devices": matches,
                "status": {
                    "title": "Выберите устройство",
                    "kind": "warn",
                    "badge": "ВЫБОР",
                    "sub": f"Mos: {len(matches)}",
                },
                "alert": {
                    "text": result.message
                    or "Bir nechta qurilma mos keldi — ro‘yxatdan tanlang.",
                    "kind": "warn",
                },
            }
        if kind == "linked" or linked:
            sealed = bool((result.device or {}).get("sealed"))
            needs_confirm = bool((result.device or {}).get("needsAdminConfirm"))
            notified = bool((result.device or {}).get("notificationSent"))
            confirm_url = str((result.device or {}).get("confirmUrl") or "").strip()
            self._last_device = dict(result.device or {})
            try:
                self.session.write_service_handoff()
            except Exception:
                pass
            try:
                self.session.ensure_tunnel_supervisor()
            except Exception:
                pass
            title = (
                "Ожидание подтверждения в Web"
                if needs_confirm
                else ("Привязка закреплена" if sealed else "Подключено")
            )
            if needs_confirm:
                alert_text = (
                    "Webga tasdiqlash so‘rovi yuborildi"
                    if notified
                    else "Webda «Подтвердить привязку» kerak"
                )
                alert_detail = (
                    "Adminlarga bildirishnoma YUBORILDI (Web → 🔔). "
                    "Qurilma kartasida «Подтвердить привязку» ni bosing — "
                    "keyin yuz sync yoqiladi."
                    if notified
                    else "Bildirishnoma yuborilmagan bo‘lishi mumkin. "
                    "Web → Qurilmalar → shu terminal → «Подтвердить привязку»."
                )
                alert_hint = (
                    f"Havola: {confirm_url}"
                    if confirm_url
                    else "Web bildirishnomalar panelini oching."
                )
            else:
                alert_text = "Настройка завершена — окно можно закрыть."
                alert_detail = "Лица только через Web «Синхронизировать» или Link Sync."
                alert_hint = ""
            return {
                "clearPassword": True,
                "status": {
                    "title": title,
                    "kind": "warn" if needs_confirm else "ok",
                    "badge": "ПОДТВЕРЖДЕНИЕ" if needs_confirm else "ОК",
                    "sub": f"Устройство: {(result.device or {}).get('host') or host or '—'}",
                },
                "alert": {
                    "text": alert_text,
                    "detail": alert_detail,
                    "hint": alert_hint,
                    "kind": "warn" if needs_confirm else "ok",
                },
                "webConfirm": {
                    "needed": needs_confirm,
                    "notificationSent": notified,
                    "confirmUrl": confirm_url,
                },
                "device": {
                    "name": (result.device or {}).get("name") or "Hikvision",
                    "host": (result.device or {}).get("host") or host,
                    "state": "linked",
                    "location": self._location_label(),
                    "apiUrl": self.session.api_url,
                },
                "tunnel": self._tunnel_payload(),
            }
        return {
            "clearPassword": clear_pwd,
            "status": {
                "title": result.message or "Ошибка",
                "kind": "danger",
                "badge": "ОШИБКА",
                "sub": f"Устройство: {host or '—'}",
            },
            "alert": {"text": result.message or "Ошибка", "kind": "danger"},
        }

    def reconnect(self, payload: dict[str, Any] | None = None) -> bool:
        data = payload if isinstance(payload, dict) else {}
        self._reconnect_steps = []
        threading.Thread(
            target=self._reconnect_worker,
            args=(
                str(data.get("password") or ""),
                str(data.get("ip") or "").strip() or None,
            ),
            daemon=True,
        ).start()
        return True

    def _reconnect_worker(
        self, password: str = "", ip_hint: str | None = None
    ) -> None:
        labels = {
            "web": "Веб",
            "scan": "Сканер",
            "match": "Сопоставление",
            "auth": "Пароль",
            "link": "Связь",
        }

        def on_step(step_id: str, state: str, detail: str = "") -> None:
            found = False
            for row in self._reconnect_steps:
                if row["id"] == step_id:
                    row["state"] = state
                    row["detail"] = detail
                    row["label"] = labels.get(step_id, step_id)
                    found = True
                    break
            if not found:
                self._reconnect_steps.append(
                    {
                        "id": step_id,
                        "state": state,
                        "detail": detail,
                        "label": labels.get(step_id, step_id),
                    }
                )
            self._emit("onReconnectProgress", self._reconnect_steps)

        try:
            result = self.session.auto_reconnect_network(
                password,
                on_step=on_step,
                ip_hint=ip_hint,
            )
        except Exception as exc:
            self._emit(
                "onReconnectDone",
                {
                    "status": {
                        "title": "Ошибка восстановления",
                        "kind": "danger",
                        "badge": "ОШИБКА",
                        "sub": str(exc),
                    },
                    "alert": {"text": str(exc), "kind": "danger"},
                    "steps": self._reconnect_steps,
                },
            )
            return
        payload = self._connect_result(
            result,
            clear_pwd=False,
            linked=result.kind in ("linked", "reconnected"),
        )
        payload["steps"] = self._reconnect_steps
        self._emit("onReconnectDone", payload)

    def tunnel_status(self) -> bool:
        threading.Thread(target=self._tunnel_status_worker, daemon=True).start()
        return True

    def restore_tunnel(self) -> bool:
        threading.Thread(target=self._restore_tunnel_worker, daemon=True).start()
        return True

    def _tunnel_payload(self, *, light: bool = False) -> dict[str, str]:
        if light:
            try:
                url = read_tunnel_url(self.session.root) or "—"
            except Exception:
                url = "—"
            return {"state": "не проверено", "url": url or "—"}
        try:
            health = self.session.tunnel_health()
        except Exception:
            return {"state": "нет данных", "url": "—"}
        if health is None:
            return {"state": "нет данных", "url": "—"}
        if isinstance(health, dict):
            return {
                "state": str(health.get("state") or health.get("status") or "—"),
                "url": str(health.get("url") or health.get("publicUrl") or "—"),
            }
        ok = bool(getattr(health, "ok", False))
        url = str(getattr(health, "tunnel_url", "") or getattr(health, "url", "") or "—")
        mode = str(getattr(health, "mode", "") or "")
        message = str(getattr(health, "message", "") or "")
        state = "онлайн" if ok else "офлайн"
        if mode:
            state = f"{state} ({mode})"
        if message and not ok:
            state = message[:80]
        # Soften alarm when LAN face agent is already syncing.
        try:
            from paths import load_service_config, service_status_file, tunnel_cooldown_remaining
            import json

            left = tunnel_cooldown_remaining(self.session.root)
            st_path = service_status_file(self.session.root)
            face_ok = False
            if st_path.is_file():
                st = json.loads(st_path.read_text(encoding="utf-8"))
                face_ok = bool(st.get("faceAgent")) and str(st.get("state") or "") == "face_agent"
            lan_fb = bool(load_service_config(self.session.root).get("lanFallback"))
            if lan_fb and url and "trycloudflare" not in url.lower():
                state = "онлайн (LAN)"
            elif left > 0 and not ok:
                mins = max(1, (left + 59) // 60)
                state = (
                    f"LAN mumkin — Cloudflare ~{mins} daq "
                    "(«Восстановить туннель» LAN ga o‘tadi)"
                )
            elif face_ok and not ok:
                state = "LAN sync OK (tunnel kutilyapti)"
        except Exception:
            pass
        return {"state": state, "url": url or "—"}

    def _tunnel_status_worker(self) -> None:
        tunnel = self._tunnel_payload()
        self._emit(
            "onTunnelDone",
            {
                "tunnel": tunnel,
                "status": {
                    "title": tunnel.get("state") or "Туннель",
                    "kind": "accent",
                    "badge": "ТУННЕЛЬ",
                    "sub": tunnel.get("url") or "—",
                },
            },
        )

    def _restore_tunnel_worker(self) -> None:
        try:
            result = self.session.restore_tunnel()
        except Exception as exc:
            self._emit(
                "onTunnelDone",
                {
                    "tunnel": self._tunnel_payload(),
                    "alert": {"text": str(exc), "kind": "danger"},
                    "status": {
                        "title": "Ошибка туннеля",
                        "kind": "danger",
                        "badge": "ОШИБКА",
                        "sub": str(exc),
                    },
                },
            )
            return
        tunnel = self._tunnel_payload()
        ok = result.kind == "tunnel_ok"
        self._emit(
            "onTunnelDone",
            {
                "tunnel": tunnel,
                "alert": {
                    "text": result.message or ("Туннель восстановлен" if ok else "Не удалось"),
                    "kind": "ok" if ok else "warn",
                },
                "status": {
                    "title": result.message or tunnel.get("state") or "Туннель",
                    "kind": "ok" if ok else "warn",
                    "badge": "ТУННЕЛЬ",
                    "sub": tunnel.get("url") or "—",
                },
            },
        )

    def _location_label(self) -> str:
        lid = self.session.location_id or ""
        for row in self._locations:
            if row.get("id") == lid:
                return row.get("label") or lid
        return lid or "—"

    def sync_status(self) -> dict[str, Any]:
        """Current face sync progress (Web + local agent)."""
        try:
            from face_sync import snapshot_progress
            from link_diag import log_file_path, setup_logging

            setup_logging(self.session.root)
            snap = snapshot_progress(self.session.root)
            snap["logPath"] = str(log_file_path(self.session.root))
            return snap
        except Exception as exc:
            from link_diag import attach_error, explain

            err = explain(str(exc), context="sync_progress")
            return attach_error(
                {"ok": False, "running": False, "percent": 0, "message": err["title"]},
                err,
            )

    def recent_logs(self, limit: int = 60) -> dict[str, Any]:
        try:
            from link_diag import read_recent_logs, setup_logging

            setup_logging(self.session.root)
            return read_recent_logs(self.session.root, limit=int(limit or 60))
        except Exception as exc:
            return {"ok": False, "lines": [], "message": str(exc)[:200]}

    def sync_faces(self, force: bool = False, failed_only: bool = False) -> bool:
        """Start face sync in background — emits onSyncProgress / onSyncDone."""
        if getattr(self, "_sync_busy", False):
            self._emit(
                "onSyncProgress",
                {
                    **self.sync_status(),
                    "message": "Синхронизация уже идёт…",
                    "detail": "Parallel sync bloklangan — joriy jarayon tugashini kuting.",
                    "hint": "Progress bar yangilanishini kuzating yoki logni oching.",
                },
            )
            return False
        self._sync_busy = True
        threading.Thread(
            target=self._sync_faces_worker,
            args=(bool(force), bool(failed_only)),
            daemon=True,
        ).start()
        return True

    def _sync_faces_worker(self, force: bool, failed_only: bool) -> None:
        try:
            from face_sync import run_face_sync
            from link_diag import alert_from_error, explain, log_file_path, setup_logging

            setup_logging(self.session.root)

            def on_progress(payload: dict[str, Any]) -> None:
                self._emit("onSyncProgress", payload)

            result = run_face_sync(
                self.session.root,
                force=force,
                failed_only=failed_only,
                queue=True,
                on_progress=on_progress,
            )
            prog = result.get("progress") if isinstance(result.get("progress"), dict) else {}
            ok = bool(result.get("ok"))
            if ok:
                alert = {
                    "text": result.get("message") or "Синхронизация завершена",
                    "detail": result.get("detail") or "",
                    "hint": result.get("hint") or "",
                    "logPath": str(log_file_path(self.session.root)),
                    "kind": "ok" if not int((prog or {}).get("failed") or 0) else "warn",
                }
            else:
                err = result.get("error") or explain(
                    str(result.get("message") or "Sync xato"),
                    context="sync_failed",
                )
                alert = alert_from_error(err if isinstance(err, dict) else explain(str(err)), kind="danger")
            self._emit(
                "onSyncDone",
                {
                    "ok": ok,
                    "result": result,
                    "progress": prog,
                    "alert": alert,
                    "status": {
                        "title": alert.get("text") or "Синхронизация лиц",
                        "sub": (alert.get("detail") or "")[:120],
                        "kind": alert.get("kind") or ("ok" if ok else "danger"),
                        "badge": "SYNC",
                    },
                },
            )
        except Exception as exc:
            from link_diag import alert_from_error, explain

            err = explain(str(exc), context="sync_failed")
            self._emit(
                "onSyncDone",
                {
                    "ok": False,
                    "alert": alert_from_error(err),
                    "status": {
                        "title": err["title"],
                        "sub": err.get("detail", "")[:160],
                        "kind": "danger",
                        "badge": "SYNC",
                    },
                },
            )
        finally:
            self._sync_busy = False

    def sync_clock(self) -> dict[str, Any]:
        """LAN clock sync on the bound terminal."""
        try:
            from face_sync import sync_clock_local
            from link_diag import alert_from_error, log_file_path, setup_logging

            setup_logging(self.session.root)
            result = sync_clock_local(self.session.root)
            if result.get("ok"):
                alert = {
                    "text": result.get("message") or "Время обновлено",
                    "detail": result.get("detail") or "",
                    "hint": result.get("hint") or "",
                    "logPath": str(log_file_path(self.session.root)),
                    "kind": "ok",
                }
            else:
                err = result.get("error") or {"title": result.get("message"), "detail": "", "hint": ""}
                alert = alert_from_error(err if isinstance(err, dict) else {"title": str(err), "detail": "", "hint": ""})
            self._emit(
                "onSyncClockDone",
                {"ok": bool(result.get("ok")), "result": result, "alert": alert},
            )
            return result
        except Exception as exc:
            from link_diag import alert_from_error, explain

            err = explain(str(exc), context="clock")
            out = {"ok": False, "message": err["title"], "error": err}
            self._emit(
                "onSyncClockDone",
                {"ok": False, "result": out, "alert": alert_from_error(err)},
            )
            return out

    def window_minimize(self) -> bool:
        hwnd = self._hwnd()
        if hwnd and sys.platform == "win32":
            try:
                ctypes.windll.user32.ShowWindow(hwnd, _SW_MINIMIZE)
                return True
            except Exception:
                pass
        win = self._window()
        if win is None:
            return False
        try:
            win.minimize()
            return True
        except Exception:
            return False

    def window_toggle_maximize(self) -> bool:
        hwnd = self._hwnd()
        if hwnd and sys.platform == "win32":
            try:
                if self._is_maximized():
                    ctypes.windll.user32.ShowWindow(hwnd, _SW_RESTORE)
                else:
                    ctypes.windll.user32.ShowWindow(hwnd, _SW_MAXIMIZE)
                return True
            except Exception:
                pass
        win = self._window()
        if win is None:
            return False
        try:
            if self._is_maximized():
                win.restore()
            else:
                win.maximize()
            return True
        except Exception:
            return False

    def window_start_resize(self, edge: str = "se") -> bool:
        """Begin OS window resize from a frameless edge/corner (mouse already down)."""
        if sys.platform != "win32":
            return False
        hwnd = self._hwnd()
        if not hwnd:
            return False
        ht = _HT_BY_EDGE.get(str(edge or "se").lower())
        if ht is None:
            return False
        try:
            user32 = ctypes.windll.user32
            user32.ReleaseCapture()
            user32.SendMessageW(hwnd, _WM_NCLBUTTONDOWN, ht, 0)
            return True
        except Exception:
            return False

    def window_close(self) -> bool:
        win = self._window()
        if win is None:
            return False
        try:
            win.destroy()
            return True
        except Exception:
            return False


def run_desktop() -> None:
    _set_aumid()
    try:
        import webview
    except ImportError as exc:
        raise SystemExit(
            "pywebview kerak. pip install pywebview\n" + str(exc)
        ) from exc

    # Resume after reboot / network drop: worker + HttpHost heal without re-Ulash.
    try:
        from auto_resume import ensure_background_worker, reconcile_link
        from paths import find_root, load_config, load_service_config

        root = find_root()
        ensure_background_worker(root)
        svc = load_service_config(root) or {}
        cfg = load_config(root)
        api_url = str(svc.get("apiUrl") or cfg.get("apiUrl") or "").rstrip("/")
        tenant = str(svc.get("tenantCode") or cfg.get("tenantCode") or "demo")
        if api_url and svc.get("enabled") is not False:
            reconcile_link(root, api_url, tenant, force_httphost=False)
    except Exception:
        pass

    ui = _ui_dir()
    index = ui / "index.html"
    if not index.is_file():
        raise SystemExit(f"UI topilmadi: {index}")

    holder: dict[str, Any] = {"window": None}
    api = LinkApi(holder)
    icon = None
    for cand in (
        base / name
        for base in (Path(sys.executable).resolve().parent, find_root(), Path(__file__).resolve().parent)
        for name in app_icon_names("ico")
    ):
        if cand.is_file():
            icon = str(cand)
            break

    window = webview.create_window(
        APP_TITLE,
        url=index.as_uri(),
        js_api=api,
        width=680,
        height=860,
        min_size=(560, 680),
        background_color="#F3F3F3",
        text_select=False,
        frameless=True,
        easy_drag=False,
        resizable=True,
        shadow=True,
    )
    holder["window"] = window

    def _on_shown() -> None:
        _enable_frameless_resize(window)

    try:
        window.events.shown += _on_shown
    except Exception:
        pass
    webview.start(gui="edgechromium", icon=icon)


def _enable_frameless_resize(window) -> None:
    """Keep custom chrome but allow OS edge/corner resize + min/max boxes."""
    if sys.platform != "win32":
        return
    try:
        native = getattr(window, "native", None)
        if native is None:
            return
        hwnd = int(native.Handle.ToInt32())
    except Exception:
        return
    try:
        user32 = ctypes.windll.user32
        GWL_STYLE = -16
        WS_THICKFRAME = 0x00040000
        WS_MINIMIZEBOX = 0x00020000
        WS_MAXIMIZEBOX = 0x00010000
        WS_SYSMENU = 0x00080000
        SWP_NOSIZE = 0x0001
        SWP_NOMOVE = 0x0002
        SWP_NOZORDER = 0x0004
        SWP_FRAMECHANGED = 0x0020
        style = user32.GetWindowLongW(hwnd, GWL_STYLE)
        style |= WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU
        user32.SetWindowLongW(hwnd, GWL_STYLE, style)
        user32.SetWindowPos(
            hwnd,
            0,
            0,
            0,
            0,
            0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
        )
    except Exception:
        pass


if __name__ == "__main__":
    run_desktop()
